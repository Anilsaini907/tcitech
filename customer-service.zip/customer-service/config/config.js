const fs = require('fs');
const config = require('config')

const databaseAccount = JSON.parse(process.env.databaseAccount);

let options = databaseAccount.options;

if(process.env.NODE_ENV === 'development-local'){
    delete options.dialectOptions;
}

module.exports = {
'development-local' : {
  database: config.db.name, 
  username: databaseAccount.username,
  password: databaseAccount.password,
  ...options
  },
  development:{
  database: config.db.name, 
  username: databaseAccount.username,
  password: databaseAccount.password,
  ...options
  },
  staging:{
    database: config.db.name, 
    username: databaseAccount.username,
    password: databaseAccount.password,
    ...options
  },
  stage1:{
    database: config.db.name, 
    username: databaseAccount.username,
    password: databaseAccount.password,
    ...options
  },  
  crp:{
    database: config.db.name, 
    username: databaseAccount.username,
    password: databaseAccount.password,
    ...options
  },    
  preprod:{
    database: config.db.name, 
    username: databaseAccount.username,
    password: databaseAccount.password,
    ...options
  },
  dev2:{
    database: config.db.name, 
    username: databaseAccount.username,
    password: databaseAccount.password,
    ...options
  },  
  sit:{
    database: config.db.name, 
    username: databaseAccount.username,
    password: databaseAccount.password,
    ...options
  },  
  kut:{
    database: config.db.name, 
    username: databaseAccount.username,
    password: databaseAccount.password,
    ...options
  },      
  p2mig:{
    database: config.db.name, 
    username: databaseAccount.username,
    password: databaseAccount.password,
    ...options
  },    
  production:{
  database: config.db.name, 
  username: databaseAccount.username,
  password: databaseAccount.password,
  ...options
  },
};