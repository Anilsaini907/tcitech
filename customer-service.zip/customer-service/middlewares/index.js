const cors = require('cors');
const bodyParser = require('body-parser');
const _ = require('lodash');
const validator = require('express-validator');


class MiddlewareIndex {
    constructor(app) {
        this.app = app;
    }
    configureMiddlewares() {

        this.app.use(cors());
        this.app.options('*', cors()); 
        this.app.use(bodyParser.json({ limit: '50mb' }));
        this.app.use(bodyParser.urlencoded({
            extended: false
        }));
        this.app.use(validator({
            customValidators: {
              enum: (input, options) => options.includes(input)
            }
          }));
     
    }
}

module.exports = (app) => {
    return new MiddlewareIndex(app);
}