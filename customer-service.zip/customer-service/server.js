const compression = require('compression');

process.env.NODE_ENV = process.env.NODE_ENV || 'development-local';
console.info("Environment: ", process.env.NODE_ENV);

const environment = require('./utilities/environment.process');
environment.processEnvironmentVariables().then(() => {
  //successfully set environment variables from google store
  const _ = require('lodash');

  const express = require('express');
  const swaggerOptions = require('./services/services.config/SwaggerOptions');
  const logUtils = require('./utilities/logUtils');

  const app = express();
  // https://medium.com/@victor.valencia.rico/gzip-compression-with-node-js-cc3ed74196f9
  // use compression to reduce response size
  // gzip header will auto-detect by browser
  app.use(compression());
  const middlewares = require('./middlewares')(app);
  middlewares.configureMiddlewares();

  const expressSwagger = require('express-swagger-generator')(app);

  const authMaster = require('@driveit/driveit-databases/databases/auth');
  const salesMaster = require('@driveit/driveit-databases/databases/salesMaster');
  const serviceMaster = require('@driveit/driveit-databases/databases/serviceMaster');
  const specMaster = require('@driveit/driveit-databases/databases/specMaster');
  const notificationMaster = require('@driveit/driveit-databases/databases/notificationMaster');
  const tradeinMaster = require('@driveit/driveit-databases/databases/tradeinMaster');
  const pricingMaster = require('@driveit/driveit-databases/databases/pricingMaster');
  const generalMaster = require('@driveit/driveit-databases/databases/generalMaster');
  const customerMaster = require('@driveit/driveit-databases/databases/customerMaster');
  const authSyncDatabase = require('@driveit/driveit-databases').authSyncDatabase;


  authSyncDatabase(customerMaster, {
    runMigration: false
  }).then(() => {
    
    // to fix model association
    let dbModels = {};
    const generalModels = _.omit(generalMaster, ['sequelize']);
    dbModels = {...generalModels}
    const customerModels = _.omit(customerMaster, ['sequelize']);
    dbModels = {...dbModels, ...customerModels}
    const salesModels = _.omit(salesMaster, ['sequelize']);
    dbModels = {...dbModels, ...salesModels}
    const serviceModels = _.omit(serviceMaster, ['sequelize']);
    dbModels = {...dbModels, ...serviceModels}
    const specModels = _.omit(specMaster, ['sequelize']);
    dbModels = {...dbModels, ...specModels}
    const authModels = _.omit(authMaster, ['sequelize']);
    dbModels = {...dbModels, ...authModels}
    const notificationModels = _.omit(notificationMaster, ['sequelize']);
    dbModels = {...dbModels, ...notificationModels}
    const tradeInModels = _.omit(tradeinMaster, ['sequelize']);
    dbModels = {...dbModels, ...tradeInModels}
    const pricingModels = _.omit(pricingMaster, ['sequelize']);
    dbModels = {...dbModels, ...pricingModels}

    // run associates
    Object.values(dbModels).filter(model => typeof model.associate === "function").forEach(model => model.associate(dbModels));

    const services = require('./services');

    logUtils.initDebugLogging(app);

    expressSwagger(swaggerOptions);
    services(app);
    logUtils.initErrorLogging(app);

    const port = process.env.PORT || 8082;

    app.listen(port, () => {
      console.info(`Server started on environment: ${process.env.NODE_ENV} and listening on port: ${port}`)
    });

  });

  
  module.exports = app;

}).catch((error) => {
  console.error('Startup Error: ', error)
});