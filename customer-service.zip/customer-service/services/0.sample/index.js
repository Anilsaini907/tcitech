const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');
const customValidator = require('./validation');
/**
 * Search for Sample listing
 * 
 * @route POST /sample/search
 * @operationId SampleSearch
 * @group Warranty Claim Category API
 * @param {SampleSearch.model} SampleSearch.body - Search. Show all if not provided.
 * @returns {SampleSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;
    const headers = req.headers;

    if (search) {
        search.forEach((searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        })
    }
    errorDef.parameterHandler([order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.search(page, limit, order, search, filter, headers).then((resp) => {

        return res.status(200).send({
            ...resp,
            order,
            page,
            limit,
            search,
            filter
        });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add Sample
 * 
 * @route PUT /sample/add
 * @operationId SampleAdd
 * @group Warranty Claim Category API
 * @param {AddSample.model} AddSample.body.required - required AddSample
 * @returns {Array.<SampleData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.put('/add', async function (req, res, next) {
    const datas = req.body.datas;

    errorDef.parameterHandler([datas]);
    datas.forEach((Sample) => {
        errorDef.parameterHandler([
            Sample.code,
        ]);
    })
    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addMany(datas, userInfo.id).then((result) => {
                return res.status(200).send(result);
            })
            .catch((reason) => {
                next(reason);
            });
    }
});

/**
 * Update Sample
 * 
 * @route PUT /sample/update
 * @operationId SampleUpdate
 * @group Warranty Claim Category API
 * @param {UpdateSample.model} UpdateSample.body.required - required UpdateSample
 * @returns {SampleData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.put('/update', async function (req, res, next) {
    const id = req.body.id;
    const data = req.body.data;

    errorDef.parameterHandler([id, data]);

    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.update(id, data, userInfo.id).then((record) => {
            if (!record) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(record);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete Sample
 * 
 * @route DELETE /sample/delete
 * @operationId SampleDelete
 * @group Warranty Claim Category API
 * @param {DeleteSample.model} DeleteSample.body.required - required DeleteSample
 * @returns {SampleData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', async function (req, res, next) {
    const id = req.body.id;
    const option = req.body.option;

    errorDef.parameterHandler(id);
    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        // return functions.deleteMany(ids, option, userInfo.id).then((response) => {
        return functions.delete(id, option, userInfo.id).then((response) => {
            return res.status(200).send(response);
        }).catch((reason) => {
            next(reason);
        });
    }
});

module.exports = router;