const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateSample: (req, res, next) => {
        req.checkBody('datas', 'Sample object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('datas.*.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('datas.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('datas.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateSample: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('sample', 'Customer Group object parameter is missing').trim().notEmpty();
        req.checkBody('sample.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('sample.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('sample.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteSample: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}