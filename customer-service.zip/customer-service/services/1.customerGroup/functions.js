const CustomerGroupModel = require('@driveit/driveit-databases/databases/customerMaster/models/1.customerGroup');
const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
var _ = require('lodash');
const request = require('request');

class Functions {

    static async getCustomerGroup(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        };

        if (search) {
            let excludedSearch = _.remove(search, (o) => { return o.colId === 'countryName' || o.colId === 'countryCode'; });
            let searched = await this.prepQry(excludedSearch, token);
            search = _.concat(search, searched);
        }

        let attr = null;
        let customerGroupRes = await CustomerGroupModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond);

        let resp = await CountryModel.searchAll([], ['id', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], [], true, true, true);
        let countries = resp && !_.isEmpty(resp) ? _.map(resp, 'dataValues') : [];

        _.forEach(customerGroupRes.rows, (row) => {
            let found = _.find(countries, (o) => { return _.isEqual(o.id, row.countryId); });
            if (found) {
                row.dataValues['countryName'] = found.name ? found.name : '';
            }
        });

        return {
            ...customerGroupRes,
            page: page.page,
            limit: page.limit
        };
    }

    static async prepQry(search, token) {
        let likeArr = [];
        let searchMasterDatas = [];
        for(let u = 0; u < _.size(search); u++) {
            if (search[u].colId === 'countryName') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "name", text: search[u].text }],
                        skipInclude: true
                    });
                } else {
                    let found = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found) {
                        found.search.push({ colId: "name", text: search[u].text });
                    }
                }
            } else if (search[u].colId === 'countryCode') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "code", text: search[u].text }],
                        skipInclude: true
                    });
                } else {
                    let found1 = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found1) {
                        found1.search.push({ colId: "code", text: search[u].text });
                    }
                }
            }
        }
        

        let queryResult = await generalCache.getMasterDataByQuery(searchMasterDatas, token);
        if (queryResult) {
            if (queryResult.country) {
                let countryIds = [];
                queryResult.country.forEach((country) => {
                    countryIds.push(country.id);
                });
                likeArr.push({ colId: 'countryId', text: !_.isEmpty(countryIds) ? countryIds : ['00000000-0000-0000-0000-000000000000'] });
            }
        }
        return likeArr;
    }

    static async getAll(page) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;

        //temp fix for PBI 663. Task 729. to display country Name
        return CustomerGroupModel.getAll(q, attr, pagination, page.order).then((customerGroupRes) => {
            let masterdataTypes = ["country"];
            let token = page.token ? page.token : null;
            return generalCache.processMasterdataResult(customerGroupRes.rows, masterdataTypes, token).then((mdResults) => {
                _.forEach(customerGroupRes.rows, (row) => {
                    let mObj = {};
                    _.forEach(mdResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if (c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });

                        if (mObj[key] && mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    });
                });
                return {
                    ...customerGroupRes,
                    page: page.page,
                    limit: page.limit
                };
            });
        });

        // return {
        //     ...await CustomerGroupModel.getAll(q, attr, pagination, page.order),
        //     page: page.page,
        //     limit: page.limit
        // };
    }
    static async updateDefault(taxdata){
        const data={default:'disabled'}
        const where={countryId:taxdata.countryId,deleted:0,default:'enabled',status:'enabled'}
        const getDefaultValue=await CustomerGroupModel.findAll({where:where});
        if(getDefaultValue.length>0){
            var result=await CustomerGroupModel.update(data, {where:{id:getDefaultValue[0].id}});
        }
        return result;
    }
    static async addCustomerGroup(customerGroupObj, who) {
        if(customerGroupObj[0].default==='enabled'){
            const data={default:"disabled"}
            const where={countryId:customerGroupObj[0].countryId,deleted:0,status:'enabled'}
            await CustomerGroupModel.update(data, {where:where});
        }
        return CustomerGroupModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(customerGroupObj, async(addCustomerGroupObj) => {
                addCustomerGroupObj['createdBy'] = who;
                addCustomerGroupObj['updatedBy'] = who;
                const p = CustomerGroupModel.addNew(addCustomerGroupObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    static async updateCustomerGroup(customerGroup, where, who) {
        if(customerGroup.default==='enabled'){
            const data={default:"disabled"}
            const where={countryId:customerGroup.countryId,deleted:0,status:'enabled'}
            await CustomerGroupModel.update(data, {where:where});
        }
        customerGroup['updatedBy'] = who;
        customerGroup['id'] = where.id;
        return await CustomerGroupModel.updateCustomerGroup(customerGroup, where).then(() => {
            return CustomerGroupModel.getId(where).then((resp) => {
                if (!resp) {
                    throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteCustomerGroup(where, who, type = "soft") {
        if (type == "soft") {
            return await CustomerGroupModel.deleteSoft(where, who).then(() => {
                return CustomerGroupModel.getAll(where, null).then((resp) => {
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await CustomerGroupModel.deleteHard(where).then((resp) => {
                if (!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }

    static async saveMessageToPubSub(customerGroupObj, key) {
        let data;
        switch (key) {
            case 'INSERT':
                data = customerGroupObj[0].dataValues
                data.key = "INSERT";
                break;
            case 'DELETE':
                data = customerGroupObj.rows[0].dataValues;
                data.key = "DELETE";
                break;
            case 'UPDATE':
                data = customerGroupObj.dataValues;
                data.key = "UPDATE";
                break;
            default:
                break;
        }
        var options = {
            method: 'POST',
            url: 'https://event-hub-dot-tc3s-dev.appspot.com/message',
            body: {
                topic: 'my-topic',
                data: data
            },
            json: true
        };
        request(options, function (error, response, body) {
            if (error) {
                console.log('got error', error);
            } else {
                console.log(response.body, "status");
            }
        });
    }

}


module.exports = Functions;