const _ = require('lodash');
const functions = require('./functions');
// const { Client } = require('@elastic/elasticsearch');

// const client = new Client({
//     node: process.env.ES_URL || 'https://35.197.131.114:9200',
//     auth: {
//         username: process.env.ES_USERNAME || 'elastic',
//         password: process.env.ES_PASSWORD || 'nrhf2vddlwm59qwv4g2trw2j'
//     },
//     ssl: {
//         rejectUnauthorized: false
//     }
// })

const indexName = 'customer-master';
const indexAlias = 'customer-master';
const docType = 'customerMaster';

const self = module.exports = {
    // addNewVehicle:()=>{
    //     return new Promise(resolve=>{

    //     });
    // }

    /** indexing API - to upload existing records to ElasticSearch */
    pumpDatainES: async (data, headers) => {
        const page = data.page;
        const limit = data.limit;
        const order = data.order;
        const search = data.search || [];
        const filter = data.filter || [];
        const token = headers.authorization;

        let pageObj = {
            page,
            limit,
            order: _.isArray(order) ? order : [order.columnName, order.direction],
            token
        };

        // let customerData = await functions.getCustomer(search, pageObj, filter, null);

        // customerData.rows.forEach(async elementRes => {
        //     const esPayload = {
        //         id: elementRes.id,
        //         index: indexName,
        //         routing: elementRes.id,
        //         // body: elementRes.dataValues
        //         body: elementRes
        //     };
        //     const bulkRoData = await client.create(esPayload)
        //         .catch(err => {
        //             console.log('err', err.body.error.root_cause);
        //         })
        // });
    },
    /**
     * Update the Data in ES
     */
    updateDatainES: (data, headers = null) => {
        return new Promise(async resolve => {

            const page = data.page;
            const limit = data.limit;
            const order = data.order;
            const search = data.search || [];
            const filter = data.filter || [];
            // const token = headers.authorization;

            let pageObj = {
                page,
                limit,
                order: _.isArray(order) ? order : [order.columnName, order.direction],
                // token
            };
            // let customerData = await functions.getCustomer(search, pageObj, filter);
            // customerData.rows.forEach(async element => {
            //     await client.update({
            //         id: element.id,
            //         index: indexAlias,
            //         refresh: 'true',
            //         routing: element.id,
            //         body: {
            //             doc: element
            //         }
            //     }).then(() => {
            //         resolve()
            //     })
            //         .catch(err => {
            //             console.log('err', err.body.error.root_cause);
            //         });
            // });
        })
    },

    /**
     * Saves new RO Data Into Elastic Search
     */
    // wip
    saveNewData: (ids, headers) => {
        return new Promise(async resolve => {
            const page = 1;
            const limit = 999;
            const order = {
                "columnName": "updatedAt",
                "direction": "DESC"
            };
            const filter = [{ colId: "id", text: ids }];
            const token = headers.authorization;

            let pageObj = {
                page,
                limit,
                order: _.isArray(order) ? order : [order.columnName, order.direction],
                token
            };

            // let customerData = await functions.getCustomer([], pageObj, filter);
            // if (customerData.rows.length > 0) {
            //     customerData.rows.forEach(async elementRes => {
            //         const esPayload = {
            //             id: elementRes.id,
            //             index: indexName,
            //             routing: elementRes.id,
            //             body: elementRes
            //         };
            //         const bulkRoData = await client.create(esPayload)
            //             .catch(err => {
            //                 console.log('err', err.body.error.root_cause);
            //             })
            //         console.log('bulkRoData added in ES', bulkRoData)
            //     });
            // }
            resolve();
        });

    },

    /**
     * Update the RO Data
     */
    updateDataById: (id, headers) => {
        return new Promise(async resolve => {
            const page = 1;
            const limit = 1;
            const order = {
                "columnName": "updatedAt",
                "direction": "DESC"
            };
            const filter = [
                {
                    "colId": "id",
                    "text": [
                        id
                    ]
                }
            ];
            const token = headers.authorization;

            let pageObj = {
                page,
                limit,
                order: _.isArray(order) ? order : [order.columnName, order.direction],
                token,
                showAll: true
            };
            let customerData = await functions.getCustomer([], pageObj, filter);
            if (customerData.rows.length > 0) {
                
                let filter = [
                    {
                        "bool": {
                            "must": [{
                                wildcard: {
                                    "id": `*${id}*`
                                }
                            }]
                        }
                    }
                ];
                let query = {
                    "bool": {
                        "filter": [...filter]
                    }
                };

                // let x = await client.search({
                //     index: indexAlias,
                //     from: 0,
                //     size: 99,
                //     body: {
                //         query
                //     }
                // }).catch(err => {
                //     console.log(err);
                // });
                // const count = x.body.hits.total.value;
                
                // if (count === 0) {

                //     const esPayload = {
                //         id: customerData.rows[0].id,
                //         index: indexName,
                //         routing: customerData.rows[0].id,
                //         body: customerData.rows[0]
                //     };
                //     await client.create(esPayload)
                //         .catch(err => {
                //             console.log('err', err.body.error.root_cause);
                //         });

                // } else {
                //     await client.update({
                //         id: customerData.rows[0].id,
                //         index: indexAlias,
                //         refresh: 'true',
                //         routing: customerData.rows[0].id,
                //         body: {
                //             doc: customerData.rows[0]
                //         }
                //     })
                //     .catch(err => {
                //         console.log(err);
                //         console.log(customerData)
                //     });
                // }
                

                resolve();
            } else {
                resolve();
            }
        })
    },
    updateDataByIds: (ids, headers) => {
        return new Promise(async resolve => {
            const page = 1;
            const limit = 1;
            const order = {
                "columnName": "updatedAt",
                "direction": "DESC"
            };
            const filter = [{ colId: "id", text: ids }];
            const token = headers.authorization;

            let pageObj = {
                page,
                limit,
                order: _.isArray(order) ? order : [order.columnName, order.direction],
                token
            };
            let customerData = await functions.getCustomer([], pageObj, filter);
            if (customerData && customerData.rows && customerData.rows.length > 0) {
                customerData.rows.forEach(async elementRes => {

                    let filter = [
                        {
                            "bool": {
                                "must": [{
                                    wildcard: {
                                        "id": `*${elementRes.id}*`
                                    }
                                }]
                            }
                        }
                    ];
                    let query = {
                        "bool": {
                            "filter": [...filter]
                        }
                    };
    
                    // let x = await client.search({
                    //     index: indexAlias,
                    //     from: 0,
                    //     size: 99,
                    //     body: {
                    //         query
                    //     }
                    // }).catch(err => {
                    //     console.log(err);
                    // });
                    // const count = x.body.hits.total.value;

                    // if (count === 0) {

                    //     const esPayload = {
                    //         id: elementRes.id,
                    //         index: indexName,
                    //         routing: elementRes.id,
                    //         body: elementRes
                    //     };
                    //     await client.create(esPayload)
                    //         .catch(err => {
                    //             console.log('err', err.body.error.root_cause);
                    //         });

                    // } else {
                    //     await client.update({
                    //         id: elementRes.id,
                    //         index: indexAlias,
                    //         refresh: 'true',
                    //         routing: elementRes.id,
                    //         body: {
                    //             doc: elementRes
                    //         }
                    //     })
                    //         .catch(err => {
                    //             console.log(err);
                    //             console.log(customerData)
                    //         });
                    // }

                    
                })
                resolve();
            }
        })
    },
    deleteDataByIds: (ids, headers) => {
        return new Promise(async resolve => {

            const shouldMatch = ids.map((id) => {
                return {
                    match: {
                        id
                    }
                }
            });

            // resolve(shouldMatch);

            // await client.deleteByQuery({
            //     index: indexAlias,
            //     body: {
            //         query: {
            //             bool: {
            //                 filter: [
            //                     {
            //                         bool: {
            //                             should: shouldMatch
            //                         }
            //                     }
            //                 ]
            //             }
            //         }
            //     }
            // })
            //     .catch(err => {
            //         console.log(err);
            //         console.log('ids not updated in ES : ', ids)
            //     });
            resolve();
        })
    },

    /**
     * Search Record From ES
     */

    search: (payload) => {
        let filter = [];
        let filter_ = [];
        let addedDateRange = false;
        let nested;
        /* // nested search example
        "search": [
            {
                "colId": "customerDetails.company.code",
                "path": "customerDetails",
                "text": [
                    "myesb"
                ]
            }
        ],
        */
        if (payload.search) {
            let mustArr = [];
            payload.search.forEach((v) => {
                if(v.path) {
                    nested = {
                        path: v.path,
                        query: {
                            bool: {
                                should: [
                                    {
                                        wildcard: {
                                            [v.colId]: ((v.text[0] != null) && v.text[0] != '') ? `*${v.text[0].toLowerCase()}*`: ''
                                        }
                                    },
                                    {
                                        wildcard: {
                                            [v.colId]: ((v.text[0] != null) && v.text[0] != '') ? `*${v.text[0].toUpperCase()}*`: ''
                                        }
                                    }
                                ]
                            }
                        }
                    }
                } else {
                    if (v.text) {
                        v.text.forEach((w) => {
                            if (w) {
                                mustArr.push({
                                    wildcard: {
                                        [v.colId]: ['status'].includes(v.colId) ? `*${w.toLowerCase()}*` : `*${w.toUpperCase()}*`
                                    }
                                });
                            }
                        });
                    }
                }
                
            });
            
            if (mustArr.length > 0) {
                filter = [
                    {
                        "bool": {
                            "must": mustArr
                        }
                    }
                ]
            }
        }
        // let range = {};
        if (payload.filter) {

            filter_ = payload.filter.map(i => {
                // console.log((i.colId !== 'startDate' && i.colId !== 'endDate'))
                if (i.colId !== 'startDate' && i.colId !== 'endDate') {
                    const t = i.text.map(element => {
                        return {
                            "match_phrase": {
                                [i.colId]: {
                                    "query": `${element}`
                                }
                            }
                        }
                    });
                    return {
                        "bool": {
                            "should": t,
                            "minimum_should_match": 1
                        }
                    }
                } else {

                    const dateFilter = _.map(payload.filter, 'colId');
                    if ((dateFilter.indexOf('startDate') !== -1 && dateFilter.indexOf('endDate') !== -1) && addedDateRange == false) {
                        const startDateVal = payload.filter.filter(x => x.colId == 'startDate')[0];
                        const endDateVal = payload.filter.filter(x => x.colId == 'endDate')[0];
                        const x = {
                            "range": {
                                "repairOrderDate": {
                                    "gte": startDateVal.text[0],
                                    "lte": endDateVal.text[0]
                                }
                            }
                        }
                        addedDateRange = true;
                        return x;
                    } else if ((dateFilter.indexOf('startDate') !== -1) && addedDateRange == false) {
                        const t = i.text.map(element => {
                            addedDateRange = true;
                            return {
                                "match_phrase": {
                                    [i.colId]: {
                                        "query": `${element}`
                                    }
                                }
                            }
                        });
                        return {
                            "bool": {
                                "should": t,
                                "minimum_should_match": 1
                            }
                        }
                    } else if ((dateFilter.indexOf('endDate') !== -1) && addedDateRange == false) {
                        const t = i.text.map(element => {
                            addedDateRange = true;
                            return {
                                "match_phrase": {
                                    [i.colId]: {
                                        "query": `${element}`
                                    }
                                }
                            }
                        });
                        return {
                            "bool": {
                                "should": t,
                                "minimum_should_match": 1
                            }
                        }
                    }

                    // console.log();
                    // console.log((dateFilter.indexOf('startDate') !== -1 && dateFilter.indexOf('endDate') !== -1))
                }
            });
            filter_ = filter_.filter(Boolean);

        }
        let orderCol = payload.order.columnName;

        const query = {
            "bool": {
                "filter": [...filter, ...filter_]
            },
        };
        if (nested) {
            query.bool.filter.push({nested});
        }
        // console.log('nested.........', JSON.stringify(query))

        return new Promise(resolve => {
            // client.search({
            //     index: indexAlias,
            //     from: (payload.limit ? payload.limit * (payload.page - 1) : 0),
            //     size: payload.limit,
            //     body: {
            //         // "query": {
            //         //     "bool": {
            //         //         "filter": [...filter, ...filter_]
            //         //     },
            //         //     nested
            //         // },
            //         query,
            //         "sort": [
            //             {
            //                 [orderCol]: {
            //                     "order": payload.order.direction
            //                 }
            //             }
            //         ]
            //     }
            // }).then(x => {
            //     const count = x.body.hits.total.value;
            //     const rows = _.map(x.body.hits.hits, '_source');
            //     resolve({
            //         count: count,
            //         rows: rows
            //     })
            // })
            //     .catch(err => {
            //         console.log(err);
            //     });

        })
    },

    /**
     * Update the RepairOrderType In ES through update_by_query
     */
    // updateROType:(id,data)=>{
    //     return new Promise(async resolve=>{
    //         await client.updateByQuery({
    //             index: indexAlias,
    //             body: {
    //                 "query": {
    //                     "term": {
    //                         "repairOrderTypeId": id
    //                     }
    //                 },
    //                 "script": {
    //                     "source": `ctx._source.repairOrderTypeCode = '${data.code}';ctx._source.repairOrderTypeName = '${data.name}';ctx._source.roTypeChargeType = '${data.chargeType}';`,
    //                     "lang": "painless"
    //                 }
    //             }
    //         })
    //         .catch(err => {
    //             console.log(err);
    //             console.log(getReWampData)
    //         });
    //         resolve();
    //     })
    // }
}