var _ = require('lodash');
const uuidv4 = require('uuid').v4;
class GetFunction {
  // #region - For Search functions
  
  static getNavInterfaceCustomerSql(customerId, action) {
    const fileId = uuidv4();
    return `
    SELECT  '${fileId}' as 'fileId', records.*
    FROM
    (SELECT distinct
            'C' AS 'dataType',
            '${action}' AS 'action',
			      'TCEAS' AS 'companyCode',
            IFNULL(f.previousCustomerNo, customer.id) AS 'no',
			      SUBSTRING(customer.name, 1, 50)  AS 'name',
            SUBSTRING(customer.name, 51, 100) AS 'name2',
            SUBSTRING(customerDetails.mAddress1, 1, 50) AS 'address',
            SUBSTRING(customerDetails.mAddress2, 1, 50)  AS 'address2',
            SUBSTRING(customerDetails.mAddress3, 1, 50)   AS 'address3',
            '' AS 'address4',
            postcode.code AS 'postCode',
            country.code AS 'countryCode',
            SUBSTRING(recContact.name, 1, 50) AS 'contact',
            IFNULL(CONCAT(aom.code, customerDetails.mobile), CONCAT(aot.code, customerDetails.telephone))  AS 'phoneNo',
            CONCAT(aof.code, customerDetails.fax) AS 'faxNo',
            SUBSTRING(customerDetails.email, 1, 50)  AS 'email',
            IFNULL(con2.value1, 'NoCUST_PG') AS 'cusVenPostingGroup',
            con.value1 AS 'paymentTermCode',
            '' AS 'paymentMethodCode',
            case WHEN customer.status IN ('inactive','disabled') THEN 1 ELSE 0 END AS 'isDeleted',
            customer.IdentityNo AS 'registrationNo',
            f.creditLimit AS 'creditLimit',
            f.vatNumber AS 'gstRegistrationNo',
            IFNULL(con2.value1, 'NoCUST_PG')  AS 'gstBusinessPostingGroup',
            '' AS 'gstStatusLastCheckedDate',
            IFNULL(con2.value1, 'NoCUST_PG') AS 'genBusPostingGroup',
            '' AS 'reservefield6',
            '' AS 'reservefield7',
            '' AS 'reservefield8',
            '' AS 'reservefield9',
            '' AS 'reservefield10'
    FROM customer_master.customer 
	  INNER JOIN customer_master.company ON company.code IN ('MYEAS','KHEAS')
    LEFT JOIN customer_master.customerDetails on customerDetails.customerId = customer.id
    and customerDetails.companyId IN ( select id from customer_master.company where dealerGroupId IN (select id from customer_master.dealerGroup where code = 'TCDLR'))
    LEFT JOIN general_master.areaOperatorCode aom on aom.id = customerDetails.mobileCode
    LEFT JOIN general_master.areaOperatorCode aof on aof.id = customerDetails.faxCode
    LEFT JOIN general_master.areaOperatorCode aot on aot.id = customerDetails.telCode
    LEFT JOIN general_master.postcode on postcode.id = customerDetails.mPostcodeId
    LEFT JOIN (SELECT customerId, name, customerDetailsId from customer_master.customerContact where customerId = '${customerId}' order by createdAt desc LIMIT 1) recContact on recContact.customerId = customer.id and recContact.customerDetailsId = customerDetails.id
    LEFT JOIN general_master.country on country.id = customerDetails.mCountryId
    LEFT JOIN customer_master.customerAccountGroup cag on customer.customerAccountGroupId = cag.id
    LEFT JOIN customer_master.customerFinance f ON customer.id = f.customerId AND f.companyId = company.id
    LEFT JOIN customer_master.customerGroup cg on cg.id = f.customerGroupId
    LEFT JOIN customer_master.paymentTerms pt ON pt.id = f.paymentTermsId
	  LEFT JOIN (SELECT parameter2, parameter3, value2, value1 FROM general_master.constantParameter WHERE module = 'SHARED' AND functionArea = 'CUST_PT_NAV') AS con on con.parameter2 = company.code AND con.parameter3 = pt.code
	  LEFT JOIN (SELECT parameter2, parameter3, parameter4, value2, value1 FROM general_master.constantParameter WHERE module = 'SHARED' AND functionArea = 'CUST_PG_NAV') AS con2 on con2.parameter2 = company.code AND con2.parameter3 = cag.code AND con2.parameter4 = cg.code 
    where customer.id = '${customerId}' and (IFNULL(cg.code,'') NOT IN ('G6') AND IFNULL(pt.code,'') NOT IN ('001'))  ) AS records LIMIT 1
    `;
  }

  // #endregion
}

module.exports = GetFunction;
