const CustomerModel = require('@driveit/driveit-databases/databases/customerMaster/models/10.customer');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

var moment = require('moment');
const generalCache = require('../cache-request/general-api');
const CustomerAccountGroupModel = require('@driveit/driveit-databases/databases/customerMaster/models/6.customerAccountGroup');
const authCache = require('../cache-request/auth-api');
const CustomerDetailsModel = require('@driveit/driveit-databases/databases/customerMaster/models/11.customerDetails');
const ContactRelationship = require('@driveit/driveit-databases/databases/customerMaster/models/5.contactRelationship');
const CustomerMaster = require('@driveit/driveit-databases/databases/customerMaster');
const GeneralMaster = require('@driveit/driveit-databases/databases/generalMaster');
const Utils = require('../../utilities/utils');
const Status = require('@driveit/driveit-databases/databases/generalMaster/models/enums/Status');
const customerDetailsFunctions = require('../11.customerDetails/functions')
const customerFinanceFunctions = require('../12.customerFinance/functions')
const customerContactFunctions = require('../13.customerContact/functions')
const customerRemarksFunctions = require('../34.customerRemarks/functions')
const customerTagsFunctions = require('../35.customerTags/functions')
const customerPdpaFunctions = require('../37.customerPdpa/functions')
const SpecMaster = require('@driveit/driveit-databases/databases/specMaster');
const elasticSearchVehicle = require('../es-shared/elasticsearchVehicle')
const vehicleFunctions = require('../shared-services/functionsVehicle')

const SalutationModel = require('@driveit/driveit-databases/databases/generalMaster/models/10.salutation');
const IdentityModel = require('@driveit/driveit-databases/databases/generalMaster/models/12.identity');
const EducationModel = require('@driveit/driveit-databases/databases/generalMaster/models/08.education');
const PaymentTermModel = require('@driveit/driveit-databases/databases/customerMaster/models/2.paymentTerms');
const CustomerContactModel = require('@driveit/driveit-databases/databases/customerMaster/models/13.customerContact');
const CustomerFinanceModel = require('@driveit/driveit-databases/databases/customerMaster/models/12.customerFinance');
const BranchModel = require('@driveit/driveit-databases/databases/customerMaster/models/18.branch');
const CompanyModel = require('@driveit/driveit-databases/databases/customerMaster/models/7.company');

const CityModel = require('@driveit/driveit-databases/databases/generalMaster/models/03.city');
const StateModel = require('@driveit/driveit-databases/databases/generalMaster/models/02.state');
const PostcodeModel = require('@driveit/driveit-databases/databases/generalMaster/models/04.postcode');
const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const AreaOperatorCodeModel = require('@driveit/driveit-databases/databases/generalMaster/models/60.areaOperatorCode');

const VehicleModel = require('@driveit/driveit-databases/databases/specMaster/models/09.vehicle');
const CustomerVehicleRelationModel = require('@driveit/driveit-databases/databases/specMaster/models/14.customerVehicleRelation');
const VehicleSalesServiceHistoryModel = require('@driveit/driveit-databases/databases/specMaster/models/25.vehicleSalesServiceHistory');
const MakeModel = require('@driveit/driveit-databases/databases/specMaster/models/01.make');
const ModelModel = require('@driveit/driveit-databases/databases/specMaster/models/02.model');
const ServiceHistoryRevampModel = require('@driveit/driveit-databases/databases/serviceMaster/models/114.serviceHistoriesRevamp');
const getFunction = require('./functions.get');
const topicSeries = require('../../utilities/topicSeries');
const Sequelize = require("sequelize");
const kafkaService = require('@driveit/driveit-databases/utils/kafkaService');
const config = require('config');

const Op = Sequelize.Op;
class Functions {

	static async getCustomer(search, page, filter = [], tenantId = null, attribute = [], basicSearch = false, showAll = false, distKeys = null, searchOrCond = false, rowOnly = false, countOnly = false) {
		let customerVehicleRelationWhere;
		const pagination = {
			limit: page.limit,
			offset: page.limit * (page.page - 1),
		};

		if (tenantId !== null) {
			let filter0 = tenantId ? [{ colId: "tenantId", text: [tenantId] }] : [];
			let cDetails = await CustomerDetailsModel.searchAll([], null, {}, ['updatedAt', 'desc'], filter0, true, false, true);
			const customerIds = _.map(cDetails, 'customerId');
			filter = _.concat(filter, [{ colId: "id", text: customerIds }]);
		}

		if (!_.isEmpty(attribute)) {
			const { text: [rCompanyId] = [] } = attribute.find(({ model, colId }) => (model === 'customerDetails' || colId === 'customerDetails.companyId'));

			if (rCompanyId) {
				const { country: { id: countryId } } = await CompanyModel.findOne({
					where: { id: rCompanyId },
					include: [{ model: CountryModel, attributes: ['id', 'code', 'name'] }]
				});

				filter.push({ colId: 'countryId', text: [countryId] });
			}
			if (search && search.length > 0) {
				const [vehicleRegNofiler] = search.filter((o) => o.colId === 'customerVehicleRelations[0].regNo');
				if (vehicleRegNofiler) {
					customerVehicleRelationWhere = {
						regNo: {[Op.like]: `%${vehicleRegNofiler.text[0].toUpperCase()}%`}
					}
					// Remove regNo from search variable
					search = search.filter((o) => o.colId !== 'customerVehicleRelations[0].regNo'); 
				}
			 }
		}



		if (basicSearch) {
			if (search && search.length) { rowOnly = false } // return count if search query
			let result = await CustomerModel.searchAll(search, ['id', 'countryId', 'customerAccountGroupId', 'salutationId', 'name', 'identityId', 'identityNo', 'regionId', 'status'], pagination, page.order, filter, true, showAll, rowOnly, [
				{
					model: CustomerAccountGroupModel,
					attributes: ['id', 'code', 'name'],
				},
				{
					model: GeneralMaster.Country,
					attributes: ['id', 'code', 'name'],
				},
				{
					model: GeneralMaster.Identity,
					attributes: ['id', 'code', 'name'],
				},
				{
					model: GeneralMaster.Region,
					attributes: ['id', 'code', 'name'],
				},
				{
					model: SpecMaster.CustomerVehicleRelation,
					where: customerVehicleRelationWhere,
					attributes: ['id', 'customerId', 'regNo'],

				}
			], null, distKeys, searchOrCond);

			if (rowOnly) {
				return {
					rows: result,
					page: page.page,
					limit: page.limit
				};
			}
			return {
				...result,
				page: page.page,
				limit: page.limit
			};
		}

		let attr = null;
		let customerRes = await CustomerModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond);

		return {
			...customerRes,
			page: page.page,
			limit: page.limit,
			tenantId
		};
	}
	static async prepQry(search) {
		if (search.length > 0) {
			let likeArr = [];
			let regNo = search[0].text[0];
			let regtext = '';
			for (let i = 0; i < regNo.length; i++) {
				regtext += regNo.charAt(i).toUpperCase();
			}

			console.log("search text", regtext);
			const query = `select customerId from spec_master.customerVehicleRelation where regNo LIKE '%${regtext}%' 
       order by createdAt desc`;
			const result = await GeneralMaster.sequelize.query(query, { type: Sequelize.QueryTypes.SELECT });
			//   
			if (result.length > 0) {
				const customerIds = [];
				for (let i = 0; i < result.length; i++) {
					// result[i].customerId;
					customerIds.push(result[i].customerId);
				}
				console.log("customerIds", customerIds);
				likeArr.push({ colId: 'id', text: customerIds });
			}
			return likeArr;
		}
	}
	static async getCustomerLookup(search, pageObj, filter = [], tenantId = null, attribute = [], basicSearch = false, showAll = false, distKeys = null, searchOrCond = false, noCount) {
		
		const getCompanyFilter = filter.find((f) => f.colId == 'companyId');
		filter = filter.filter((f) => f.colId !== 'companyId')
		if (getCompanyFilter) {
			attribute.push({
				model: 'customerDetails',
				colId: 'companyId',
				text: getCompanyFilter.text
			})
		}
		basicSearch = true;

		let getRes = await this.getCustomer(search, pageObj, filter, tenantId, attribute, basicSearch, showAll, distKeys, searchOrCond, noCount);
		let customerIds = getRes.rows.map((c) => c.id);
		customerIds = _.uniq(_.compact(customerIds));

		if (getCompanyFilter) {
			const getCdetails = await CustomerDetailsModel.findAll({
				where: { customerId: customerIds, companyId: getCompanyFilter.text },
				include: [
					{ model: GeneralMaster.PostCode, as: "cPostcode", attributes: ['id', 'code'] },
					{ model: GeneralMaster.City, as: "cCity", attributes: ['id', 'code', 'name'] },
					{ model: GeneralMaster.State, as: "cState", attributes: ['id', 'code', 'name'] },
					{ model: GeneralMaster.Country, as: "cCountry", attributes: ['id', 'code', 'name'] },
					{ model: GeneralMaster.PostCode, as: "mPostcode", attributes: ['id', 'code'] },
					{ model: GeneralMaster.City, as: "mCity", attributes: ['id', 'code', 'name'] },
					{ model: GeneralMaster.State, as: "mState", attributes: ['id', 'code', 'name'] },
					{ model: GeneralMaster.Country, as: "mCountry", attributes: ['id', 'code', 'name'] },
					{ model: GeneralMaster.AreaOperatorCode, as: "areaOperatorCode", attributes: ['id', 'code', 'name', 'cao'] },
					{ model: GeneralMaster.AreaOperatorCode, as: "telCodeDetail", attributes: ['id', 'code', 'name', 'cao'] },
					{ model: GeneralMaster.AreaOperatorCode, as: "faxCodeDetail", attributes: ['id', 'code', 'name', 'cao'] },
				]
			})

			getRes.rows.forEach((row) => {
				const getCdetail = getCdetails.find((each) => {
					return each.customerId === row.id
				})
				if (getCdetail) {
					// row.dataValues.customerDetail = getCdetail;
					this.mapCDetails(getCdetail, row);
				}
			})
		}

		const customerFinanceModel = require('@driveit/driveit-databases/databases/customerMaster/models/12.customerFinance')
		const customerFinanceRes = await customerFinanceModel.findAll({
			where: {
				customerId: customerIds,
				companyId: getCompanyFilter.text[0],
				deleted: 0
			},
			attributes: ['id', 'customerId', 'companyId', 'taxClassId']
		})
		let taxClassIds = customerFinanceRes.map((cf) => cf.taxClassId);
		taxClassIds = _.uniq(_.compact(taxClassIds));
		let taxClassRes;
		if (taxClassIds.length) {
			const taxClassModel = require('@driveit/driveit-databases/databases/customerMaster/models/8.taxclass')
			taxClassRes = await taxClassModel.findAll({
				where: {
					id: taxClassIds,
					deleted: 0
				},
				attributes: ['id', 'code', 'name']
			})
		}

		getRes.rows.forEach((row) => {
			row.dataValues['identityCode'] = row.identity && row.identity.code ? row.identity.code : ''
			row.dataValues['customerGroupCode'] = row.customerAccountGroup && row.customerAccountGroup.code ? row.customerAccountGroup.code : ''
			row.dataValues['customerGroupName'] = row.customerAccountGroup && row.customerAccountGroup.name ? row.customerAccountGroup.name : ''
			row.dataValues['customerAccountGroupCode'] = row.customerAccountGroup && row.customerAccountGroup.code ? row.customerAccountGroup.code : ''
			row.dataValues['customerAccountGroupName'] = row.customerAccountGroup && row.customerAccountGroup.name ? row.customerAccountGroup.name : ''

			let customerFinanceObj = customerFinanceRes.find((finance) => finance.customerId == row.id);
			if (taxClassRes && customerFinanceObj && customerFinanceObj.taxClassId) {
				const foundTax = taxClassRes.find((t) => t.id == customerFinanceObj.taxClassId)
				row.dataValues['taxClassId'] = foundTax.id;
				row.dataValues['taxClassCode'] = foundTax.code;
				row.dataValues['taxClassName'] = foundTax.name;
			} else {
				row.dataValues['taxClassId'] = null
				row.dataValues['taxClassCode'] = null
				row.dataValues['taxClassName'] = null
			}
		})

		console.log("getRes", getRes);
		return getRes;
	}

	static mapCDetails(customerDetails, row) {
		row.dataValues.customerTelCodeId = customerDetails.telCode
		row.dataValues.customerTelCode = customerDetails.telCodeDetail ? customerDetails.telCodeDetail.code : ''
		row.dataValues.customerTel = customerDetails.telephone
		row.dataValues.customerMobileCodeId = customerDetails.mobileCode
		row.dataValues.customerMobileCode = customerDetails.areaOperatorCode ? customerDetails.areaOperatorCode.code : null
		row.dataValues.customerMobile = customerDetails.mobile
		row.dataValues.customerAddress = this.mapCAddress(customerDetails)
	}

	static mapCAddress(customerDetail) {

		let customerAddress = '';
		if (customerDetail.mAddress1) {
			customerAddress += `${customerDetail.mAddress1}`;
		}
		if (customerDetail.mAddress2) {
			customerAddress += `,${customerDetail.mAddress1}`;
		}
		if (customerDetail.mAddress3) {
			customerAddress += `,${customerDetail.mAddress1}`;
		}
		if (customerDetail.mPostcode) {
			customerAddress += `,${customerDetail.mPostcode.code}`;
		}
		if (customerDetail.mCity) {
			customerAddress += `,${customerDetail.mCity.name}`;
		}
		if (customerDetail.mState) {
			customerAddress += `,${customerDetail.mState.name}`;
		}
		if (customerDetail.mCountry) {
			customerAddress += `,${customerDetail.mCountry.name}`;
		}
		return customerAddress.length ? customerAddress : null
	}

	static async searchV2(customerId, companyId) {

		// const code = 'CUSTOMER';
		// return await this.getTopicCode(code)

		let customerRes1 = await this.getCustomerV2(customerId);

		const sameGroupCompanyIds = await this.getSameGroupCompanyIds(companyId);

		/** customerdetails */
		const customerDetailsRes = await this.getCustomerDetails(customerId, sameGroupCompanyIds); // only get customerdetail with same group company
		let customerDetailsData = customerDetailsRes && customerDetailsRes.length ? customerDetailsRes[0] : null;

		if (customerDetailsData) { // show if same Dealer Group
			const getSameParentCompanyIds = await this.getSameParentCompanyIds(companyId);

			/** customerFinances */
			const customerFinanceRes = await this.getCustomerFinance(customerId, getSameParentCompanyIds) // only get customerFinance with same parent
			/** customerPDPA */
			const customerPdpaRes = await this.getCustomerPdpa(customerId, getSameParentCompanyIds) // only get customerFinance with same parent

			customerDetailsData['customerFinances'] = customerFinanceRes;
			customerDetailsData.dataValues['customerFinances'] = customerFinanceRes;

			const existingCustomerPdpa = this.getExistingCustomerPdpa(customerDetailsData);
			customerDetailsData['customerPdpa'] = customerPdpaRes || existingCustomerPdpa;
			customerDetailsData.dataValues['customerPdpa'] = customerPdpaRes || existingCustomerPdpa;

			const additional = await this.getAdditional(customerId);
			customerDetailsData['customerRemarks'] = _.get(additional, 'customerRemarks');
			customerDetailsData.dataValues['customerRemarks'] = _.get(additional, 'customerRemarks');
			customerDetailsData['customerTags'] = _.get(additional, 'customerTags');
			customerDetailsData.dataValues['customerTags'] = _.get(additional, 'customerTags');

			customerRes1[0]['customerDetails'] = customerDetailsData;
			customerRes1[0].dataValues['customerDetails'] = customerDetailsData;


		}

		return customerRes1[0];

	}

	static getExistingCustomerPdpa(customerDetailsData) {

		const pdpaKeys = [
			'customerId',
			'companyId',
			'isFullConsent',
			'isPartialConsent',
			'consentA',
			'consentB',
			'consentC',
			'consentD',
			'consentE',
			'consentF',
			'consentG',
			'consentH',
			'consentI',
			'consentJ',
			'pdpaConsent',
			'pdpaClause',
			'pdpaSignedDate',
		]
		if (customerDetailsData) {
			return _.pick(customerDetailsData, pdpaKeys)
		}

		return null;

	}

	static async getCustomerV2(customerId) {
		const filter = [{ colId: 'id', text: [customerId] }];
		const commonAttr = [
			'id',
			'code',
			'name',
		];
		const customInclude = [{
			model: CustomerMaster.CustomerAccountGroup,
			attributes: commonAttr,
		},
		{
			model: GeneralMaster.Salutation,
			attributes: commonAttr,
		},
		{
			model: GeneralMaster.Country,
			attributes: commonAttr,
		},
		{
			model: GeneralMaster.Region,
			attributes: commonAttr,
		},
		{
			model: GeneralMaster.Identity,
			attributes: commonAttr,
		}
		];

		return await CustomerModel.searchAll([], null, {}, ['updatedAt', 'desc'], filter, true, false, true, customInclude);
	}

	static async getCustomerDetails(customerId, sameGroupCompanyIds) {
		const commonAttr = [
			'id',
			'code',
			'name',
		];

		const filter4 = [
			{ colId: 'customerId', text: [customerId] },
			{ colId: 'companyId', text: sameGroupCompanyIds }
		]
		const pagination = {
			limit: 1,
			offset: 0,
		} /** get first record, which is latest update */
		return CustomerDetailsModel.searchAll([], null, pagination, ['updatedAt', 'desc'], filter4, true, false, true, [
			// {
			//     model: CustomerMaster.CustomerFinance,
			//     include:[
			//         {model:CustomerMaster.PaymentTerms},
			//         {model:CustomerMaster.CustomerGroup},
			//         {model:CustomerMaster.TaxClass}
			//     ]
			// },
			{
				model: CustomerMaster.CustomerContact,
				include: [{ model: GeneralMaster.Salutation, attributes: commonAttr },
				{ model: CustomerMaster.ContactRelationship, attributes: commonAttr }
				]
			},
			{
				model: CustomerMaster.CustomerCorrespondenceAddress
			},
			// {
			//     model: CustomerMaster.CustomerRemarks
			// },
			// {
			//     model: CustomerMaster.CustomerTags
			// },
			{
				model: GeneralMaster.PostCode,
				attributes: ['id', 'code'],
				as: 'cPostcode'
			},
			{
				model: GeneralMaster.AreaOperatorCode,
				attributes: ['id', 'code'],
				as: 'areaOperatorCode'

			},
			{
				model: GeneralMaster.City,
				attributes: commonAttr,
				as: 'cCity'
			},
			{
				model: GeneralMaster.State,
				attributes: commonAttr,
				as: 'cState'
			},
			{
				model: GeneralMaster.Country,
				attributes: commonAttr,
				as: 'cCountry'
			},
			{
				model: GeneralMaster.PostCode,
				attributes: ['id', 'code'],
				as: 'mPostcode'
			},
			{
				model: GeneralMaster.City,
				attributes: commonAttr,
				as: 'mCity'
			},
			{
				model: GeneralMaster.State,
				attributes: commonAttr,
				as: 'mState'
			},
			{
				model: GeneralMaster.Country,
				attributes: commonAttr,
				as: 'mCountry'
			},
			{
				model: CustomerMaster.Company,
				attributes: commonAttr
			}
		]);

	}

	static async getCustomerFinance(customerId, companyIds) {
		const filter2 = [
			{ colId: 'customerId', text: [customerId] }, { colId: 'companyId', text: companyIds }
		];
		return await CustomerMaster.CustomerFinance.searchAll([], null, {}, ['updatedAt', 'desc'], filter2, true, false, true,
			[
				{ model: CustomerMaster.PaymentTerms },
				{ model: CustomerMaster.CustomerGroup },
				{ model: CustomerMaster.TaxClass }
			]
		)
	}

	static async getCustomerPdpa(customerId, companyIds) {
		const filter2 = [
			{ colId: 'customerId', text: [customerId] }, { colId: 'companyId', text: companyIds }
		];

		const res = await CustomerMaster.CustomerPdpa.searchAll([], null, {}, ['updatedAt', 'desc'], filter2, true, false, true);

		return res && res.length ? res[0] : null;
	}

	static async getAdditional(customerId) { // customerTags and customerRemarks
		const filter4 = [
			{ colId: 'customerId', text: [customerId] }
		]
		const pagination = {
			limit: null,
			offset: 0,
		}
		const attr = ['id']
		const CustomerDetailsRes = await CustomerMaster.CustomerDetails.searchAll([], attr, pagination, ['updatedAt', 'desc'], filter4, true, false, true);
		if (CustomerDetailsRes && CustomerDetailsRes.length) {
			let customerDetailsIds = [];
			customerDetailsIds = CustomerDetailsRes.map((c) => c.id);
			customerDetailsIds = _.uniq(customerDetailsIds);
			const filter2 = [
				{ colId: 'customerDetailsId', text: customerDetailsIds }
			];
			const customerTags = await CustomerMaster.CustomerTags.searchAll([], null, {}, ['updatedAt', 'desc'], filter2, true, false, true);
			const customerRemarks = await CustomerMaster.CustomerRemarks.searchAll([], null, {}, ['updatedAt', 'desc'], filter2, true, false, true);
			return {
				customerRemarks,
				customerTags
			}
		}
		return null;
	}

	static async getSameGroupCompanyIds(companyId) {

		const filter2 = [{ colId: 'id', text: [companyId] }];
		const attr2 = ['id', 'dealerGroupId']
		let customerRes2 = await CustomerMaster.Company.searchAll([], attr2, {}, ['updatedAt', 'desc'], filter2, true, false, true);

		if (!(customerRes2 && customerRes2.length)) {
			throw {
				status: 400,
				code: "COMPANY_ERROR",
				message: "Tenant Company Error. Please set tenant company to proceed."
			};
		}
		if (!customerRes2[0].dealerGroupId) {
			throw {
				status: 400,
				code: "DEALERGROUP_ERROR",
				message: "Dealer group is not set for this company. Please set dealer group to proceed."
			};
		}

		const filter3 = [{ colId: 'dealerGroupId', text: [customerRes2[0].dealerGroupId] }];
		let customerRes3 = await CustomerMaster.Company.searchAll([], ['id'], {}, ['updatedAt', 'desc'], filter3, true, false, true);

		return customerRes3.map((c) => c.id);

	}


	/** ---------------------------------------------------- */

	static async getSameParentCompanyIds(companyId) {
		const token = null;
		let filterCompany = [{
			colId: 'branchId',
			text: [companyId]
		}]
		const checkbranch = await CustomerMaster.CompanyBranch.searchAll([], ['id', 'companyId', 'branchId'], { limit: 1, offset: 0 }, ['companyId', 'asc'], filterCompany, true, false, true);

		const companyFound = checkbranch.length ? checkbranch[0].companyId : companyId;
		const companyList = await this.processCompanyTree(token, null, companyFound); // get All company to compute view type

		return companyList.map((c) => c.childId);
	}

	/**
			 * process hq/company/dealer view
			 */
	static async processCompanyTree(token, hqId = null, entityId = null) {
		const attr = ['id', 'code', 'name', 'parentCompanyId', 'makeIds'];
		let res = await CustomerMaster.Company.searchAll([], attr, { limit: null, offset: 0 }, ['updatedAt', 'desc'], [], true, false, true);
		// return res
		const newRes = _.map(res, (v, k) => {
			let viewType = 'company';
			if (!v.parentCompanyId) {
				viewType = 'hq'
			}
			const makeIds = Utils.isJsonString(v.makeIds) ? JSON.parse(v.makeIds) : [v.makeIds];
			return {
				name: v.name,
				parentId: v.parentCompanyId,
				childId: v.id,
				viewType,
				makeIds: !v.parentCompanyId && v.makeIds ? makeIds : null
			}
		});
		const getCompany = newRes.filter((c) => c.viewType === 'company');
		newRes.forEach((n) => {
			if (getCompany.find((c) => c.childId === n.parentId)) {
				n.viewType = 'dealer'
			}
		})

		if (entityId) {
			const getEntityObj = newRes.find((c) => c.childId === entityId);
			if (!getEntityObj) {
				return []; // is branch because not found in company table
			} else {
				var parentId = getEntityObj.parentId, counter = 0, getHq;
				if (parentId) { // if not hq (hq will have parentId null)
					while (parentId) { // loop to gethq
						counter = 0;
						for (counter; counter < newRes.length; counter++) {
							if (newRes[counter].childId == parentId) {
								parentId = newRes[counter].parentId;
								getHq = newRes[counter];
							}
						}
					}
					hqId = getHq.childId;
				} else {
					hqId = entityId;
				}
			}

		} // reason to get hqId so only return tree from main hq

		const arrtemp = this.treeify(newRes, hqId); // to get children
		const objList = this.flat(arrtemp);
		// return objList
		const newArr = _.map(objList, (obj) => {
			const nObj = { ...obj };
			nObj.hasChild = nObj.children.length > 0
			return nObj; //_.omit(obj,["children"]);
		})
		return newArr;
	}

	static treeify(list, hqId = null) {
		var treeList = [];
		var lookup = {};
		list.forEach((obj) => {
			lookup[obj.childId] = obj;
			lookup[obj.childId].children = [];
		});
		list.forEach((obj) => {
			if (obj.parentId != null && lookup[obj.parentId]) {
				lookup[obj.parentId].children.push(obj);
			} else {
				treeList.push(obj);
			}
		});
		if (hqId) {
			return _.filter(treeList, (rr) => {
				return rr.childId == hqId;
			})
		}
		return treeList;
	}

	/** flatten nested array. ref: https://stackoverflow.com/a/35273005 */
	static flat(array) {
		var result = [];
		let self = this;
		array.forEach(function (a) {
			result.push(a);
			if (Array.isArray(a.children)) {
				result = result.concat(self.flat(a.children));
			}
		});
		return result;
	}

	/** ---------------------------------------------------- */


	static async getAll(page) {
		const pagination = {
			limit: page.limit,
			offset: page.limit * (page.page - 1),
		}
		let q = {};
		let attr = null;
		return {
			...await CustomerModel.getAll(q, attr, pagination, page.order),
			page: page.page,
			limit: page.limit
		};
	}

	static async addCustomer(customerObjArr, topicCode, who, headers) {

		// return {customer: customerObjArr, topicCode};
		const validCustObj = await this.validateAddCustObj(customerObjArr);

		if (validCustObj && validCustObj.length > 0) {

			for (let y = 0; y < validCustObj.length; y++) {
				let custObj = validCustObj[y];
				if (!custObj.id) {
					const custCode = await this.getGenerateCode(topicCode, headers).catch((error) => { console.log(error); });
					if (custCode) {
						custObj['id'] = custCode;
					}
				}
			}

			return CustomerModel.sequelize.transaction((t) => {
				var promises = [];
				_.forEach(validCustObj, (addCustomerObj) => {
					addCustomerObj['createdBy'] = who;
					addCustomerObj['updatedBy'] = who;
					const p = CustomerModel.addNew(addCustomerObj, t);
					promises.push(p);
				});
				return Promise.all(promises);
			});
		}
	}

	static async addCustomerV2(payload, who) {
		//const custCompIdTemp = payload.customer[0].companyId; 
		const custCompIdTemp = payload.customer && payload.customer.length > 0 && payload.customer[0].companyId ? payload.customer[0].companyId : null;
		const customerObj = payload.customer[0];
		const topicCode = payload.topicCode;
		const validCustObj = await this.validateAddCustObj([customerObj]);
		// return validCustObj

		let custObj = validCustObj[0], topicRes, custCode;
		if (!custObj.id) {
			topicRes = await this.getTopicCode(topicCode).catch((error) => { throw (error); }); // GET CURRENT, DONT UPDATE YET
			custCode = topicRes.prefix + String(topicRes.currentNumber);
			if (custCode) {
				custObj['id'] = custCode;
			}
		}
		let custDetail, custDetailsId, addedCust;
		await CustomerModel.sequelize.transaction(async (t) => {
			const addCustomerObj = validCustObj[0];
			addCustomerObj['createdBy'] = who;
			addCustomerObj['updatedBy'] = who;
			addedCust = await CustomerModel.addNew(addCustomerObj, t);

			if (addedCust) {
				let promises = [];
				/** CustomerDetails */
				const customerData = payload.customerDetails;
				customerData['customerId'] = custCode;
				customerData['createdBy'] = who;
				customerData['updatedBy'] = who;
				customerData['localLangaugeName'] = customerObj.localLangaugeName ? customerObj.localLangaugeName : null;
				customerData['localLangaugeAddress'] = customerData.localLangaugeAddress ? customerObj.localLangaugeName : null;
				const addedCustDetail = await CustomerMaster.CustomerDetails.addNew(customerData, t);
				custDetailsId = addedCustDetail.id;

				/** CustomerCorrespondenceAddress */
				const correspondenceAddressesData = _.get(payload, 'customerDetails.correspondenceAddresses');
				if (correspondenceAddressesData && correspondenceAddressesData.length) {
					_.forEach(correspondenceAddressesData, (addObj) => {
						addObj['createdBy'] = who;
						addObj['updatedBy'] = who;
						addObj['customerDetailsId'] = custDetailsId;
					});
					const p = CustomerMaster.CustomerCorrespondenceAddress.bulkCreate(correspondenceAddressesData, { returning: true, transaction: t })
					promises.push(p)
				}

				/** CustomerFinance */
				const customerFinanceData = payload.customerFinance;
				customerFinanceData['customerGroupId'] = _.get(payload, 'customerFinance.customerGroupId', ''); // empty string if null
				customerFinanceData['customerId'] = custCode;
				// customerFinanceData['customerDetailsId'] = custDetailsId;
				customerFinanceData['createdBy'] = who;
				customerFinanceData['updatedBy'] = who;
				await CustomerMaster.CustomerFinance.addNew(customerFinanceData, t);

				/** CustomerPdpa */
				const customerPdpaData = payload.customerPdpa;
				customerPdpaData['customerId'] = custCode;
				customerPdpaData['createdBy'] = who;
				customerPdpaData['updatedBy'] = who;
				await CustomerMaster.CustomerPdpa.addNew(customerPdpaData, t);

				/** CustomerContact */
				const customerContactData = payload.customerContacts;
				if (customerContactData && customerContactData.customerContact && customerContactData.customerContact.length) {
					_.forEach(customerContactData.customerContact, (addObj) => {
						addObj['customerId'] = custCode;
						addObj['customerDetailsId'] = custDetailsId;
						addObj['createdBy'] = who;
						addObj['updatedBy'] = who;
					});
					const p = CustomerMaster.CustomerContact.bulkCreate(customerContactData.customerContact, { returning: true, transaction: t })
					promises.push(p)
				}
				/** CustomerTag */
				const customerTagData = payload.customerTags;
				if (customerTagData && customerTagData.customerTag && customerTagData.customerTag.length) {
					_.forEach(customerTagData.customerTag, (addObj) => {
						addObj['customerDetailsId'] = custDetailsId;
						addObj['createdBy'] = who;
						addObj['updatedBy'] = who;
					});
					const p = CustomerMaster.CustomerTags.bulkCreate(customerTagData.customerTag, { returning: true, transaction: t })
					promises.push(p)
				}
				/** CustomerRemark */
				const custRemarkData = payload.customerRemarks;
				if (custRemarkData && custRemarkData.customerRemark && custRemarkData.customerRemark.length) {
					_.forEach(custRemarkData.customerRemark, (addObj) => {
						addObj['customerDetailsId'] = custDetailsId;
						addObj['createdBy'] = who;
						addObj['updatedBy'] = who;
					});
					const p = CustomerMaster.CustomerRemarks.bulkCreate(custRemarkData.customerRemark, { returning: true, transaction: t })
					promises.push(p)
				}
				await Promise.all(promises);
			}

		});
		if (custDetailsId) {
			let filterCustDetail = [{ colId: 'id', text: [custDetailsId] }];

			const custDetailRes = await CustomerDetailsModel.searchAll([], null, { limit: 1, offset: 0 }, ["createdAt", "desc"], filterCustDetail, false, false, true);
			custDetail = custDetailRes[0];
			custDetail['financeGroupId'] = _.get(payload, 'customerFinance.customerGroupId', '');
			custDetail['contactName'] = _.get(payload, 'customerContacts.customerContact[0].name', '');
			custDetail['isNewInsert'] = true;

			// Lee Qi Rui request change. overwrite company id when sending to kafka
			// Bug: detect empty/null for value custObj.companyId, add try catch during calling kafka
			//custDetail['companyId'] = custObj.companyId;
			//let foundComp = await CompanyModel.getId({ id: custObj.companyId });
			//custDetail['company'] = _.pick(foundComp, ['id', 'code', 'name']);
			//await customerDetailsFunctions.navisionCustomerHistory(custDetail, who);
			try {
				let tempCustCompId;
				if (custObj.companyId) {
					tempCustCompId = custObj.companyId;
				}
				else {
					tempCustCompId = custCompIdTemp
				}
				custDetail['companyId'] = tempCustCompId;
				let foundComp = await CompanyModel.getId({ id: tempCustCompId });
				custDetail['company'] = _.pick(foundComp, ['id', 'code', 'name']);
				await customerDetailsFunctions.navisionCustomerHistory(custDetail, who);
			}
			catch (error) {
				console.error(error);
			}
		}
		await this.updateTopicCode(topicRes.id, topicRes.currentNumber); // updateTopicCode after all successful

		return addedCust;
	}

	static async getTopicCode(code) {
		const where = { code, deleted: false, status: Status.ENABLED };
		return GeneralMaster.TopicSeries.getOne(where).then((existingRecord) => {

			if (!existingRecord) {
				throw errorDef.NOT_FOUND;
			}

			if (!existingRecord.currentNumber) {
				existingRecord.currentNumber = existingRecord.startNumber;
			}

			const numberLength = existingRecord.currentNumber.length;
			let incrementedNumber = (+existingRecord.currentNumber) + 1;
			incrementedNumber = Utils.leadingZeros(incrementedNumber, numberLength);

			return { id: existingRecord.id, currentNumber: incrementedNumber, prefix: existingRecord.prefix };
		})
	}

	static async updateTopicCode(topicId, incrementedNumber) {
		const payload = { currentNumber: incrementedNumber };
		const where = { id: topicId }
		return GeneralMaster.TopicSeries.sequelize.transaction(async (transaction) => {
			return GeneralMaster.TopicSeries.updateRecord(payload, where, transaction).then((updated) => {
				if (updated) {
					return GeneralMaster.TopicSeries.getOne(where, transaction).then((newRecord) => {
						if (newRecord.prefix !== null && newRecord.prefix !== "") {
							return newRecord.prefix + newRecord.currentNumber;
						} else {
							if (customizedPrefix !== null && customizedPrefix !== "") {
								return customizedPrefix + newRecord.currentNumber;
							} else {
								return newRecord.currentNumber;
							}
						}
					});
				}
				throw errorDef.UPDATE_FAILED;
			});
		});

	}

	static async validateAddCustObj(customerObjArr) {
		if (!_.isEmpty(customerObjArr)) {
			for (let x = 0; x < customerObjArr.length; x++) {
				let customerObj = customerObjArr[x];
				let queryCust = await CustomerModel.getId({ identityId: customerObj.identityId, identityNo: customerObj.identityNo }).catch(err => {
					console.log(err);
				});

				if (queryCust) {
					throw errorDef.NOT_UNIQUE;
				} else {
					delete customerObj.companyId; // why delete companyId ?
				}
			}
		}
		return customerObjArr;
	}

	static async validateCustObj(customerObjArr) {
		// let promises0 = [];
		if (!_.isEmpty(customerObjArr)) {
			for (let x = 0; x < customerObjArr.length; x++) {
				let customerObj = customerObjArr[x];
				let queryCust = await CustomerModel.getId({ identityId: customerObj.identityId, identityNo: customerObj.identityNo }).catch(err => {
					console.log(err);
				});

				if (queryCust && queryCust.id) {
					if (queryCust.id !== customerObj.id) {
						throw errorDef.NOT_UNIQUE;
					} else {
						if (_.size(queryCust.id) === 36) {  // is UUID
							customerObj['oldId'] = queryCust.id;
							delete customerObj.id;
						} else {
							customerObj['id'] = queryCust.id;
						}
						delete customerObj.companyId;
					}

				} else {
					if (customerObj.id !== undefined) {
						if (_.size(customerObj.id) === 36) {  // is UUID
							customerObj['oldId'] = customerObj.id;
							delete customerObj.id;
						}
					}
					delete customerObj.companyId;
				}

				// return await CustomerDetailsModel.getId({
				//     customerId: c.id
				// }).then((r) => {
				//     if(r && r.companyId === customerObj.companyId) {
				//         throw errorDef.NOT_UNIQUE;  
				//     } 
				//     delete customerObj.companyId;
				//     return customerObj;
				// }).catch((e) => e);
				//if(customerObj.id && c.id === customerObj.id) {
			}
		}


		// return Promise.all(promises0);
		return customerObjArr;
	}

	// Get Generate Code
	static async getGenerateCode(code, headers) {
		return topicSeries.generateSeries(code, headers).then((s) => {
			return s;
		}).catch(function (err) {
			if (err.name == 'RequestError') {
				return Promise.reject(err);
			}
			return topicSeries.addCode(headers.authorization, code).then((res) => {
				if (res) {
					return topicSeries.generateSeries(code, headers).then((s) => {
						return s;
					}).catch(function (err) {
						return Promise.reject(err);
					})
				} else {
					return Promise.reject();
				}
			}).catch(function (err) {
				return Promise.reject(err);
			})
		});
	}
	// static async getGenerateMultipleCode(code, headers, howMany) {
	//     return topicSeries.generateMultipleSeries(code, headers, howMany).then((s) => {
	//         if (s.status && s.code && s.message) {
	//             return Promise.reject(s);
	//         } else {
	//             return s;
	//         }

	//     }).catch(function (err) {
	//         return Promise.reject(err);
	//     });
	// }


	static async updateCustomer(customer, where, who, headers) {
		customer['updatedBy'] = who;
		customer['id'] = where.id;

		const validCustObj = await this.validateCustObj([customer]);

		let promises = [];
		if (validCustObj && validCustObj.length > 0) {

			for (let c = 0; c < validCustObj.length; c++) {
				let custObj = validCustObj[c];
				if (custObj.id) {
					await CustomerModel.updateCustomer(custObj, { id: custObj.id });
					promises.push(CustomerModel.getId({ id: custObj.id }));
				} else {
					let topicCode;
					let filterCag = [{ colId: 'id', text: [custObj.customerAccountGroupId] }];
					let queryCag = await CustomerAccountGroupModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterCag, true, false, true);
					if (queryCag && !_.isEmpty(queryCag)) {
						topicCode = queryCag[0].topicCode;
					}

					if (topicCode) {
						const custCode = await this.getGenerateCode(topicCode, headers).catch((error) => { console.log(error); });
						if (custCode) {
							custObj['id'] = custCode;
						}
						custObj['updatedBy'] = who;
						await CustomerModel.updateCustomer(custObj, { id: custObj.oldId });
						promises.push(CustomerModel.getId({ id: custObj.id }));
					}

				}
			}
		}

		return Promise.all(promises);
	}

	static async updateCustomerV2(payload, who, headers) {
		const customer = payload.customer;
		const companyId = _.cloneDeep(payload.customer.companyId);

		customer['updatedBy'] = who;
		customer['id'] = payload.id;

		const validCustObj = await this.validateCustObj([customer]);

		let resp;
		if (validCustObj && validCustObj.length > 0 && validCustObj[0].id) {
			let custObj = validCustObj[0];
			await CustomerModel.updateCustomer(custObj, { id: custObj.id });
			resp = await CustomerModel.getId({ id: custObj.id });

			let promises = [];
			if (resp) {
				let customerId = resp.id, customerDetailsId;

				/** customerDetails */
				const customerData = payload.customerDetails;
				customerData['customerId'] = customerId;
				customerData['financeGroupId'] = _.get(payload, 'customerFinance.customerGroupId', '');
				customerData['contactName'] = _.get(payload, 'customerContacts.customerContact[0].name', '');

				customerData['tenantCompanyId'] = companyId;
				customerData['localLangaugeName'] = customer.localLangaugeName ? customer.localLangaugeName : null;
				customerData['localLangaugeAddress'] = customerData.localLangaugeAddress ? customerData.localLangaugeAddress : null;

				customerDetailsId = _.get(customerData, 'id');
				const whereCustomerDetails = { id: customerDetailsId }
				promises.push(customerDetailsFunctions.updateCustomerDetails(customerData, whereCustomerDetails, who));
				promises.push(customerDetailsFunctions.updateCustomerCorrespondenceAddrs(customerData, whereCustomerDetails, who))

				const {
					customerFinance: custFinanceData,
					customerPdpa: custPdpaData,
					customerContacts: custContactData,
					customerTags: custTagData,
					customerRemarks: custRemarkData,
				} = payload;

				/** customerFinance */
				if (custFinanceData) {
					custFinanceData['customerGroupId'] = _.get(payload, 'customerFinance.customerGroupId', ''); // empty string if null
					custFinanceData['customerId'] = customerId;
					delete custFinanceData.customerDetailsId;
					// custFinanceData['customerDetailsId'] = customerDetailsId;
					const paramCustFinance = [custFinanceData, { id: custFinanceData.id }, who];
					promises.push(customerFinanceFunctions.updateCustomerFinance(...paramCustFinance));
				}

				/** customerPdpa */
				if (custPdpaData) {
					custPdpaData['customerId'] = customerId;
					const paramCustPdpa = [custPdpaData, { id: custPdpaData.id }, who];
					promises.push(customerPdpaFunctions.updateCustomerPdpa(...paramCustPdpa));
				}

				/** customerContact */
				if (custContactData) {
					_.forEach(custContactData.customerContact, (obj) => {
						obj['customerDetailsId'] = customerDetailsId;
					});
					let detailIdOrDeleted1 = custContactData.deletedContacts !== undefined ? custContactData.deletedContacts : customerDetailsId;
					const paramCustContact = [detailIdOrDeleted1, custContactData.customerContact, who];
					promises.push(customerContactFunctions.groupUpdateCustomerContactV2(...paramCustContact));
				}

				/** customerTag */
				if (custTagData) {
					_.forEach(custTagData.customerTag, (obj) => {
						obj['customerDetailsId'] = customerDetailsId;
					});
					let detailIdOrDeleted3 = custTagData.deletedTags !== undefined ? custTagData.deletedTags : customerDetailsId;
					const paramCustTag = [detailIdOrDeleted3, custTagData.customerTag, who];
					promises.push(customerTagsFunctions.groupUpdateCustomerTag(...paramCustTag));
				}

				/** customerRemark */
				if (custRemarkData) {
					_.forEach(custRemarkData.customerRemark, (obj) => {
						obj['customerDetailsId'] = customerDetailsId;
					});
					let detailIdOrDeleted2 = custRemarkData.deletedRemarks !== undefined ? custRemarkData.deletedRemarks : customerDetailsId;
					const paramCustRemark = [detailIdOrDeleted2, custRemarkData.customerRemark, who];
					promises.push(customerRemarksFunctions.groupUpdateCustomerRemark(...paramCustRemark));
				}

				await Promise.all(promises);
			}

		}

		// after update success, update vehicleservice // no longer use elasticsearch
		/*
		let filterCustVehRelationship = [{ colId: 'customerId', text: [customer.id] }];
		let CustVehRelationshipRes = await SpecMaster.CustomerVehicleRelation.searchAll([], ['id', 'customerId', 'vehicleId', 'updatedAt'], {}, ["updatedAt", "desc"], filterCustVehRelationship, true, false, true);
		let vehIds = CustVehRelationshipRes.map((r) => r.vehicleId);
		vehIds = vehIds ? _.uniq(vehIds) : [];
		if (vehIds.length) {
				await elasticSearchVehicle.updateDataByIds(vehicleFunctions, vehIds, headers).catch(err => console.error(err));
		}
		*/

		return resp;
	}

	static async deleteCustomer(where, who, type = "soft") {
		if (type == "soft") {
			return await CustomerModel.deleteSoft(where, who).then(() => {
				return CustomerModel.getAll(where, null).then((resp) => {
					return resp;
				});
			});
		} else if (type == "hard") {
			return await CustomerModel.deleteHard(where).then((resp) => {
				if (!resp) {
					return resp;
				} else {
					return where;
				}
			});
		}
	}

	static async getAuthInfo(result, headers) {
		let internalUserIds = this.extractInternalUserIds(result);

		let searchUsersData = [];
		searchUsersData.push({
			cacheKey: "internal_users",
			search: [{ colId: 'id', text: internalUserIds }],
			attributes: ['id', 'employeeId', 'fullName', 'updatedAt'],
			skipInclude: true
		});
		let queryAuthCacheRes = await authCache.getCacheByQuery(searchUsersData, headers.authorization);

		let salutationRelationshipIds = this.extractSalutationNRelationshipIds(result);
		let searchSalutationData = [];
		searchSalutationData.push({
			masterdata: 'salutation',
			search: [{ colId: 'id', text: salutationRelationshipIds[0] }],
			attributes: ['id', 'code', 'name', 'updatedAt'],
			skipInclude: true
		});
		let queryGeneralCacheRes = await generalCache.getMasterDataByQuery(searchSalutationData, headers.authorization);

		let filterContactRelationship = [{ colId: "id", text: salutationRelationshipIds[1] }];
		let queryContactRelationships = await ContactRelationship.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ["updatedAt", "desc"], filterContactRelationship, true, false, true);

		return this.modifyRowValues(
			result,
			queryAuthCacheRes && queryAuthCacheRes.internal_users ? queryAuthCacheRes.internal_users : [],
			queryGeneralCacheRes && queryGeneralCacheRes.salutation ? queryGeneralCacheRes.salutation : [],
			queryContactRelationships && _.size(queryContactRelationships) > 0 ? queryContactRelationships : []
		);
	}

	static modifyRowValues(finalResponse, rInternalUsers = [], rSalutations = [], rRelationships = []) {
		_.forEach(finalResponse.rows, (row) => {
			let foundUpdatedBy = _.find(rInternalUsers, (o) => { return o.id === row.updatedBy; });
			row['updatedByName'] = foundUpdatedBy ? foundUpdatedBy.fullName : null;
			let foundCreatedBy = _.find(rInternalUsers, (o) => { return o.id === row.createdBy; });
			row['createdByName'] = foundCreatedBy ? foundCreatedBy.fullName : null;

			_.forEach(row['customerDetails'], (row2) => {
				_.forEach(row2['customerContacts'], (row3) => {
					let foundSalutation = _.find(rSalutations, (o) => { return o.id === row3.salutationId; });
					row3['salutation'] = foundSalutation ? foundSalutation : null;
					let foundRelationship = _.find(rRelationships, (o) => { return o.id === row3.relationshipId; });
					row3['relationship'] = foundRelationship ? foundRelationship : null;
				});
			});
		});
		return finalResponse;
	}

	static extractInternalUserIds(finalResponse) {
		let results = [];
		_.forEach(finalResponse.rows, (row) => {
			if (row['updatedBy']) {
				results.push(row['updatedBy']);
			}
			if (row['createdBy']) {
				results.push(row['createdBy']);
			}
		});
		return _.uniq(results);
	}

	static extractSalutationNRelationshipIds(finalResponse) {
		let results = [];
		let results2 = [];
		_.forEach(finalResponse.rows, (row) => {
			_.forEach(row['customerDetails'], (row2) => {
				_.forEach(row2['customerContacts'], (row3) => {
					if (row3.salutationId) {
						results.push(row3.salutationId);
					}
					if (row3.relationshipId) {
						results2.push(row3.relationshipId);
					}
				});
			});
		});
		return [_.uniq(results), _.uniq(results2)];
	}

	static async updateCustomerProfile(customer, removedCusLocationIdList) {
		// .cusOtherSalutation
		// .race
		// .customerTypeCode
		// .internetAccess
		// .firstLanguagePreference
		// .secondLanguagePreference
		// .remarks
		// .isExcludeFromTax
		// .isNonEditable
		// .navCustType
		// .navdebtorCode
		// .isPosted
		// .cmsCustCode
		// .isInsertToTemp
		// .isOnDebtorControl
		// .creditLimitBlockedBy
		// .isBreachReminded1
		// .isBreachReminded2
		// .gststatusLastCheckedDate
		// .virtualBankAccountNo
		// .gstpostingGroup
		// .gstidno

		let where = { id: customer.cusId };

		let salutationId = null;
		if (customer.cusSalutation) {
			let searchSalutation = [{ colId: 'name', text: [customer.cusSalutation.toUpperCase()] }];
			let salutationRes = await SalutationModel.searchAll(searchSalutation, null, {}, ['updatedAt', 'desc'], [], true, false, true, [], null, null, true);
			let salutations = salutationRes ? _.map(salutationRes, 'dataValues') : [];
			if (!_.isEmpty(salutations)) {
				salutationId = salutations[0].id;
			}
		}

		let name = customer.cusName ? customer.cusName : null;
		let identityNo = customer.customerIdno ? customer.customerIdno : null;

		let identityId = null;
		if (customer.customerIdtypeCode) {
			let searchIdentity = [{ colId: 'code', text: [customer.customerIdtypeCode.toUpperCase()] }];
			let identityRes = await IdentityModel.searchAll(searchIdentity, null, {}, ['updatedAt', 'desc'], [], true, false, true, [], null, null, true);
			let identities = identityRes ? _.map(identityRes, 'dataValues') : [];
			if (!_.isEmpty(identities)) {
				identityId = identities[0].id;
			}
		}

		await CustomerModel.updateCustomer({
			salutationId,
			name,
			identityNo,
			identityId
		}, where);


		let isNeedSpecialAttention = customer.needAttention ? customer.needAttention : false;

		let highestEducationId = null;
		if (customer.highestEducation) {
			let searchEducation = [{ colId: 'name', text: [customer.highestEducation.toUpperCase()] }];
			let eduRes = await EducationModel.searchAll(searchEducation, null, {}, ['updatedAt', 'desc'], [], true, false, true, [], null, null, true);
			let educations = eduRes ? _.map(eduRes, 'dataValues') : [];
			if (!_.isEmpty(educations)) {
				highestEducationId = educations[0].id;
			}
		}

		let receiveSMS = customer.isReceiveSms ? customer.isReceiveSms : false;
		let isVehicleCollectionSMS = customer.isReceiveVehColSms ? customer.isReceiveVehColSms : false;
		let isServiceReminderSMS = customer.isReceiveSvcRmdSms ? customer.isReceiveSvcRmdSms : false;
		let isCampaignSMS = customer.isReceiveCmpSms ? customer.isReceiveCmpSms : false;

		let gender = null
		if (customer.gender) {
			gender = customer.gender.toLowerCase() === 'male' ? '1' : '2';
		}

		await CustomerDetailsModel.updateCustomerDetails({
			isNeedSpecialAttention,
			highestEducationId,
			receiveSMS,
			isVehicleCollectionSMS,
			isServiceReminderSMS,
			isCampaignSMS,
			gender
		}, { customerId: customer.cusId });


		let paymentTermsId = null;
		if (customer.paymentterm) {
			let searchPayterm = [{ colId: 'code', text: [String(customer.paymentterm).toUpperCase()] }];
			let paymentTermRes = await PaymentTermModel.searchAll(searchPayterm, null, {}, ['updatedAt', 'desc'], [], true, false, true, [], null, null, true);
			let terms = paymentTermRes ? _.map(paymentTermRes, 'dataValues') : [];
			if (!_.isEmpty(terms)) {
				paymentTermsId = terms[0].id;
			}
		}

		let creditLimit = customer.creditlimit ? String(customer.creditlimit) : null;

		await CustomerFinanceModel.updateCustomerFinance({
			creditLimit,
			paymentTermsId
		}, { customerId: customer.cusId });


		let customerLocations = customer.customerLocations;
		let loc = customerLocations[0]; // get the first one
		if (loc) {
			// customerLocationId
			// locationId
			// customerCode
			// cusPassword
			// officeTelExt
			// addressId
			// onlineRegTempPassword
			// verificationString
			// isThroughEmail
			// forgetPasswordString
			// cusTelOffice
			let mobile = loc.cusTelHp ? loc.cusTelHp : null;
			let telephone = loc.cusTelHouse ? loc.cusTelHouse : null;
			let fax = loc.cusFax ? loc.cusFax : null;
			let email = loc.cusEmail ? loc.cusEmail : null;

			let mAddress1 = null, mAddress2 = null, mAddress3 = null;
			let mCityId = null, mStateId = null, mCountryId = null, mPostcodeId = null;

			if (loc.address) {
				mAddress1 = loc.address.address1;
				mAddress2 = loc.address.address2;
				mAddress3 = loc.address.address3;

				if (loc.address.city) {
					let foundCity = await CityModel.getId({ code: loc.address.city });
					if (foundCity) {
						mCityId = foundCity.id;
					}
				}

				if (loc.address.stateCode) {
					let foundState = await StateModel.getId({ code: loc.address.stateCode.toUpperCase() });
					if (foundState) {
						mStateId = foundState.id;
					}
				}

				if (loc.address.postcode) {
					let foundPostcode = await PostcodeModel.getId({ code: loc.address.postcode });
					if (foundPostcode) {
						mPostcodeId = foundPostcode.id;
					}
				}

				if (loc.address.countryCode) {
					let foundCountry = await CountryModel.getId({ code: loc.address.countryCode.toUpperCase() });
					if (foundCountry) {
						mCountryId = foundCountry.id;
					}
				}
			}

			await CustomerDetailsModel.updateCustomerDetails({
				mobile,
				telephone,
				fax,
				email,
				mAddress1,
				mAddress2,
				mAddress3,
				mCityId,
				mStateId,
				mCountryId,
				mPostcodeId
			}, { customerId: customer.cusId });

			// loc.contactPerson
			// loc.contactPersonNo
		}

		return true;
	}

	static async getNavInterfaceCustomer(who, customerId, action) {
		const sql = getFunction.getNavInterfaceCustomerSql(customerId, action);

		const sqlgetnav = await GeneralMaster.sequelize.query(sql, { type: Sequelize.QueryTypes.SELECT });
		if (sqlgetnav.length > 0) {

			sqlgetnav.map((data) => {
				data.createdBy = who;
				data.updatedBy = who;
				return data;
			});

			await this.sendDataToNav(sqlgetnav, who);
		}

		return sqlgetnav;
	}


	static async sendDataToNav(dataCV, who) {
		const promiseList = [];
		dataCV.forEach((navisionInputData) => {
			promiseList.push(GeneralMaster.NavisionTceasCustomerDriveIT.addRecord(navisionInputData));
		});
		const navisionResponseData = await Promise.all(promiseList);
		//Send data to Kafka
		kafkaService.sendDataToKafka(
			config.navisionKafka.ip,
			config.navisionKafka.port,
			config.navisionKafka.topic.navisionTceasCustomerDriveIT,
			navisionResponseData,
			async () => {
				const promiseArray = []
				navisionResponseData.forEach((data) => {
					promiseArray.push(
						GeneralMaster.NavisionTceasCustomerDriveIT.updateRecord({ syncStatus: 'success' }, { id: data.id })
					)
				})
				Promise.all(promiseArray)
					.then(() => [])
					.catch(err => console.log(err))
			},
			async () => {
				const arrayPromiseSendToDB = [];
				navisionResponseData.forEach((data) => {
					const navisionCronJob = {
						tableName: 'navisionTceasCustomerDriveIT',
						navisionHistoryId: data.id,
						createdBy: who,
						updatedBy: who,
					};
					arrayPromiseSendToDB.push(
						GeneralMaster.NavisionCRonJobs.addRecord(navisionCronJob)
					)
					Promise.all(arrayPromiseSendToDB)
						.then(() => [])
						.catch(err => console.log(err))
				})

			}
		);
	}

	static async getEnquiryValidation(regNo, icNo) {
		let vehicle = {};
		let foundVhc = await VehicleModel.getOneWithoutInclude({ regNo: regNo });
		if (foundVhc) {
			let filterCvr = [{ colId: 'vehicleId', text: [foundVhc.id] }, { colId: 'status', text: ['assigned'] }];
			let cvrRes = await CustomerVehicleRelationModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterCvr, true, false, true);
			let cvrs = cvrRes ? _.map(cvrRes, 'dataValues') : [];

			let customerLocId = null;
			if (!_.isEmpty(cvrs)) {
				let filtCustDetail = [{ colId: 'customerId', text: [cvrs[0].customerId] }];
				let customerDetailRes = await CustomerDetailsModel.searchAll([], null, {}, ['updatedAt', 'desc'], filtCustDetail, true, false, true);
				let customerDetails = customerDetailRes ? _.map(customerDetailRes, 'dataValues') : [];
				if (!_.isEmpty(customerDetails)) {
					customerLocId = customerDetails[0].id;
				}
			}

			let filterHist = [
				{ colId: 'orderType', text: ['GENERAL REPAIR ORDER'] },
				{ colId: 'vehicleId', text: [foundVhc.id] }
			];
			let vhcSaleServiceHistRes = await VehicleSalesServiceHistoryModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterHist, true, false, true);
			let vhcSaleServiceHists = vhcSaleServiceHistRes ? _.map(vhcSaleServiceHistRes, 'dataValues') : [];

			let filterServiceHistRevamp = [
				{ colId: 'vehicleId', text: [foundVhc.id] }
			];
			let serviceHistRevampRes = await ServiceHistoryRevampModel.searchAll([], null, {}, ['createdAt', 'desc'], filterServiceHistRevamp, true, false, true);
			let serviceHistRevamps = serviceHistRevampRes ? _.map(serviceHistRevampRes, 'dataValues') : [];

			let lastServiceBranch = null, lastServiceDt = null, lastServiceMil = 0;
			if (!_.isEmpty(vhcSaleServiceHists) || !_.isEmpty(serviceHistRevamps)) {
				let serviceHistories = [];
				for (let q = 0; q < _.size(vhcSaleServiceHists); q++) {
					let ssh = vhcSaleServiceHists[q];
					let foundBranch = await BranchModel.getOne({ id: ssh.branchId });
					serviceHistories.push({
						mileage: ssh.mileage ? ssh.mileage : 0,
						serviceDate: ssh.orderDate,
						branchName: foundBranch ? foundBranch.name : null
					});
				}

				_.forEach(serviceHistRevamps, (sh) => {
					serviceHistories.push({
						mileage: sh.mileage ? sh.mileage : 0,
						serviceDate: sh.dateIn,
						branchName: sh.WorkshopName
					});
				});

				serviceHistories = _.orderBy(serviceHistories, ['serviceDate'], ['desc']);
				if (!_.isEmpty(serviceHistories)) {
					lastServiceBranch = serviceHistories[0].branchName;
					lastServiceDt = moment(serviceHistories[0].serviceDate, 'YYYY-MM-DD').format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
					lastServiceMil = serviceHistories[0].mileage;
				}

			}

			let makeName = '', modelName = '';
			if (foundVhc.makeId) {
				let foundMake = await MakeModel.getId({ id: foundVhc.makeId });
				if (foundMake) {
					makeName = foundMake.name;
				}
			}
			if (foundVhc.modelId) {
				let foundModel = await ModelModel.getId({ id: foundVhc.modelId });
				if (foundModel) {
					modelName = foundModel.name;
				}
			}

			vehicle['vehId'] = foundVhc.id;
			vehicle['vehRegistrationNo'] = foundVhc.regNo;
			vehicle['vehEngineNo'] = foundVhc.engineNo;
			vehicle['vehChassisNo'] = foundVhc.chassisNo;
			vehicle['vehPurchaseDate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['cusId'] = !_.isEmpty(cvrs) ? cvrs[0].customerId : null;
			vehicle['customerLocationId'] = customerLocId;
			vehicle['modId'] = foundVhc.modelId;
			vehicle['nvidate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['ododate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['warrantyPeriod'] = null;
			vehicle['warrantyExpiryDate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['standardWarrantyMileage'] = 0;
			vehicle['sellerId'] = '';
			vehicle['assignedOwner'] = '';
			vehicle['assignedOwnerHpNo'] = '';
			vehicle['lastServiceDate'] = lastServiceDt;
			vehicle['lastServiceMileage'] = lastServiceMil;
			vehicle['lastServiceWorkshop'] = lastServiceBranch;
			vehicle['registrationType'] = '';
			vehicle['registrationDate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['deliveryDate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['productionDate'] = foundVhc.manufacturingDate ? moment(foundVhc.manufacturingDate, 'YYYY-MM-DD').format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z' : null;
			vehicle['extendedWarrantyPeriod'] = 0;
			vehicle['expiryExtendedWarrantyPeriod'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['extendedWarrantyMileage'] = 0;
			vehicle['freeSvcVoucherCreatedDate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['insuranceCompany'] = '';
			vehicle['ewpinsurer'] = '';
			vehicle['remarks'] = null;
			vehicle['isTccar'] = false;
			vehicle['isDealerVehicle'] = false;
			vehicle['isPreRegisterVehicle'] = false;
			vehicle['vehFabricationNo'] = '';
			vehicle['ewpinsurerCode'] = '';
			vehicle['lastLubSvcDate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['lastLubSvcWorkshop'] = '';
			vehicle['lastLubSvcMileage'] = 0;
			vehicle['lastLubSvcEot'] = '';
			vehicle['isAssignedCar'] = false;
			vehicle['extendedWarrantyStartDate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
			vehicle['extendedWarrantyStartMileage'] = 0;
			vehicle['isupdatedbyIbs'] = false;
			vehicle['carMake'] = makeName;
			vehicle['carModel'] = modelName;
			vehicle['isNiscare'] = false;
			vehicle['npmpType'] = '';
			vehicle['npmpExpiryDate'] = moment().format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
		}

		let customer = {};
		let filterCust = [{ colId: 'identityNo', text: [icNo] }];
		let custRes = await CustomerModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterCust, true, false, true);
		let custs = custRes ? _.map(custRes, 'dataValues') : [];

		if (!_.isEmpty(custs)) {
			let foundCust = custs[0];

			let cusSalutation = '';
			if (foundCust.salutationId) {
				let filterSalutation = [{ colId: 'id', text: [foundCust.salutationId] }];
				let salutationRes = await SalutationModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterSalutation, true, false, true);
				let salutations = salutationRes ? _.map(salutationRes, 'dataValues') : [];
				if (!_.isEmpty(salutations)) {
					cusSalutation = salutations[0].name;
				}
			}

			let customerIdtypeCode = '';
			if (foundCust.identityId) {
				let foundIdentityType = await IdentityModel.getId({ id: foundCust.identityId });
				if (foundIdentityType) {
					customerIdtypeCode = foundIdentityType.code;
				}
			}

			let custLocationId = 0;
			let needAttention = false, isReceiveSms = false, isReceiveVehColSms = false, isReceiveSvcRmdSms = false, isReceiveCmpSms = false;
			let highestEducation = '';
			let gender = '';
			let cusTelHp = '', cusTelOffice = '', cusTelHouse = '', cusFax = '', cusEmail = '';
			let mAddress1 = '', mAddress2 = '', mAddress3 = '';
			let rPostCode = '', rCityName = '', rStateCode = '', rCountryCode = '';
			let filterCustDetail = [{ colId: 'customerId', text: [foundCust.id] }];
			let custDetailRes = await CustomerDetailsModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterCustDetail, true, false, true);
			let custDetails = custDetailRes ? _.map(custDetailRes, 'dataValues') : [];
			if (!_.isEmpty(custDetails)) {
				custLocationId = custDetails[0].id;
				needAttention = custDetails[0].isNeedSpecialAttention;
				isReceiveSms = custDetails[0].receiveSMS;
				isReceiveVehColSms = custDetails[0].isVehicleCollectionSMS;
				isReceiveSvcRmdSms = custDetails[0].isServiceReminderSMS;
				isReceiveCmpSms = custDetails[0].isCampaignSMS;
				if (custDetails[0].highestEducationId) {
					let foundEdu = await EducationModel.getOne({ id: custDetails[0].highestEducationId });
					if (foundEdu) {
						highestEducation = foundEdu.name;
					}
				}
				gender = custDetails[0].gender ? (custDetails[0].gender === '1' ? 'Male' : 'Female') : '';
				cusTelHp = custDetails[0].mobile;
				cusTelHouse = custDetails[0].telephone;
				cusFax = custDetails[0].fax;
				cusEmail = custDetails[0].email;
				mAddress1 = custDetails[0].mAddress1;
				mAddress2 = custDetails[0].mAddress2;
				mAddress3 = custDetails[0].mAddress3;

				if (custDetails[0].mPostcodeId) {
					let foundPostcode = await PostcodeModel.getId({ id: custDetails[0].mPostcodeId });
					if (foundPostcode) {
						rPostCode = foundPostcode.code;
					}
				}
				if (custDetails[0].mCityId) {
					let foundCity = await CityModel.getId({ id: custDetails[0].mCityId });
					if (foundCity) {
						rCityName = foundCity.name;
					}
				}
				if (custDetails[0].mStateId) {
					let foundState = await StateModel.getId({ id: custDetails[0].mStateId });
					if (foundState) {
						rStateCode = foundState.code;
					}
				}
				if (custDetails[0].mCountryId) {
					let foundCountry = await CountryModel.getId({ id: custDetails[0].mCountryId });
					if (foundCountry) {
						rCountryCode = foundCountry.code;
					}
				}
			}

			let cp = null, cpn = null;
			let filterCustomerContact = [
				{ colId: 'customerId', text: [foundCust.id] },
				{ colId: 'customerDetailsId', text: [custLocationId] }
			];
			let customerContactRes = await CustomerContactModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterCustomerContact, true, false, true);
			let customerContacts = customerContactRes ? _.map(customerContactRes, 'dataValues') : [];
			if (!_.isEmpty(customerContacts)) {
				cp = customerContacts[0].name;
				let rMobileCode = '';
				if (customerContacts[0].mobileCode) {
					let foundAoc = await AreaOperatorCodeModel.getId({ id: customerContacts[0].mobileCode });
					if (foundAoc) {
						rMobileCode = '(' + foundAoc.code + ')';
					}
				}

				let rTelCode = '';
				if (customerContacts[0].telCode) {
					let foundAoc1 = await AreaOperatorCodeModel.getId({ id: customerContacts[0].telCode });
					if (foundAoc1) {
						rTelCode = '(' + foundAoc1.code + ')';
					}
				}

				if (!_.isEmpty(customerContacts[0].mobile)) {
					cpn = rMobileCode + customerContacts[0].mobile;
				} else if (!_.isEmpty(customerContacts[0].telephone)) {
					cpn = rTelCode + customerContacts[0].telephone;
				}
			}

			let paymentterm = '', creditlimit = 0;
			let filterCustFinance = [{ colId: 'customerId', text: [foundCust.id] }];
			let custFinanceRes = await CustomerFinanceModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterCustFinance, true, false, true);
			let custFinances = custFinanceRes ? _.map(custFinanceRes, 'dataValues') : [];
			if (!_.isEmpty(custFinances)) {
				if (custFinances[0].paymentTermsId) {
					let foundPaymentTerm = await PaymentTermModel.getId({ id: custFinances[0].paymentTermsId });
					if (foundPaymentTerm) {
						paymentterm = foundPaymentTerm.name;
					}
				}
				creditlimit = !_.isEmpty(custFinances[0].creditLimit) ? Number(custFinances[0].creditLimit) : 0;
			}



			customer['cusId'] = foundCust.id;
			customer['cusSalutation'] = cusSalutation;
			customer['cusOtherSalutation'] = '';
			customer['cusName'] = foundCust.name;
			customer['customerIdno'] = foundCust.id; // -- requested by DriveOn
			customer['customerIdtypeCode'] = customerIdtypeCode;
			customer['race'] = '';
			customer['customerTypeCode'] = '';
			customer['internetAccess'] = false;
			customer['needAttention'] = needAttention;
			customer['firstLanguagePreference'] = '';
			customer['secondLanguagePreference'] = '';
			customer['highestEducation'] = highestEducation;
			customer['remarks'] = '';
			customer['isExcludeFromTax'] = false;
			customer['isReceiveSms'] = isReceiveSms;
			customer['isReceiveVehColSms'] = isReceiveVehColSms;
			customer['isReceiveSvcRmdSms'] = isReceiveSvcRmdSms;
			customer['isReceiveCmpSms'] = isReceiveCmpSms;
			customer['isNonEditable'] = false;
			customer['gender'] = gender;
			customer['navCustType'] = null;
			customer['navdebtorCode'] = null;
			customer['isPosted'] = false;
			customer['cmsCustCode'] = '';
			customer['paymentterm'] = paymentterm;
			customer['creditlimit'] = creditlimit;
			customer['isOnDebtorControl'] = false;
			customer['creditLimitBlockedBy'] = '';
			customer['gstpostingGroup'] = '';

			let loc = {
				customerLocationId: custLocationId,
				customerId: foundCust.id,
				locationId: 0,
				customerCode: '',
				cusTelHp,
				cusTelOffice,
				cusTelHouse,
				cusFax,
				cusEmail,
				cusPassword: '',
				officeTelExt: '',
				addressId: 0,
				contactPerson: cp,
				contactPersonNo: cpn,
				onlineRegTempPassword: '',
				verificationString: '',
				forgetPasswordString: '',
				isThroughEmail: false
			};
			loc['address'] = {
				addressId: 0,
				address1: mAddress1,
				address2: mAddress2,
				address3: mAddress3,
				city: rCityName,
				postcode: rPostCode,
				stateCode: rStateCode,
				countryCode: rCountryCode
			};
			customer['customerLocation'] = loc;
		}


		return {
			status: true,
			vehicle,
			customer
		}
	}
}

module.exports = Functions;