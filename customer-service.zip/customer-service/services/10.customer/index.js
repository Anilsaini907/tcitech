const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');
// const esRO = require('../es-shared/elasticsearch');
// const es = require('./elasticsearch');
/**
 * Search Customer Masterdata service
 * 
 * @route POST /customer/search
 * @operationId searchCustomer
 * @group Customer API
 * @param {CustomerSearch.model} CustomerSearch.body - Search. Show all if not provided.
 * @returns {CustomerSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post(['/search', '/esSearch'], function (req, res, next) {
	const {
		page,
		limit,
		order,
		search,
		filter,
		attribute,
		basicSearch
	} = req.body;

	const showAll = req.body.showAll ? req.body.showAll : false;
	const distKeys = req.body.distKeys ? req.body.distKeys : null;
	const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

	const tenantId = req.body.tenantId;

	if (search) {
		_.forEach(search, (searchObj) => {
			errorDef.parameterHandler([searchObj.colId, searchObj.text]);
		});
	}
	errorDef.parameterHandler([page, limit, order]);
	errorDef.parameterHandler([order.columnName, order.direction]);
	let pageObj = {
		page,
		limit,
		order: [order.columnName, order.direction]
	}
	return functions.getCustomer(search, pageObj, filter, tenantId, attribute, basicSearch, showAll, distKeys, searchOrCond).then((resp) => {
		if (!resp) {
			throw errorDef.MASTERDATA_NOT_FOUND
		}

		return res.status(200).send({ ...resp, order, search, filter, attribute, basicSearch });
	}).catch((reason) => {
		next(reason);
	});
});

router.post('/getCustomerLookup', function (req, res, next) {
	const page = req.body.page;
	const limit = req.body.limit;
	const order = req.body.order;
	const search = req.body.search;
	const filter = req.body.filter;
	const attribute = req.body.attribute;
	const basicSearch = req.body.basicSearch ? req.body.basicSearch : false;
	const showAll = req.body.showAll ? req.body.showAll : false;
	const distKeys = req.body.distKeys ? req.body.distKeys : null;
	const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;
	const tenantId = req.body.tenantId;
	const noCount = req.body.noCount;

	let pageObj = {
		page,
		limit,
		// order: [order.columnName, order.direction]
		order: [order.columnName, "ASC"]
	}
	return functions.getCustomerLookup(search, pageObj, filter, tenantId, attribute, basicSearch, showAll, distKeys, searchOrCond, noCount).then((resp) => {
		if (!resp) {
			throw errorDef.MASTERDATA_NOT_FOUND
		}

		return res.status(200).send({ ...resp, order, search, filter });
	}).catch((reason) => {
		next(reason);
	});
});

router.post('/searchV2', function (req, res, next) {
	const id = req.body.id;
	const companyId = req.body.companyId;

	return functions.searchV2(id, companyId).then((resp) => {
		if (!resp) {
			throw errorDef.MASTERDATA_NOT_FOUND
		}

		return res.status(200).send(resp);
	}).catch((reason) => {
		next(reason);
	});
});
/**
 * Add Customer Masterdata service
 * 
 * @route POST /customer/add
 * @operationId addCustomer
 * @group Customer API
 * @param {AddCustomer.model} AddCustomer.body.required - required Customer
 * @returns {Array.<CustomerData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
/** old API, see addV2 */
router.post('/add', [customValidator.validateCreateCustomer], async function (req, res, next) {
	const customer = req.body.customer;
	const topicCode = req.body.topicCode;
	errorDef.parameterHandler([customer, topicCode]);
	_.forEach(customer, (customerObj) => {
		errorDef.parameterHandler([
			// customerObj.id,
			customerObj.countryId,
			customerObj.customerAccountGroupId,
			// customerObj.regionId,
			customerObj.name,
			customerObj.identityId,
			customerObj.identityNo,
			customerObj.companyId
		]);
	});
	const userInfo = await errorDef.userInfoHandler(req)
		.catch(err => {
			console.error(err);
			next(err);
		});
	if (userInfo) {
		const who = userInfo.id
		// const who = 'abe';
		return functions.addCustomer(customer, topicCode, who, req.headers).then(async (resp) => {
			if (!resp) {
				throw errorDef.MASTERDATA_NOT_FOUND
			}
			if (resp && resp.length > 0) {
				const newCustomerIds = resp.map((r) => r.id);
				// await es.saveNewData(newCustomerIds, req.headers).catch(err => console.error(err));
			}
			return res.status(200).send(resp);
		}).catch((reason) => {
			next(reason);
		});
	}
});

router.post('/addV2', async function (req, res, next) {
	const customer = req.body.customer;
	const topicCode = req.body.topicCode;
	errorDef.parameterHandler([customer, topicCode]);
	_.forEach(customer, (customerObj) => {
		errorDef.parameterHandler([
			customerObj.countryId,
			customerObj.customerAccountGroupId,
			customerObj.name,
			customerObj.identityId,
			customerObj.identityNo,
			// customerObj.companyId
		]);
	});
	const userInfo = await errorDef.userInfoHandler(req)
		.catch(err => {
			console.error(err);
			next(err);
		});

	const payload = req.body;
	if (userInfo) {
		const who = userInfo.id
		// const who = 'abe';
		return functions.addCustomerV2(payload, who).then(async (respV2) => {
			const resp = respV2 ? [respV2] : null;
			if (!resp) {
				throw errorDef.MASTERDATA_NOT_FOUND
			}
			if (resp && resp.length > 0) {
				const newCustomerIds = resp.map((r) => r.id);
				await functions.getNavInterfaceCustomer(who, newCustomerIds, 'I');
				// await es.saveNewData(newCustomerIds, req.headers).catch(err => console.error(err));
			}
			return res.status(200).send(resp);
		}).catch((reason) => {
			next(reason);
		});
	}
});
/**
 * Update Customer Masterdata service
 * 
 * @route POST /customer/update
 * @operationId updateCustomer
 * @group Customer API
 * @param {UpdateCustomer.model} UpdateCustomer.body.required - required Customer
 * @returns {CustomerData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customValidator.validateUpdateCustomer], async function (req, res, next) {
	const customerId = req.body.id;
	const customer = req.body.customer;
	errorDef.parameterHandler([customerId]);
	errorDef.parameterHandler([customer]);
	// errorDef.parameterHandler([customer.code, customer.name]);
	const userInfo = await errorDef.userInfoHandler(req)
		.catch(err => {
			console.error(err);
			next(err);
		});
	if (userInfo) {
		let where = { id: customerId };
		return functions.updateCustomer(customer, where, userInfo.id, req.headers).then(async (resp) => {
			if (!resp) {
				throw errorDef.MASTERDATA_NOT_FOUND
			}
			// const updateESRO = esRO.updateCustomer(customerId, resp[0]).catch(err => console.error(err));
			// const updateES = es.updateDataById(customerId, req.headers).catch(err => console.error(err));
			// await Promise.all([
			//     updateESRO,
			//     updateES
			// ]);
			return res.status(200).send(resp);
		}).catch((reason) => {
			next(reason);
		});
	}
});

router.post('/updateV2', [customValidator.validateUpdateCustomer], async function (req, res, next) {
	const customerId = req.body.id;
	const customer = req.body.customer;
	errorDef.parameterHandler([customerId]);
	errorDef.parameterHandler([customer]);
	const userInfo = await errorDef.userInfoHandler(req)
		.catch(err => {
			console.error(err);
			next(err);
		});
	const payload = req.body;
	if (userInfo) {
		const who = userInfo.id;
		let where = { id: customerId };
		return functions.updateCustomerV2(payload, who, req.headers).then(async (resp) => {
			if (!resp) {
				throw errorDef.MASTERDATA_NOT_FOUND
			}
			const navCust = await functions.getNavInterfaceCustomer(who, customerId, 'M');

			return res.status(200).send(resp);
		}).catch((reason) => {
			next(reason);
		});
	}
});
/**
 * Delete Customer Masterdata service
 * 
 * @route DELETE /customer/delete
 * @operationId deleteCustomer
 * @group Customer API
 * @param {DeleteCustomer.model} DeleteCustomer.body.required - required Customer
 * @returns {Array.<CustomerData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteCustomer], async function (req, res, next) {
	const customerId = req.body.id;
	const deleteOption = req.body.option;
	errorDef.parameterHandler([customerId, deleteOption]);
	const userInfo = await errorDef.userInfoHandler(req)
		.catch(err => {
			console.error(err);
			next(err);
		});
	if (userInfo) {
		let where = { id: customerId };
		return functions.deleteCustomer(where, userInfo.id, deleteOption).then(async (resp) => {
			if (!resp) {
				throw errorDef.MASTERDATA_NOT_FOUND
			}
			// await es.deleteDataByIds([customerId], req.headers).catch(err => console.error(err));
			return res.status(200).send(resp);
		}).catch((reason) => {
			next(reason);
		});
	}
});
router.delete('/esDelete', async function (req, res, next) {
	const customerIds = req.body.ids;

	// await es.deleteDataByIds(customerIds, req.headers).catch(err => console.error(err));
	return res.status(200).send({ msg: `deleted ${JSON.stringify(customerIds)}` });
});

/**
 * Export Customer Masterdata service
 * 
 * @route POST /customer/export
 * @operationId exportCustomer
 * @group Customer API
 * @param {CustomerSearch.model} CustomerSearch.body - Search. Show all if not provided.
 * @returns {CustomerSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
	const search = req.body.search;
	const page = req.body.page;
	const limit = req.body.limit;
	const order = req.body.order;

	if (search) {
		_.forEach(search, (searchObj) => {
			errorDef.parameterHandler([searchObj.colId, searchObj.text]);
		});
	}
	errorDef.parameterHandler([page, limit, order]);
	errorDef.parameterHandler([order.columnName, order.direction]);
	let pageObj = {
		page,
		limit,
		order: [order.columnName, order.direction]
	}

	return functions.getCustomer(search, pageObj, []).then((resp) => {
		if (!resp) {
			throw errorDef.MASTERDATA_NOT_FOUND
		}
		let data = {
			rows: resp.rows,
			filename: 'customer'
		};

		return ExportAPI.exportData(null, data).then(response => {
			if (!response) {
				throw errorDef.EXPORTDATA_NOT_FOUND;
			}
			return res.status(200).send(response);
		});

	}).catch((reason) => {
		next(reason);
	});
});

/** ////// Elastic Search Functions /////////////// */
// router.post('/uploadData', async (req, res, next) => {

//     es.pumpDatainES(req.body, req.headers)
//         .then(x => {
//             res.status(200).json(x);
//         })
//         .catch(err => {
//             console.error(err);
//         })
// })
// router.post('/updateData', async (req, res, next) => {

//     // es.updateDatainES(req.body, req.headers)
//     es.updateDatainES(req.body)
//         .then(x => {
//             res.status(200).json(x);
//         })
//         .catch(err => {
//             console.error(err);
//         })
// })


// router.post('/esSearch', (req, res, next) => {
//     es.search(req.body)
//         .then(x => {
//             functions.getAuthInfo(x, req.headers).then((x2) => {
//                 res.status(200).json({ ...x2, ...req.body });
//             });

//         })
//         .catch(err => {
//             console.error(err)
//         })
// });

router.put('/mobile-web-update-profile', async function (req, res, next) {
	const customer = req.body.customer;
	const removedCusLocationIdList = req.body.removedCusLocationIDList;
	const isMobile = req.body.isMobile ? req.body.isMobile : false;

	return functions.updateCustomerProfile(customer, removedCusLocationIdList).then(result => {
		return res.status(200).send(result);
	}).catch((reason) => {
		next(reason);
	});
});

router.post('/mobile-web-get-enquiry-validation', async function (req, res, next) {
	const regNo = req.body.regNo;
	const icNo = req.body.icNo;
	const isMobile = req.body.isMobile ? req.body.isMobile : false;

	return functions.getEnquiryValidation(regNo, icNo).then(result => {
		return res.status(200).send(result);
	}).catch((reason) => {
		next(reason);
	});
});

router.post('/navisionInterfaceCustomer', async function (req, res, next) {
	//const datas = req.body.datas;
	const customerId = req.body.customerId;
	const action = req.body.action;

	if (customerId && action) {

		return functions.getNavInterfaceCustomer('TCEAS', customerId, action).then((result) => {
			return res.status(200).send(result);
		})
			.catch((reason) => {
				next(reason);
			});
	}
});

module.exports = router;