const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateCustomer: (req, res, next) => {
        req.checkBody('customer', 'Customer object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('customer.*.countryId', 'Country parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.*.customerAccountGroupId', 'Customer Account Group parameter is invalid or missing').trim().notEmpty();
        // req.checkBody('customer.*.regionId', 'Region parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.*.identityId', 'Identity ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.*.identityNo', 'Identity No parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.*.companyId', 'companyId is invalid or missing').trim().notEmpty();
        // req.checkBody('customer.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateCustomer: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer', 'Customer object parameter is missing').trim().notEmpty();
        req.checkBody('customer.countryId', 'Country parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.customerAccountGroupId', 'Customer Account Group parameter is invalid or missing').trim().notEmpty();
        // req.checkBody('customer.regionId', 'Region parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.identityId', 'Identity ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.identityNo', 'Identity No parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customer.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteCustomer: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}