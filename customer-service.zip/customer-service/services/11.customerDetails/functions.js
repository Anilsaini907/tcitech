const CustomerModel = require('@driveit/driveit-databases/databases/customerMaster/models/10.customer');
const CompanyModel = require('@driveit/driveit-databases/databases/customerMaster/models/7.company');
const CustomerFinanceModel = require('@driveit/driveit-databases/databases/customerMaster/models/12.customerFinance');
const CustomerDetailsModel = require('@driveit/driveit-databases/databases/customerMaster/models/11.customerDetails');
const CustomerGroupModel = require('@driveit/driveit-databases/databases/customerMaster/models/1.customerGroup');
const CustomerCorrespondenceAddrModel = require('@driveit/driveit-databases/databases/customerMaster/models/33.customerCorrespondenceAddress');
const NavisionCustomerHistoryModel = require("@driveit/driveit-databases/databases/generalMaster/models/90.navisionCustomerHistory");
const ConstantParameterModel = require("@driveit/driveit-databases/databases/generalMaster/models/89.constantParameter");
const NavisionCronJobModel = require("@driveit/driveit-databases/databases/generalMaster/models/95.navisionCRonJobs");
const KafkaService = require("@driveit/driveit-databases/utils/kafkaService.js");

const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
var moment = require('moment');
const config = require('config');
const generalCache = require('../cache-request/general-api');
class Functions {

    static async getCustomerDetails(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        };

        let attr = null;
        return {
            ...await CustomerDetailsModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        };
    }

    static async getAll(page) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await CustomerDetailsModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addCustomerDetails(customerDetailsObj, who) {
        // return CustomerDetailsModel.sequelize.transaction((t) => {
        var promises = [];
        _.forEach(customerDetailsObj, (addCustomerDetailsObj) => {
            addCustomerDetailsObj['createdBy'] = who;
            addCustomerDetailsObj['updatedBy'] = who;
            const p = CustomerDetailsModel.addNew(addCustomerDetailsObj, null).then(async (res) => {
                let where = { id: res.id };
                return res;
            });
            promises.push(p);
        });
        return Promise.all(promises).then((resP) => {
            const custDetailsIds = _.map(resP, 'id');
            let filterCustDetail = [{ colId: 'id', text: !_.isEmpty(custDetailsIds) ? custDetailsIds : [null] }];

            return CustomerDetailsModel.searchAll([], null, {}, ["createdAt", "desc"], filterCustDetail, false, true, true).then(async (res) => {
                let promises2 = [];
                if (res && res.length) {
                    for (let q = 0; q < _.size(res); q++) {
                        let custDetail = res[q];
                        custDetail['financeGroupId'] = customerDetailsObj[0]['financeGroupId'];
                        custDetail['contactName'] = customerDetailsObj[0]['contactName'];
                        custDetail['isNewInsert'] = true;

                        // Lee Qi Rui request change. overwrite company id when sending to kafka
                        if (customerDetailsObj[0].tenantCompanyId !== undefined) {
                            custDetail['companyId'] = customerDetailsObj[0].tenantCompanyId;
                            let foundComp = await CompanyModel.getId({ id: customerDetailsObj[0].tenantCompanyId });
                            custDetail['company'] = _.pick(foundComp, ['id', 'code', 'name']);
                        }

                        // await this.navisionCustomerHistory(custDetail, who);
                        const p = this.navisionCustomerHistory(custDetail, who);
                        promises2.push(p);
                    }
                }
                if (promises2.length) {
                    await Promise.all(promises2);
                }

                return (res && res.length) ? res : [];
            });
        });

        // return CustomerDetailsModel.sequelize.transaction((t) => {
        //     var promises = [];
        //     _.forEach(customerDetailsObj, (addCustomerDetailsObj) => {
        //         addCustomerDetailsObj['createdBy'] = who;
        //         addCustomerDetailsObj['updatedBy'] = who;
        //         const p = CustomerDetailsModel.addNew(addCustomerDetailsObj, t);

        //         promises.push(p);
        //     });
        //     return Promise.all(promises).then((res) => {
        //         if (!_.isEmpty(res)) {
        //             for(let i = 0; i < res.length; i++) {
        //                 // let custDetail = res[i];
        //                 let where = { id: res[i].id };
        //                 CustomerDetailsModel.getId(where).then(async (custDetail)=>{
        //                     if (custDetail) {
        //                         await this.navisionCustomerHistory(custDetail).catch((err) => { console.log(err); });
        //                     }
        //                 });
        //             }
        //         }

        //         return res;
        //     });
        // });
    }

    static async addCustomerCorrespondenceAddrs(resp, customerDetailsObj, who) {
        return CustomerCorrespondenceAddrModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(resp, (obj) => {
                let found = _.find(customerDetailsObj, (o) => {
                    return (
                        // o.address1 === obj.address1 && o.address2 === obj.address2 && o.address3 === obj.address3 &&
                        // o.postcodeId === obj.postcodeId && o.cityId === obj.cityId && o.stateId === obj.stateId &&
                        // o.countryId === obj.countryId && 
                        o.telephone === obj.telephone && o.mobile === obj.mobile &&
                        o.email === obj.email && o.preferedModeOfContactId === obj.preferedModeOfContactId
                    );
                });

                if (found && found.correspondenceAddresses) {
                    _.forEach(found.correspondenceAddresses, (corrAddr) => {
                        corrAddr['createdBy'] = who;
                        corrAddr['updatedBy'] = who;
                        corrAddr['customerDetailsId'] = obj.id;
                        const p = CustomerCorrespondenceAddrModel.addRecord(corrAddr, t);
                        promises.push(p);
                    });
                }
            });

            return Promise.all(promises);
        });
    }

    static async updateCustomerDetails(customerDetail, where, who) {
        const customerDateOfBirth = customerDetail.dateOfBirth || '1900-01-01';
        const isValidDate = moment(customerDateOfBirth).isValid();
        customerDetail.dateOfBirth = null;
        if (isValidDate) {
            customerDetail.dateOfBirth = new Date(customerDateOfBirth);
        }

        const { customerId, companyId } = customerDetail;
        const existedCustomerDetail = await CustomerDetailsModel.getId({ customerId, companyId });
        if (existedCustomerDetail) {
            where.id = existedCustomerDetail.id;
        }

        const isAddNew = !where.id;
        if (isAddNew) {
            delete customerDetail.id;
            const addedCustomerDetails = await this.addCustomerDetails([customerDetail], who);
            if (!addedCustomerDetails) {
                throw errorDef.MASTERDATA_NOT_FOUND;
            }

            const [addedCustomerDetail] = addedCustomerDetails || [{}];
            return addedCustomerDetail;
        }

        const foundCustomerDetail = await CustomerDetailsModel.getId(where);
        if (!foundCustomerDetail) {
            throw errorDef.MASTERDATA_NOT_FOUND;
        }

        customerDetail['updatedBy'] = who;
        customerDetail['id'] = where.id;
        await CustomerDetailsModel.updateCustomerDetails(customerDetail, where);
        let updatedCustomerDetail = await CustomerDetailsModel.getId(where);

        updatedCustomerDetail['financeGroupId'] = customerDetail['financeGroupId'];
        updatedCustomerDetail['contactName'] = customerDetail['contactName'];

        // Lee Qi Rui request change. overwrite company id when sending to kafka
        if (customerDetail.tenantCompanyId !== undefined) {
            updatedCustomerDetail['companyId'] = customerDetail.tenantCompanyId;
            let foundComp = await CompanyModel.getId({ id: customerDetail.tenantCompanyId });
            updatedCustomerDetail['company'] = _.pick(foundComp, ['id', 'code', 'name']);
        }

        await this.navisionCustomerHistory(updatedCustomerDetail, who).catch((err) => { console.log(err); });

        return updatedCustomerDetail;
    }

    static async updateCustomerCorrespondenceAddrs(customerDetails, where, who) {
        return CustomerCorrespondenceAddrModel.sequelize.transaction((t) => {
            var promises = [];

            _.forEach(customerDetails.correspondenceAddresses, (obj) => {
                obj['updatedBy'] = who;
                obj['customerDetailsId'] = where.id;
                let p;
                if (obj.id !== undefined && obj.id !== null) {     // update
                    p = CustomerCorrespondenceAddrModel.updateRecord(_.omit(obj, 'id'), { id: obj.id }, t);
                } else {    // add
                    delete obj.id;
                    obj['createdBy'] = who;
                    p = CustomerCorrespondenceAddrModel.addRecord(obj, t);
                }
                promises.push(p);
            });

            //delete
            _.forEach(customerDetails.deletedCorrespondenceAddresses, (id) => {
                let p2 = CustomerCorrespondenceAddrModel.deleteRecord({ id }, t);
                promises.push(p2);
            });

            return Promise.all(promises);
        });
    }

    static async deleteCustomerDetails(where, who, type = "soft") {
        if (type == "soft") {
            return await CustomerDetailsModel.deleteSoft(where, who).then(() => {
                return CustomerDetailsModel.getAll(where, null).then((resp) => {
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await CustomerDetailsModel.deleteHard(where).then((resp) => {
                if (!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }

    static async getCustomerAddresses(customerId, token) {
        let where = {
            customerId: customerId
        };
        let city = [];
        let country = [];
        let postcode = [];
        let state = [];
        let address1 = '', address2 = '';
        return CustomerDetailsModel.getOne(where).then(response => {
            let searchMasterDatas = [];
            if (response) {
                const data = response.dataValues;
                if (data.mAddress1) {
                    address1 += data.mAddress1 ? data.mAddress1 + ',' : null;
                }
                if (data.mAddress2) {
                    address1 += data.mAddress2 ? data.mAddress2 + ',' : null;
                }
                if (data.mAddress3) {
                    address1 += data.mAddress3 ? data.mAddress3 + ',' : null;
                }
                if (data.cAddress1) {
                    address2 += data.cAddress1 ? data.cAddress1 + ',' : null;
                }
                if (data.cAddress2) {
                    address2 += data.cAddress2 ? data.cAddress2 + ',' : null;
                }
                if (data.cAddress3) {
                    address2 += data.cAddress3 ? data.cAddress3 + ',' : null;
                }

                _.map(response.dataValues, (v, k) => {
                    if (k.includes('City')) {
                        city.push(v);
                    }

                    if (k.includes('State')) {
                        state.push(v);
                    }
                    if (k.includes('Postcode')) {
                        postcode.push(v);
                    }

                    if (k.includes('Country')) {
                        country.push(v);
                    }
                })
                if (city && city.length > 0) {
                    searchMasterDatas.push({
                        masterdata: 'city',
                        search: [{ colId: "id", text: city }]
                    });
                }
                if (state && state.length > 0) {
                    searchMasterDatas.push({
                        masterdata: 'state',
                        search: [{ colId: "id", text: state }]
                    });
                }
                if (postcode && postcode.length > 0) {
                    searchMasterDatas.push({
                        masterdata: 'postcode',
                        search: [{ colId: "id", text: postcode }]
                    });
                }
                if (country && country.length > 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "id", text: country }]
                    });
                }

                return generalCache.getMasterDataByQuery(searchMasterDatas, token).then((queryResult) => {

                    if (queryResult) {
                        if (queryResult.city && queryResult.city.length > 0) {
                            let mCity = queryResult.city.find(el => el['id'] === data.mCityId);
                            let cCity = queryResult.city.find(el => el['id'] === data.cCityId);
                            if (mCity) {
                                address1 += mCity && mCity.name ? mCity.name + ', ' : ''
                            }
                            if (cCity) {
                                address2 += cCity && cCity.name ? cCity.name + ', ' : ''
                            }
                        }
                        if (queryResult.state && queryResult.state.length > 0) {
                            let mState = queryResult.state.find(el => el['id'] === data.mStateId);
                            let cState = queryResult.state.find(el => el['id'] === data.cStateId);
                            if (mState) {
                                address1 += mState && mState.name ? mState.name + ', ' : ''
                            }
                            if (cState) {
                                address2 += cState && cState.name ? cState.name + ', ' : ''
                            }
                        }
                        if (queryResult.postcode && queryResult.postcode.length > 0) {
                            let mPostcode = queryResult.postcode.find(el => el['id'] === data.mPostcodeId);
                            let cPostcode = queryResult.postcode.find(el => el['id'] === data.cPostcodeId);
                            if (mPostcode) {
                                address1 += mPostcode && mPostcode.name ? mPostcode.name + ', ' : ''
                            }
                            if (cPostcode) {
                                address2 += cPostcode && cPostcode.name ? cPostcode.name + ', ' : ''
                            }
                        }
                        if (queryResult.country && queryResult.country.length > 0) {
                            let mCountry = queryResult.country.find(el => el['id'] === data.mCountryId ? data.mCountryId : null);
                            let cCountry = queryResult.country.find(el => el['id'] === data.cCountryId ? data.cCountryId : null);
                            if (mCountry) {
                                address1 += mCountry && mCountry.name ? mCountry.name + '.' : ''
                            }
                            if (cCountry) {
                                address2 += cCountry && cCountry.name ? cCountry.name + '.' : ''
                            }
                        }
                        let addresses = [];
                        addresses.push({ id: 1, name: address1, status: 1 });
                        addresses.push({ id: 2, name: address2, status: 1 });

                        return {
                            rows: addresses
                        };
                    }
                })
            }
        });
    }

    static async testabe(customerDetailsId) {

        const who = 'abe'

        let filterCustDetail = [{ colId: 'id', text: [customerDetailsId] }];
        const customInclude = [
            // { 
            //     model: CustomerContactModel
            // },
            // { 
            //     model: CustomerFinanceModel,
            //     include: [
            //         {
            //             model: CustomerGroupModel
            //         }
            //     ]
            // }
        ]
        return CustomerDetailsModel.searchAll([], null, {}, ["createdAt", "desc"], filterCustDetail, false, true, true, customInclude).then(async (res) => {
            // return res;
            let promises = [];
            if (res && res.length) {
                for (let q = 0; q < _.size(res); q++) {
                    let custDetail = res[q];
                    custDetail['financeGroupId'] = _.get(custDetail, 'customerFinances[0].customerGroup.id', null);
                    custDetail['contactName'] = _.get(custDetail, 'customerContacts[0].name', null);
                    const test = true;
                    const p = this.navisionCustomerHistory(custDetail, who, test);
                    promises.push(p);
                }
            }
            return Promise.all(promises);
        });
    }

    static async addNavisionCustomerHistory(customerIds, newTopic = null, test = false) {
        let filterCustomerDetail = [
            { colId: 'customerId', text: customerIds },
            { colId: 'status', text: ['enabled'] }
        ];
        let result = await CustomerDetailsModel.searchAll([], null, {}, ["createdAt", "desc"], filterCustomerDetail, false, false, true);
        let custDetails = result ? _.map(result, 'dataValues') : [];

        let nonCustomers = _.difference(customerIds, _.map(custDetails, 'customerId'));

        
        let successArr = [], failArr = [];
        for (let i = 0; i < _.size(custDetails); i++) {
            let custDetail = custDetails[i];

            custDetail['financeGroupId'] = _.get(custDetail, 'customerFinances[0].customerGroup.id', null);
            custDetail['contactName'] = _.get(custDetail, 'customerContacts[0].name', null);
            // check whether this customer detail is newly inserted to NavisionCustomerHistory
            let foundNaviCustomerHist = await NavisionCustomerHistoryModel.getOne({no: custDetail.customerId});
            if (!foundNaviCustomerHist) {
                custDetail['isNewInsert'] = true;
            }
            let result2 = await this.navisionCustomerHistory(custDetail, 'system', false, true);

            let isEtcm = await this.checkRowIsEtcm(custDetail);
            await this.callNavisionCustomerHistoryKafka([result2], 'system', isEtcm, newTopic, test);

            if (result2) {
                successArr.push(custDetail.customerId);
            } else {
                failArr.push(custDetail.customerId);
            }
        }
        return {
            pushed: successArr,
            error: failArr,
            except: nonCustomers
        };
    }

    static async callNavisionCustomerHistoryKafka(result, who, isEtcm, newTopic = null, test = false) {
        // const self = this;
        if (!_.isEmpty(result)) {

            const mappResult = _.map(_.map(result, 'dataValues'), (o) => {
                return _.omit(o, ['createdBy', 'createdAt', 'updatedBy', 'updatedAt', 'syncStatus'])
            });

            
            let topic = newTopic !== null ? newTopic : (isEtcm ? config.navisionKafka.topic.navisionCustomerEtcmHistory : config.navisionKafka.topic.navisionCustomerHistory);
            if (!test) {
                await KafkaService.sendDataToKafka(
                    config.navisionKafka.ip,
                    config.navisionKafka.port,
                    topic,
                    mappResult[0], async function (kafkaResult) {

                        if (kafkaResult && kafkaResult.length > 0) {

                            const mappedIds = _.map(result, 'id');
                            await Promise.all([
                                NavisionCustomerHistoryModel.updateRecord({ syncStatus: 'success' }, { id: mappedIds })
                            ]);
                            // resolve();
                        } else {
                            // Save data to cronjob table.
                            // if (newTopic === null) {
                            //     await self.insertNavisionCronJobTableBulk('navisionInvoiceCancelHistory', mappResult, who);
                            // }
                            // resolve();
                        }
                    }, async function (error) {
                        // save data to cronjob table.
                        // if (newTopic === null) {
                        //     await self.insertNavisionCronJobTableBulk('navisionInvoiceCancelHistory', mappResult, who);
                        // }
                        // resolve();
                    });
            } else {
                // resolve();
            }

        } else {
            // resolve();
        }
    }


    static async navisionCustomerHistory(data, who, test = false, dontSendKafka = false) {
        
        let cust = await CustomerModel.getId({id: data.customerId});
        let name = '';
        let name2 = '';
        if (cust) {
            if (cust.name.length > 50) {
                name = cust.name.substring(0, 50);
                name2 = cust.name.substring(50, 100);
            } else {
                name = cust.name;
            }
        }
        
        let previousCustomerNo = cust ? cust.previousCustomerNo : null;
        
        let group = data.financeGroupId ? await CustomerGroupModel.getId({id: data.financeGroupId}) : null;

        let filterConstantPrm = [{ colId: 'status', text: ['Active'] }, { colId: 'module', text: ['SHARED'] }];
        let constantsResp = await ConstantParameterModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterConstantPrm, true, true, true);
        let constants = constantsResp ? _.map(constantsResp, 'dataValues') : [];

        let companyCode = 'NoCOMPANY_NAV Value1';
        let cusVenPostingGroup = 'NoCUST_PG';
        let businessPostingGroup = 'NoCUST_PG';
        let gstBusinessPostingGroup = 'NoCUST_PG';

        let foundConstant1 = _.find(constants, (constant) => {
            return constant.module === 'SHARED'
                && constant.functionArea === 'COMPANY_NAV'
                && constant.parameter2 === data.company.code;
        });
        if (foundConstant1) {
            companyCode = foundConstant1.value1;
        } else {

            let foundCompany = await CompanyModel.getId({ id: data.companyId });
            if (foundCompany) {
                let foundParentComp = await CompanyModel.getId({ id: foundCompany.parentCompanyId });
                if (foundParentComp) {
                    let foundConstant2 = _.find(constants, (constant) => {
                        return constant.module === 'SHARED'
                            && constant.functionArea === 'COMPANY_NAV'
                            && constant.parameter2 === foundParentComp.code;
                    });
                    if (foundConstant2) {
                        companyCode = foundConstant2.value1;
                    } else {

                        let foundParentComp2 = await CompanyModel.getId({ id: foundParentComp.parentCompanyId });
                        if (foundParentComp2) {
                            let foundConstant3 = _.find(constants, (constant) => {
                                return constant.module === 'SHARED'
                                    && constant.functionArea === 'COMPANY_NAV'
                                    && constant.parameter2 === foundParentComp2.code;
                            });
                            if (foundConstant3) {
                                companyCode = foundConstant3.value1;
                            }
                        }
                        

                    }
                }
            }

        }
        let foundConstant2 = _.find(constants, (constant) => {
            return constant.module === 'SHARED'
                && constant.functionArea === 'CUST_PG_NAV'
                && cust && cust.customerAccountGroup && constant.parameter2 === cust.customerAccountGroup.code
                && (constant.parameter3 === '-' || (group && constant.parameter3 === group.code));
                    // || ((data.customerFinances && data.customerFinances[0]) ? constant.parameter3 === data.customerFinances[0].customerGroup.code : false))) {
        });
        if (foundConstant2) {
            cusVenPostingGroup = foundConstant2.value1;
            businessPostingGroup = foundConstant2.value2;
            gstBusinessPostingGroup = foundConstant2.value3;
        }

        let phoneNo = data.telephone ? data.telephone : '';
        if (data.telCodeDetail) {
            phoneNo = data.telCodeDetail.code + '-' + phoneNo;
        }
        let faxNo = data.fax ? data.fax : '';
        if (data.faxCodeDetail) {
            faxNo = data.faxCodeDetail.code + '-' + faxNo;
        }

        const navisionHistory = {
            dataType: 'C',
            action: data.isNewInsert !== undefined && data.isNewInsert ? 'I' : 'M',
            companyCode,
            no: previousCustomerNo ? previousCustomerNo : data.customerId,
            name,
            name2,
            address: data.mAddress1,
            address2: data.mAddress2,
            address3: data.mAddress3,
            address4: '',
            postCode: _.get(data, 'mPostcode.code', null),
            countryCode: _.get(data, 'mCountry.code', null),
            // contact : (data.customerContacts && data.customerContacts[0]) ? data.customerContacts[0].name : '',
            contact: data.contactName,
            phoneNo,
            faxNo,
            email: data.email,
            registrationNo: cust ? cust.identityNo : '',
            cusVenPostingGroup,
            businessPostingGroup,
            paymentTermCode: 'CASH',
            paymentMethodCode: '',
            deleted: cust ? (cust.deleted ? cust.deleted : 0) : 0,
            gstRegistrationNo: '',
            gstBusinessPostingGroup,
            gstStatusLastCheckedDate: null,
            createdBy: cust ? cust.createdBy : '',
            updatedBy: cust ? cust.updatedBy : '',
        };

        if (test) {
            return navisionHistory;
        }

        let res = await NavisionCustomerHistoryModel.addRecord(navisionHistory);
        if (dontSendKafka) {
            return res;
        }

        let isEtcm = await this.checkRowIsEtcm(data);

        navisionHistory.id = res.id;
        delete navisionHistory.createdBy;
        delete navisionHistory.updatedBy;
        const self = this;
        await KafkaService.sendDataToKafka(
            config.navisionKafka.ip,
            config.navisionKafka.port,
            isEtcm ? config.navisionKafka.topic.navisionCustomerEtcmHistory : config.navisionKafka.topic.navisionCustomerHistory,
            navisionHistory,
            async function (kafkaResult) {
            
            if (kafkaResult && kafkaResult.length > 0) {
                // Update NavisionHistory status is success
                await self.updateNavisionHistoryStatus(navisionHistory);
            } else {
                // Save data to cronjob table.
                // await self.insertNavisionCronJobTable(navisionHistory, who);
            }
        }, async function (error) {
            // save data to cronjob table.
            // console.log(error);
            // await self.insertNavisionCronJobTable(navisionHistory, who);
            console.log("NVCHECK: ",error); //added to check if any error and easy to trace in log
        });
        
        return res;
    }

    static async checkRowIsEtcm(data) {
        let isEtcm = false;
        let foundCompany = await CompanyModel.getId({ code: _.get(data, 'company.code', null) });
        if (foundCompany) {
            if (foundCompany.code === 'MYETC') {
                isEtcm = true;
            }
            if (!_.isEmpty(foundCompany.parentCompanyId)) {
                let foundParentCompany = await CompanyModel.getId({ id: foundCompany.parentCompanyId });
                if (foundParentCompany) {
                    if (foundParentCompany.code === 'MYETC') {
                        isEtcm = true;
                    }
                    if (!_.isEmpty(foundParentCompany.parentCompanyId)) {
                        let foundParentCompany2 = await CompanyModel.getId({ id: foundParentCompany.parentCompanyId });
                        if (foundParentCompany2) {
                            if (foundParentCompany2.code === 'MYETC') {
                                isEtcm = true;
                            }
                        }
                    }
                }
            }
        }
        return isEtcm;
    }

    static async updateNavisionHistoryStatus(navisionHistory) {
        const where = {
            id: navisionHistory.id,
        }
        const updateResult = await NavisionCustomerHistoryModel.updateRecord({ syncStatus: 'success' }, where);
        return updateResult;
    }

    static async insertNavisionCronJobTable(navisionHistory, who) {
        const navisionCronJob = {
            tableName: 'navisionCustomerHistory',
            navisionHistoryId: navisionHistory.id,
            createdBy: who,
            updatedBy: who
        }
        const result = await NavisionCronJobModel.addRecord(navisionCronJob);
        return result;
    }
}


module.exports = Functions;