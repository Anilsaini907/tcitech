const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');
// const es = require('../10.customer/elasticsearch');
/**
 * Search Customer Masterdata service
 * 
 * @route POST /customerDetails/search
 * @operationId searchCustomerDetails
 * @group Customer Details API
 * @param {CustomerDetailsSearch.model} CustomerDetailsSearch.body - Search. Show all if not provided.
 * @returns {CustomerDetailsSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    return functions.getCustomerDetails(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});
/**
 * Add Customer Masterdata service
 * 
 * @route POST /customerDetails/add
 * @operationId addCustomerDetails
 * @group Customer Details API
 * @param {AddCustomerDetails.model} AddCustomerDetails.body.required - required CustomerDetails
 * @returns {Array.<CustomerDetailsData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', async function (req, res, next) {
    const customerDetails = req.body.customerDetails;
    errorDef.parameterHandler([customerDetails]);
    _.forEach(customerDetails, (customerDetailsObj) => {
        errorDef.parameterHandler([
            customerDetailsObj.customerId,
            customerDetailsObj.tenantId,
            customerDetailsObj.mAddress1,
            customerDetailsObj.mPostcodeId,
            customerDetailsObj.mCityId,
            customerDetailsObj.mStateId,
            customerDetailsObj.mCountryId,
            // customerDetailsObj.cAddress1,
            // customerDetailsObj.cPostcodeId,
            // customerDetailsObj.cCityId,
            // customerDetailsObj.cStateId,
            // customerDetailsObj.cCountryId,
            customerDetailsObj.telephone,
            customerDetailsObj.mobile,
            customerDetailsObj.email,
            customerDetailsObj.preferedModeOfContactId,
            // customerDetailsObj.receiveSMS,
            // customerDetailsObj.gender,
            // customerDetailsObj.highestEducationId,
            // customerDetailsObj.ethnicityId,
            // customerDetailsObj.dateOfBirth,
            // customerDetailsObj.nationality,
            // customerDetailsObj.religionId,
            // customerDetailsObj.pdpaConsent,
            // customerDetailsObj.pdpaSignedDate
        ]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        const who = userInfo.id;
        // const who = 'abe test';
        return functions.addCustomerDetails(customerDetails, who).then(async (resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND;
            }

            return functions.addCustomerCorrespondenceAddrs(resp, customerDetails, who).then(async (resp2) => {
                const customerIds = resp.map((r) => r.customerId);
                // const updateES = es.updateDataByIds(customerIds, req.headers).catch(err => console.error(err));
                // await Promise.all([updateES]);

                return res.status(200).send(resp);
            }).catch((reason2) => {
                next(reason2);
            });

        }).catch((reason) => {
            // next(reason);
            res.status(200).send({msg: 'Service Error'});
        });
    }
});

/**
 * Update Customer Masterdata service
 * 
 * @route POST /customerDetails/update
 * @operationId updateCustomerDetails
 * @group Customer Details API
 * @param {UpdateCustomerDetails.model} UpdateCustomerDetails.body.required - required CustomerDetails
 * @returns {CustomerDetailsData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', async function (req, res, next) {
    const customerDetailsId = req.body.id;
    const customerDetails = req.body.customerDetails;
    errorDef.parameterHandler([customerDetails]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: customerDetailsId };
        return functions.updateCustomerDetails(customerDetails, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }

            return functions.updateCustomerCorrespondenceAddrs(customerDetails, { id: resp.id }, userInfo.id).then(async (resp2) => {

                const customerId = resp.customerId;
                // const updateES = es.updateDataById(customerId, req.headers).catch(err => console.error(err));
                // await Promise.all([updateES]);
                return res.status(200).send(resp);

            }).catch((reason2) => {
                next(reason2);
            });
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete Customer Masterdata service
 * 
 * @route DELETE /customerDetails/delete
 * @operationId deleteCustomerDetails
 * @group Customer Details API
 * @param {DeleteCustomerDetails.model} DeleteCustomerDetails.body.required - required CustomerDetails
 * @returns {Array.<CustomerDetailsData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteCustomerDetails], async function (req, res, next) {
    const customerDetailsId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([customerDetailsId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: customerDetailsId };
        return functions.deleteCustomerDetails(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Export Customer Masterdata service
 * 
 * @route POST /customerDetails/export
 * @operationId exportCustomerDetails
 * @group Customer Details API
 * @param {CustomerDetailsSearch.model} CustomerDetailsSearch.body - Search. Show all if not provided.
 * @returns {CustomerDetailsSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }

    return functions.getCustomerDetails(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows: resp.rows,
            filename: 'customer_details'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});


/**
 * Search Customer Masterdata service
 * 
 * @route POST /getAddressByCustomerId/search
 * @operationId searchCustomerDetailsByCustomerId
 * @group Customer Details API
 * @param {CustomerDetailsSearch.model} CustomerDetailsSearch.body - Search. Show all if not provided.
 * @returns {CustomerDetailsSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/getAddressByCustomerId', function (req, res, next) {
    // const showAll = req.body.showAll;
    const customerId = req.body.customerId;
    const token = req.headers.authorization;;
    // const page = req.body.page; 
    // const limit = req.body.limit;
    // const order = req.body.order;
    // const filter = req.body.filter;

    // errorDef.parameterHandler([page, limit, order]);
    // errorDef.parameterHandler([order.columnName, order.direction]);
    return functions.getCustomerAddresses(customerId, token).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({ ...resp });
    }).catch((reason) => {
        next(reason);
    });
});

router.post('/test', function (req, res, next) {
    const customerDetailsId = req.body.id;

    return functions.testabe(customerDetailsId).then((resp) => {

        return res.status(200).send({ ...resp });
    }).catch((reason) => {
        next(reason);
    });
});

router.post('/add-navision-customer-history', async function (req, res, next) {
    req.setTimeout(3600000);
    res.setTimeout(3600000);
    const customerIds = req.body.customerIds;
    const newTopic = req.body.newTopic ? req.body.newTopic : null;      // used for pushing kafka, new custom topic name
    const test = req.body.test ? req.body.test : false;

    errorDef.parameterHandler([customerIds]);
    
    customerIds.forEach((customerId) => {
        errorDef.parameterHandler([
            customerId
        ]);
    });
    
    return functions.addNavisionCustomerHistory(customerIds, newTopic, test).then((result) => {
        return res.status(200).send(result);
    }).catch((reason) => {
        next(reason);
    });
});

module.exports = router;