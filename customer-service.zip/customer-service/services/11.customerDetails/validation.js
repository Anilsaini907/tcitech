const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateCustomerDetails: (req, res, next) => {
        req.checkBody('customerDetails', 'Customer Details object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('customerDetails.*.tenantId', 'Tenant ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.*.mAddress1', 'Customer Account Group parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.*.mPostcodeId', 'Post Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.*.mCityId', 'City parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.*.mStateId', 'Identity ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.*.mCountryId', 'Identity No parameter is invalid or missing').trim().notEmpty();
        // req.checkBody('customerDetails.*.receiveSMS', 'ReceiveSMS parameter is invalid or missing').trim().notEmpty();
        // req.checkBody('customerDetails.*.pdpaConsent', 'pdpaConsent parameter is invalid or missing').trim().notEmpty();
        // req.checkBody('customerDetails.*.pdpaSignedDate', 'pdpaSignedDate parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateCustomerDetails: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.tenantId', 'Tenant ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.mAddress1', 'Customer Account Group parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.mPostcodeId', 'Post Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.mCityId', 'City parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.mStateId', 'Identity ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.mCountryId', 'Identity No parameter is invalid or missing').trim().notEmpty();
        // req.checkBody('customerDetails.receiveSMS', 'ReceiveSMS parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.pdpaConsent', 'pdpaConsent parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerDetails.pdpaSignedDate', 'pdpaSignedDate parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteCustomerDetails: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}