const CustomerFinanceModel = require('@driveit/driveit-databases/databases/customerMaster/models/12.customerFinance');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getCustomerFinance(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;

        let custFinance = await CustomerFinanceModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond);
        for (const row of custFinance.rows) {
            if (row.paymentTermsId) {
                const PaymentTermModel = require('@driveit/driveit-databases/databases/customerMaster/models/2.paymentTerms')
                let foundPaymentTerm = await PaymentTermModel.getId({ id: row.paymentTermsId });
                if (foundPaymentTerm) {
                    row['dataValues'].paymentTerm = foundPaymentTerm.name;
                }
            }
        }

        return {
            ...custFinance,
            page: page.page,
            limit: page.limit
        };
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await CustomerFinanceModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addCustomerFinance(customerFinanceObj, who) {
        return CustomerFinanceModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(customerFinanceObj, (addCustomerFinanceObj) => {
                addCustomerFinanceObj['createdBy'] = who;
                addCustomerFinanceObj['updatedBy'] = who;
                /** blockoptions will save as JSON.stringify(array) string. Handle in frontend */
                // let blockOptionsString = "";
                // let blockOptionsArray = addCustomerFinanceObj.blockOptionsIds;
                // _.forEach(blockOptionsArray, (blockOption, index) => {
                //     if(index > 0) {
                //         blockOptionsString += ',' + blockOption;
                //     } else {
                //         blockOptionsString = blockOption;
                //     }
                // })
                // addCustomerFinanceObj['blockOptionsIds'] = blockOptionsString;
                const p = CustomerFinanceModel.addNew(addCustomerFinanceObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    
    static async updateCustomerFinance(customerFinance, where, who) {
        console.log('update CustomerFinance')
        if(where.id) {
            customerFinance['updatedBy'] = who;
            customerFinance['id'] = where.id;
            /** blockoptions will save as JSON.stringify(array) string. Handle in frontend */
            // let blockOptionsString = "";
            // let blockOptionsArray = customerFinance.blockOptionsIds;
            // _.forEach(blockOptionsArray, (blockOption, index) => {
            //     if(index > 0) {
            //         blockOptionsString += ',' + blockOption;
            //     } else {
            //         blockOptionsString = blockOption;
            //     }
            // })
            // customerFinance['blockOptionsIds'] = blockOptionsString;
            return await CustomerFinanceModel.updateCustomerFinance(customerFinance, where).then(()=>{
                return CustomerFinanceModel.getId(where).then((resp)=>{
                    if(!resp) { 
                    throw errorDef.MASTERDATA_NOT_FOUND;
                    }
                    return resp;
                });
            });
        } else {
            delete customerFinance.id;
            return this.addCustomerFinance([customerFinance], who).then((cf) => {
                return cf && cf.length ? cf[0] : {};
            })
        }
    }
    static async deleteCustomerFinance(where, who, type = "soft") {
        if(type == "soft") {
            return await CustomerFinanceModel.deleteSoft(where, who).then(()=>{
                return CustomerFinanceModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await CustomerFinanceModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;