const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');
// const es = require('../10.customer/elasticsearch');
/**
 * Search Customer Masterdata service
 * 
 * @route POST /customerFinance/search
 * @operationId searchCustomerFinance
 * @group Customer Finance API
 * @param {CustomerFinanceSearch.model} CustomerFinanceSearch.body - Search. Show all if not provided.
 * @returns {CustomerFinanceSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
        return functions.getCustomerFinance(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }

            return res.status(200).send({...resp, order, search, filter});
        }).catch((reason) => {
            next(reason);
        });
});
/**
 * Add Customer Masterdata service
 * 
 * @route POST /customerFinance/add
 * @operationId addCustomerFinance
 * @group Customer Finance API
 * @param {AddCustomerFinance.model} AddCustomerFinance.body.required - required CustomerFinance
 * @returns {Array.<CustomerFinanceData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customValidator.validateCreateCustomerFinance], async function (req, res, next) {
    const customerFinance = req.body.customerFinance;
    errorDef.parameterHandler([customerFinance]);
    _.forEach(customerFinance, (customerFinanceObj) => {
        errorDef.parameterHandler([
            customerFinanceObj.customerDetailsId,
            customerFinanceObj.customerId,
            customerFinanceObj.tenantId,
            //customerFinanceObj.companyId,
            //customerFinanceObj.customerGroupId,
            // customerFinanceObj.paymentTermsId,
            // customerFinanceObj.currencyId,
            // customerFinanceObj.creditLimit,
            // customerFinanceObj.blockOptionsIds,
            // customerFinanceObj.taxClassId
        ]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addCustomerFinance(customerFinance, userInfo.id).then(async (resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            const customerIds = resp.map((r) => r.customerId);
            // const updateES = es.updateDataByIds(customerIds, req.headers).catch(err => console.error(err));
            // await Promise.all([updateES]);
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update Customer Masterdata service
 * 
 * @route POST /customerFinance/update
 * @operationId updateCustomerFinance
 * @group Customer Finance API
 * @param {UpdateCustomerFinance.model} UpdateCustomerFinance.body.required - required CustomerFinance
 * @returns {CustomerFinanceData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', async function (req, res, next) {
    const customerFinanceId = req.body.id;
    const customerFinance = req.body.customerFinance;
    errorDef.parameterHandler([customerFinance]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: customerFinanceId };
        return functions.updateCustomerFinance(customerFinance, where, userInfo.id).then(async (resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            const customerId = resp.customerId;
            // const updateES = es.updateDataById(customerId, req.headers).catch(err => console.error(err));
            // await Promise.all([updateES]);
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete Customer Masterdata service
 * 
 * @route DELETE /customerFinance/delete
 * @operationId deleteCustomerFinance
 * @group Customer Finance API
 * @param {DeleteCustomerFinance.model} DeleteCustomerFinance.body.required - required CustomerFinance
 * @returns {Array.<CustomerFinanceData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteCustomerFinance], async function (req, res, next) {
    const customerFinanceId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([customerFinanceId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: customerFinanceId };
        return functions.deleteCustomerFinance(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export Customer Masterdata service
 * 
 * @route POST /customerFinance/export
 * @operationId exportCustomerFinance
 * @group Customer Finance API
 * @param {CustomerFinanceSearch.model} CustomerFinanceSearch.body - Search. Show all if not provided.
 * @returns {CustomerFinanceSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    
    return functions.getCustomerFinance(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows:resp.rows,
            filename:'customer_finance'
        };

        return ExportAPI.exportData(null, data).then(response =>{
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });
        
    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;