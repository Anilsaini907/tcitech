const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateCustomerFinance: (req, res, next) => {
        req.checkBody('customerFinance', 'Customer Finance object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('customerFinance.*.tenantId', 'Tenant ID parameter is invalid or missing').trim().notEmpty();
        //req.checkBody('customerFinance.*.companyId', 'Company parameter is invalid or missing').trim().notEmpty();
        //req.checkBody('customerFinance.*.customerGroupId', 'Customer Group parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerFinance.*.customerId', 'Customer ID parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateCustomerFinance: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerFinance.tenantId', 'Tenant ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerFinance.companyId', 'Company parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerFinance.customerGroupId', 'Customer Group parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerFinance.customerId', 'Customer ID parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteCustomerFinance: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}