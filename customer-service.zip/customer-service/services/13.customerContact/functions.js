const CustomerContactModel = require('@driveit/driveit-databases/databases/customerMaster/models/13.customerContact');
const ContactRelationshipModel = require('@driveit/driveit-databases/databases/customerMaster/models/5.contactRelationship');
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
var _ = require('lodash');
const customerDetailFunctions = require('../11.customerDetails/functions');

class Functions {

    static async getCustomerContact(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };

        
        if(search) {
            _.forEach(search, (searchObj) => {
                if(searchObj.colId === 'relationshipName') {
                    searchObj.colId = 'contactRelationship.name';
                } else if(searchObj.colId === 'relationshipCode') {
                    searchObj.colId = 'contactRelationship.code';
                }
            })
        }


        return CustomerContactModel.searchAll(search, null, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond).then(async (customerContactRes) => {
            _.forEach(customerContactRes.rows, (row) => {
                row.dataValues['relationshipCode'] = row.contactRelationship && row.contactRelationship.dataValues && row.contactRelationship.dataValues.code ? row.contactRelationship.dataValues.code : '';
                row.dataValues['relationshipName'] = row.contactRelationship && row.contactRelationship.dataValues && row.contactRelationship.dataValues.name ? row.contactRelationship.dataValues.name : '';
                
            });

            let searchMasterDatas = [];
            const salutationIds = customerContactRes.rows.map((row) => row.salutationId);
            if(salutationIds && salutationIds.length > 0) {
                searchMasterDatas.push({
                    masterdata: 'salutation',
                    search: [{ colId: "id", text: salutationIds }]
                });
            }
            const telCodeIds = customerContactRes.rows.map((row) => row.telCode);
            const faxCodeIds = customerContactRes.rows.map((row) => row.faxCode);
            const mobileCodeIds = customerContactRes.rows.map((row) => row.mobileCode);
            const areaOperatorCodeIds = [...telCodeIds, ...faxCodeIds, ...mobileCodeIds]
            if(areaOperatorCodeIds.length > 0) {
                searchMasterDatas.push({
                    masterdata: 'areaOperatorCode',
                    search: [{ colId: "id", text: areaOperatorCodeIds }],
                    attributes: ['id', 'code', 'updatedAt'],
                    skipInclude: true
                });
            }

            const generalCacheRes = await generalCache.getMasterDataByQuery(searchMasterDatas);

            if (generalCacheRes) {
                _.forEach(customerContactRes.rows, (r) => {
                    if (generalCacheRes.salutation && generalCacheRes.salutation.length > 0) {
                        let salutationObj = generalCacheRes.salutation.find((o) => _.isEqual(o.id, r.salutationId));
                        r.dataValues['salutation'] = salutationObj ? salutationObj.name : null;
                    }
                    if (generalCacheRes.areaOperatorCode && generalCacheRes.areaOperatorCode.length > 0) {
                        let telCodeObj = generalCacheRes.areaOperatorCode.find((o) => _.isEqual(o.id, r.telCode));
                        let faxCodeObj = generalCacheRes.areaOperatorCode.find((o) => _.isEqual(o.id, r.faxCode));
                        let mobileCodeObj = generalCacheRes.areaOperatorCode.find((o) => _.isEqual(o.id, r.mobileCode));
                        r.dataValues['telCode_telephone'] = telCodeObj ? `(${telCodeObj.code})${r.telephone}` : null;
                        r.dataValues['faxCode_fax'] = faxCodeObj ? `(${faxCodeObj.code})${r.fax}` : null;
                        r.dataValues['mobileCode_mobile'] = mobileCodeObj ? `(${mobileCodeObj.code})${r.mobile}` : null;
                    }
                });
            }
            
            return {
                ...customerContactRes,
                page: page.page,
                limit: page.limit
            };
        });
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await CustomerContactModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addCustomerContact(customerContacts, who) {
        return CustomerContactModel.sequelize.transaction(async (t) => {
            const promises = [];

            for (const addCustomerContactObj of customerContacts) {
                if (!addCustomerContactObj.customerDetailsId) {
                    const customerDetails = [
                        {
                            tenantId: addCustomerContactObj.tenantId,
                            customerId: addCustomerContactObj.customerId,
                            companyId: addCustomerContactObj.companyId,
                            mAddress1: '', // Bypass required
                            mCityId: '', // Bypass required
                            mStateId: '', // Bypass required
                            mCountryId: '', // Bypass required
                            mPostcodeId: '' // // Bypass required
                        }
                    ];
                    const [customerDetail] = await customerDetailFunctions.addCustomerDetails(customerDetails, who);
                    addCustomerContactObj.customerDetailsId = customerDetail.id;
                }
                addCustomerContactObj['createdBy'] = who;
                addCustomerContactObj['updatedBy'] = who;
                const p = CustomerContactModel.addNew(addCustomerContactObj, t);
                promises.push(p);
            }
            return Promise.all(promises);
        });
    }

    static async groupUpdateCustomerContact(detailIdOrDeletedContacts, customerContacts, who) {
        if (_.isArray(detailIdOrDeletedContacts)) {

            return CustomerContactModel.sequelize.transaction((t) => {
                var promises = [];
                
                _.forEach(customerContacts, (obj) => {
                    obj['updatedBy'] = who;
                    let p;
                    if (obj.id !== undefined && obj.id !== null) {     // update
                        p = CustomerContactModel.updateRecord(_.omit(obj, 'id'), {id: obj.id}, t);
                    } else {    // add
                        delete obj.id;
                        obj['createdBy'] = who;
                        p = CustomerContactModel.addNew(obj, t);
                    }
                    promises.push(p);
                });
    
                //delete
                _.forEach(detailIdOrDeletedContacts, (id) => {
                    let p2 = CustomerContactModel.deleteRecord({id}, t);
                    promises.push(p2);
                });
    
                return Promise.all(promises);
            });

        } else {
            let contactLists = _.map(customerContacts, (customerContact) => {
                return customerContact.customerContact;
            });

            let deleteOption = "hard";
            return this.deleteCustomerContact({customerDetailsId: detailIdOrDeletedContacts}, who, deleteOption).then((res) => {
                return this.addCustomerContact(contactLists, who).then((r) => {
                    return r;
                })
            })
        }
    }

    static async groupUpdateCustomerContactV2(detailIdOrDeletedContacts, customerContacts, who) {

        let p = [];

        let getCustDetailIds = customerContacts.map((contact) => contact.customerDetailsId);
        getCustDetailIds = _.uniq(_.compact(getCustDetailIds));
        
        const attributes = [
            'id',
            'customerId',
            'customerDetailsId',
            'tenantId',
            'relationshipId',
            'salutationId',
            'name',
            'telephone',
            'fax',
            'mobile',
            'email',
            'mareaOperatorCode',
            'fareaOperatorCode',
            'tareaOperatorCode',
            'telCode',
            'faxCode',
            'mobileCode',            
        ]
        const existingCustContacts = await CustomerContactModel.findAll({
            where: { customerDetailsId: getCustDetailIds, deleted: 0 },
            attributes
        })
        const getCurrentIds = existingCustContacts && existingCustContacts.length
            ? existingCustContacts.map((each) => each.id)
            : []
        const toAdd = [], dataIds = [];
        if(customerContacts.length) {
            customerContacts.forEach((contact) => {
                if (contact.id) {
                    dataIds.push(contact.id);
                    let allowUpdate = false;
                    const existing = existingCustContacts.find((exist) => exist.id === contact.id)
                    if (existing) {
                        for(let attribute of attributes) {
                            if (contact[attribute] !== existing[attribute]) {
                                allowUpdate = true; 
                                p.push(
                                    CustomerContactModel.update(contact, { where: { id: contact.id }} )
                                )
                                // p.push({edit: [_.omit(contact, 'id'), { where: { id: contact.id }}]})
                                break;
                            }
                        }
                    }
                } else {
                    delete contact.id;
                    contact['createdBy'] = who;
                    toAdd.push(contact);
                }
            })
            let toDeleteIds = _.difference(getCurrentIds, dataIds);
            
            if (toDeleteIds.length) {
                p.push(CustomerContactModel.update({
                    deleted: true,
                    updatedBy: who
                }, {
                    where: { id: toDeleteIds }
                }))
                // p.push({delete: { id: toDeleteIds }})
            }

            if (toAdd.length) {
                p.push(CustomerContactModel.bulkCreate(toAdd, { returning: true }));
                // p.push({add: toAdd})
            } 
        } else {
            p.push(CustomerContactModel.update({
                deleted: true,
                updatedBy: who
            }, {
                where: { id: getCurrentIds }
            }))
            // p.push({delete: { id: getCurrentIds }})
        }

        return Promise.all(p);
        
    }
    
    static async updateCustomerContact(customerContact, where, who) {
        customerContact['updatedBy'] = who;
        customerContact['id'] = where.id;
        return await CustomerContactModel.updateCustomerContact(customerContact, where).then(()=>{
            return CustomerContactModel.getId(where).then((resp)=>{
                if(!resp) { 
                    throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteCustomerContact(where, who, type = "soft") {
        if(type == "soft") {
            return await CustomerContactModel.deleteSoft(where, who).then(()=>{
                return CustomerContactModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await CustomerContactModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;