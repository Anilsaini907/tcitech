const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');
// const es = require('../es-shared/elasticsearch');
// const esCustomer = require('../10.customer/elasticsearch');
/**
 * Search Customer Masterdata service
 * 
 * @route POST /customerContact/search
 * @operationId searchCustomerContact
 * @group Customer Contact API
 * @param {CustomerContactSearch.model} CustomerContactSearch.body - Search. Show all if not provided.
 * @returns {CustomerContactSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };

    return functions.getCustomerContact(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({...resp, order, search, filter});
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add Customer Masterdata service
 * 
 * @route POST /customerContact/add
 * @operationId addCustomerContact
 * @group Customer Contact API
 * @param {AddCustomerContact.model} AddCustomerContact.body.required - required CustomerContact
 * @returns {Array.<CustomerContactData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', async function (req, res, next) {
    const customerContact = req.body.customerContact;
    errorDef.parameterHandler([customerContact]);
    if (customerContact && _.isEmpty(customerContact)) {
        return res.status(200).send({msg: 'customerContact cannot be empty'});
    } else {
        _.forEach(customerContact, (customerContactObj) => {
            errorDef.parameterHandler([
                // customerContactObj.customerDetailsId,
                customerContactObj.customerId,
                customerContactObj.tenantId,
                customerContactObj.salutationId,
                customerContactObj.name,
                // customerContactObj.relationshipId,
                // customerContactObj.telephone,
                // customerContactObj.mobile,
                // customerContactObj.email
            ]);
        });
    }
    
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        const who = userInfo.id;
        // const who = 'testuser';
        return functions.addCustomerContact(customerContact, who).then(async (resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            const customerIds = customerContact.map((r) => r.customerId);
            //comment - not used ES
            //const updateES = esCustomer.updateDataByIds(customerIds, req.headers).catch(err => console.error(err));
            //await Promise.all([updateES]);

            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update Customer Masterdata service
 * 
 * @route POST /customerContact/update
 * @operationId updateCustomerContact
 * @group Customer Contact API
 * @param {UpdateCustomerContact.model} UpdateCustomerContact.body.required - required CustomerContact
 * @returns {CustomerContactData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customValidator.validateUpdateCustomerContact], async function (req, res, next) {
    const customerContactId = req.body.id;
    const customerContact = req.body.customerContact;
    errorDef.parameterHandler([customerContactId]);
    errorDef.parameterHandler([customerContact]);
    // errorDef.parameterHandler([customerContact.code, customerContact.name]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: customerContactId };
        return functions.updateCustomerContact(customerContact, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            // es.updateCustomerContact(customerContactId,customerContact).catch(err=>console.error(err))
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update Customer Masterdata service
 * 
 * @route POST /customerContact/groupUpdate
 * @operationId Group Update CustomerContact
 * @group Customer Contact API
 * @param {GroupUpdateCustomerContact.model} GroupUpdateCustomerContact.body.required - required CustomerContact
 * @returns {CustomerContactData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/groupUpdate', async function (req, res, next) {
    // const customerContactId = req.body.id;
    const customerContacts = req.body.customerContacts;
    const customerDetailsId = req.body.customerDetailsId;
    const deletedContacts = req.body.deletedContacts;
    // errorDef.parameterHandler([customerContactId]);
    // errorDef.parameterHandler([customerContact]);
    // errorDef.parameterHandler([customerContact.code, customerContact.name]);

    let customerIds = [];

    if (!_.isEmpty(customerContacts)) {
        const tempIds = customerContacts.map((c) => c.customerId);

        if (!_.isEmpty(tempIds)) {
            customerIds = customerIds.concat(tempIds);
        }
    }
    if (!_.isEmpty(deletedContacts)) {
        const tempIds = deletedContacts.map((c) => c.customerId);

        if (!_.isEmpty(tempIds)) {
            customerIds = customerIds.concat(tempIds);
        }
    }

    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        // let where = { id: customerContactId };
        let detailIdOrDeletedContacts = deletedContacts !== undefined ? deletedContacts : customerDetailsId;
        return functions.groupUpdateCustomerContact(detailIdOrDeletedContacts, customerContacts, userInfo.id).then(async (resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            if (!_.isEmpty(customerIds)) {
                customerIds = _.uniq(customerIds);
                // const updateES = esCustomer.updateDataByIds(customerIds, req.headers).catch(err => console.error(err));
                // await Promise.all([updateES]);
            }
            
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete Customer Masterdata service
 * 
 * @route DELETE /customerContact/delete
 * @operationId deleteCustomerContact
 * @group Customer Contact API
 * @param {DeleteCustomerContact.model} DeleteCustomerContact.body.required - required CustomerContact
 * @returns {Array.<CustomerContactData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteCustomerContact], async function (req, res, next) {
    const customerContactId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([customerContactId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: customerContactId };
        return functions.deleteCustomerContact(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Export Customer Masterdata service
 * 
 * @route POST /customerContact/export
 * @operationId exportCustomerContact
 * @group Customer Contact API
 * @param {CustomerContactSearch.model} CustomerContactSearch.body - Search. Show all if not provided.
 * @returns {CustomerContactSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    
    return functions.getCustomerContact(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows:resp.rows,
            filename:'customer_conatct'
        };

        return ExportAPI.exportData(null, data).then(response =>{
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });
        
    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;