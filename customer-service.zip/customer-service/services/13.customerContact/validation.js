const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateCustomerContact: (req, res, next) => {
        req.checkBody('customerContact', 'Customer Contact object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('customerContact.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.*.tenantId', 'Tenant ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.*.salutationId', 'Salutation ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.*.customerId', 'Customer ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.*.mobile', 'Mobile parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.*.email', 'Email parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateCustomerContact: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.tenantId', 'Tenant ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.salutationId', 'Salutation ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.customerId', 'Customer ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.mobile', 'Mobile parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerContact.email', 'Email parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteCustomerContact: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}