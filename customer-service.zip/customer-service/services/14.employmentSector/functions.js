const EmploymentSectorModel = require('@driveit/driveit-databases/databases/customerMaster/models/14.employmentSector');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getEmploymentSector(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;
        return {
            ...await EmploymentSectorModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        }
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await EmploymentSectorModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addEmploymentSector(employmentSectorObj, who) {
        return EmploymentSectorModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(employmentSectorObj, (addEmploymentSectorObj) => {
                addEmploymentSectorObj['createdBy'] = who;
                addEmploymentSectorObj['updatedBy'] = who;
                const p = EmploymentSectorModel.addNew(addEmploymentSectorObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    static async updateEmploymentSector(employmentSector, where, who) {
        employmentSector['updatedBy'] = who;
        employmentSector['id'] = where.id;
        return await EmploymentSectorModel.updateEmploymentSector(employmentSector, where).then(()=>{
            return EmploymentSectorModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteEmploymentSector(where, who, type = "soft") {
        if(type == "soft") {
            return await EmploymentSectorModel.deleteSoft(where, who).then(()=>{
                return EmploymentSectorModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await EmploymentSectorModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;