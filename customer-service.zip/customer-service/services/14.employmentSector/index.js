const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');
/**
 * Search EmploymentSector Masterdata service
 * 
 * @route POST /employmentSector/search
 * @operationId searchEmploymentSector
 * @group Employment Sector API
 * @param {EmploymentSectorSearch.model} EmploymentSectorSearch.body - Search. Show all if not provided.
 * @returns {EmploymentSectorSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
        return functions.getEmploymentSector(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }

            return res.status(200).send({...resp, order, search, filter});
        }).catch((reason) => {
            next(reason);
        });
});
/**
 * Add EmploymentSector Masterdata service
 * 
 * @route POST /employmentSector/add
 * @operationId addEmploymentSector
 * @group Employment Sector API
 * @param {AddEmploymentSector.model} AddEmploymentSector.body.required - required EmploymentSector
 * @returns {Array.<EmploymentSectorData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customValidator.validateCreateEmploymentSector], async function (req, res, next) {
    const employmentSector = req.body.employmentSector;
    errorDef.parameterHandler([employmentSector]);
    _.forEach(employmentSector, (employmentSectorObj) => {
        errorDef.parameterHandler([employmentSectorObj.code, employmentSectorObj.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addEmploymentSector(employmentSector, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update EmploymentSector Masterdata service
 * 
 * @route POST /employmentSector/update
 * @operationId updateEmploymentSector
 * @group Employment Sector API
 * @param {UpdateEmploymentSector.model} UpdateEmploymentSector.body.required - required EmploymentSector
 * @returns {EmploymentSectorData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customValidator.validateUpdateEmploymentSector], async function (req, res, next) {
    const employmentSectorId = req.body.id;
    const employmentSector = req.body.employmentSector;
    errorDef.parameterHandler([employmentSectorId]);
    errorDef.parameterHandler([employmentSector]);
    // errorDef.parameterHandler([employmentSector.code, employmentSector.name]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: employmentSectorId };
        return functions.updateEmploymentSector(employmentSector, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete EmploymentSector Masterdata service
 * 
 * @route DELETE /employmentSector/delete
 * @operationId deleteEmploymentSector
 * @group Employment Sector API
 * @param {DeleteEmploymentSector.model} DeleteEmploymentSector.body.required - required EmploymentSector
 * @returns {Array.<EmploymentSectorData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteEmploymentSector], async function (req, res, next) {
    const employmentSectorId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([employmentSectorId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: employmentSectorId };
        return functions.deleteEmploymentSector(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Export EmploymentSector Masterdata service
 * 
 * @route POST /employmentSector/export
 * @operationId exportEmploymentSector
 * @group Employment Sector API
 * @param {EmploymentSectorSearch.model} EmploymentSectorSearch.body - Search. Show all if not provided.
 * @returns {EmploymentSectorSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    
    return functions.getEmploymentSector(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows:resp.rows,
            filename:'employment_sector'
        };

        return ExportAPI.exportData(null, data).then(response =>{
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });
        
    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;