const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateEmploymentSector: (req, res, next) => {
        req.checkBody('employmentSector', 'Employment Sector object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('employmentSector.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('employmentSector.*.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('employmentSector.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateEmploymentSector: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('employmentSector.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('employmentSector.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('employmentSector.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                throw retErr;
            }
        });
    },

    validateDeleteEmploymentSector: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}