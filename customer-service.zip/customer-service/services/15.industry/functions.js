const IndustryModel = require('@driveit/driveit-databases/databases/customerMaster/models/15.industry');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getIndustry(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;
        return {
            ...await IndustryModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        }
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await IndustryModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addIndustry(industryObj, who) {
        return IndustryModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(industryObj, (addIndustryObj) => {
                addIndustryObj['createdBy'] = who;
                addIndustryObj['updatedBy'] = who;
                const p = IndustryModel.addNew(addIndustryObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    static async updateIndustry(industry, where, who) {
        industry['updatedBy'] = who;
        industry['id'] = where.id;
        return await IndustryModel.updateIndustry(industry, where).then(()=>{
            return IndustryModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteIndustry(where, who, type = "soft") {
        if(type == "soft") {
            return await IndustryModel.deleteSoft(where, who).then(()=>{
                return IndustryModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await IndustryModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;