const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
const _ = require('lodash');
const customVal = require('./validation');


/**
 * Search Industry Masterdata service
 * 
 * @route POST /industry/search
 * @operationId searchIndustry
 * @group Industry API
 * @param {IndustrySearch.model} IndustrySearch.body - Search. Show all if not provided.
 * @returns {IndustrySearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search',  function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    return functions.getIndustry(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});
/**
 * Add Industry Masterdata service
 * 
 * @route POST /industry/add
 * @operationId addIndustry
 * @group Industry API
 * @param {AddIndustry.model} AddIndustry.body.required - required Industry
 * @returns {Array.<IndustryData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', async function (req, res, next) {
    const industry = req.body.industry;
    // errorDef.parameterHandler([industry]);
    _.forEach(industry, (industryObj) => {
        errorDef.parameterHandler([industryObj.code, industryObj.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addIndustry(industry, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update Industry Masterdata service
 * 
 * @route POST /industry/update
 * @operationId updateIndustry
 * @group Industry API
 * @param {UpdateIndustry.model} UpdateIndustry.body.required - required Industry
 * @returns {IndustryData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customVal.validateUpdateIndustryData], async function (req, res, next) {
    const industryId = req.body.id;
    const industry = req.body.industry;
    errorDef.parameterHandler([industryId]);
    errorDef.parameterHandler([industry]);
    // errorDef.parameterHandler([industry.code, industry.name]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: industryId };
        return functions.updateIndustry(industry, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete Industry Masterdata service
 * 
 * @route DELETE /industry/delete
 * @operationId deleteIndustry
 * @group Industry API
 * @param {DeleteIndustry.model} DeleteIndustry.body.required - required Industry
 * @returns {Array.<IndustryData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customVal.validateDeleteIndustryData], async function (req, res, next) {
    const industryId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([industryId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: industryId };
        return functions.deleteIndustry(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export Industry Masterdata service
 * 
 * @route POST /industry/export
 * @operationId exportIndustry
 * @group Industry API
 * @param {IndustrySearch.model} IndustrySearch.body - Search. Show all if not provided.
 * @returns {IndustrySearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }

    return functions.getIndustry(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows: resp.rows,
            filename: 'industry'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;