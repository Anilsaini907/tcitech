const AnnualIncomeModel = require('@driveit/driveit-databases/databases/customerMaster/models/16.annualIncome');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getAnnualIncome(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;
        return {
            ...await AnnualIncomeModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        }
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await AnnualIncomeModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addAnnualIncome(annualIncomeObj, who) {
        return AnnualIncomeModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(annualIncomeObj, (addAnnualIncomeObj) => {
                addAnnualIncomeObj['createdBy'] = who;
                addAnnualIncomeObj['updatedBy'] = who;
                const p = AnnualIncomeModel.addNew(addAnnualIncomeObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    static async updateAnnualIncome(annualIncome, where, who) {
        annualIncome['updatedBy'] = who;
        annualIncome['id'] = where.id;
        return await AnnualIncomeModel.updateAnnualIncome(annualIncome, where).then(()=>{
            return AnnualIncomeModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteAnnualIncome(where, who, type = "soft") {
        if(type == "soft") {
            return await AnnualIncomeModel.deleteSoft(where, who).then(()=>{
                return AnnualIncomeModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await AnnualIncomeModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;