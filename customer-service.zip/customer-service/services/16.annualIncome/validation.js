
const errorcodes = require('../services.config/error.codes');
const self = module.exports = {

    validateAnnualIncomeData: (req, res, next) => {
        req.checkBody('annualIncome', 'annualIncome parameter missing').trim().notEmpty().isArray();
        req.checkBody('annualIncome.*.code', 'code paramter is missing').trim().notEmpty();
        req.checkBody('annualIncome.*.name', 'name paramter is missing').trim().notEmpty();
        // req.checkBody('annualIncome.*.status', 'status paramter is missing').trim().notEmpty();
        // req.checkBody('annualIncome.*.inactivateReason', 'Inactivate Reason paramter is missing').trim().notEmpty().optional();

        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },
    validateUpdateAnnualIncomeData: (req, res, next) => {
        req.checkBody('id', 'id parameter missing').trim().notEmpty();
        req.checkBody('annualIncome', 'annualIncome parameter missing').custom(val => {
            return new Promise((resolve, reject) => {
                if (val.code === null || val.code === undefined || val.code === '') {
                    reject();
                } else if (val.name === null || val.name === undefined || val.name === '') {
                    reject();
                }
                /* else if (val.status === null || val.status === undefined || val.status === '') {
                    reject();
                } else if (val.status === 'disabled') {
                    if (val.inactivateReason === null || val.inactivateReason === undefined || val.inactivateReason === '') {

                        reject();
                    } else {
                        resolve();
                    }
                } */
                else {
                    resolve();
                }
            })


        });
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateSearchAnnualIncomeData: (req, res, next) => {
        req.checkBody('page', 'page parameter missing').trim().notEmpty();
        req.checkBody('limit', 'limit parameter missing').trim().notEmpty();
        req.checkBody('order', 'order parameter missing').trim().notEmpty();
        req.checkBody('order.columnName', 'columnName parameter missing').trim().notEmpty();
        req.checkBody('order.direction', ' direction parameter missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateDeleteAnnualIncomeData: (req, res, next) => {
        req.checkBody('id', 'id parameter missing').trim().notEmpty();
        req.checkBody('option', 'option parameter missing').trim().notEmpty();

        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    }

}