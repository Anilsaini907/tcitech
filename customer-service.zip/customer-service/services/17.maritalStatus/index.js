const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customVal = require('./validation');
/**
 * Search MaritalStatus Masterdata service
 * 
 * @route POST /maritalStatus/search
 * @operationId searchMaritalStatus
 * @group Marital Status API
 * @param {MaritalStatusSearch.model} MaritalStatusSearch.body - Search. Show all if not provided.
 * @returns {MaritalStatusSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    return functions.getMaritalStatus(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});
/**
 * Add MaritalStatus Masterdata service
 * 
 * @route POST /maritalStatus/add
 * @operationId addMaritalStatus
 * @group Marital Status API
 * @param {AddMaritalStatus.model} AddMaritalStatus.body.required - required MaritalStatus
 * @returns {Array.<MaritalStatusData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', async function (req, res, next) {
    const maritalStatus = req.body.maritalStatus;
    errorDef.parameterHandler([maritalStatus]);
    _.forEach(maritalStatus, (maritalStatusObj) => {
        errorDef.parameterHandler([maritalStatusObj.code, maritalStatusObj.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addMaritalStatus(maritalStatus, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update MaritalStatus Masterdata service
 * 
 * @route POST /maritalStatus/update
 * @operationId updateMaritalStatus
 * @group Marital Status API
 * @param {UpdateMaritalStatus.model} UpdateMaritalStatus.body.required - required MaritalStatus
 * @returns {MaritalStatusData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', async function (req, res, next) {
    const maritalStatusId = req.body.id;
    const maritalStatus = req.body.maritalStatus;
    errorDef.parameterHandler([maritalStatusId]);
    errorDef.parameterHandler([maritalStatus]);
    // errorDef.parameterHandler([maritalStatus.code, maritalStatus.name]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: maritalStatusId };
        return functions.updateMaritalStatus(maritalStatus, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete MaritalStatus Masterdata service
 * 
 * @route DELETE /maritalStatus/delete
 * @operationId deleteMaritalStatus
 * @group Marital Status API
 * @param {DeleteMaritalStatus.model} DeleteMaritalStatus.body.required - required MaritalStatus
 * @returns {Array.<MaritalStatusData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', async function (req, res, next) {
    const maritalStatusId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([maritalStatusId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: maritalStatusId };
        return functions.deleteMaritalStatus(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Export MaritalStatus Masterdata service
 * 
 * @route POST /maritalStatus/export
 * @operationId exportMaritalStatus
 * @group Marital Status API
 * @param {MaritalStatusSearch.model} MaritalStatusSearch.body - Search. Show all if not provided.
 * @returns {MaritalStatusSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }

    return functions.getMaritalStatus(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows: resp.rows,
            filename: 'marital_status'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;