const _ = require('lodash');

class SearchFunction {
  static convertField(flatField) {
    switch (flatField) {
      case 'companyId':
      case 'branchId':
        return {
          key: flatField,
          table: 'A'
        };
      case 'filterWithBusinessTypeMake':
        return {
          key: 'makeId',
          table: 'J'
        }
      case 'filterWithBusinessType':
        return {
          key: flatField,
          table: 'K',
        }

      default:
        return {
          key: flatField,
          table: 'A'
        };
    }
  }

  static generateQueryParameter(search, filter) {
    const queries = {
      'A': [
        { colId: 'deleted', operator: '=', text: '0' },
      ], // branch
      'B': [], // company
      'C': [], // country
      'D': [], // currency
      'E': [], // postcode
      'F': [], // city
      'G': [], // state
      'H': [], // costCenter
      'I': [], // profitCenter
      'J': [], // branchMakeBusinessType
      'K': [], // businessType
    };

    if (search) {
      _.forEach(search, (searchObj) => {
        const col = this.convertField(searchObj.colId);

        if (col.keys) {
          _.forEach(searchObj.text, (likeArrItem) => {
            queries[col.table].push({ colId: searchObj.colId, keys: col.keys, operator: 'LIKE', text: `%${likeArrItem}%` });
          });
        } else {
          _.forEach(searchObj.text, (likeArrItem) => {
            queries[col.table].push({ colId: col.key, operator: 'LIKE', text: `%${likeArrItem}%` });
          });
        }
      });
    }

    if (filter) {
      _.forEach(filter, (filterObj) => {
        const col = this.convertField(filterObj.colId);

        if (filterObj.colId === 'id' && filterObj.filterCondition) {
          const operator = filterObj.filterCondition[0].direction === 'ne' ? '<>' : 'IN';

          queries[col.table].push({ colId: col.key, operator: operator, text: filterObj.text[0] });
        } else {
          const arr = filterObj.text.map(item => `'${item}'`);
          queries[col.table].push({ colId: col.key, operator: 'IN', text: `(${arr.join(',')})` });
        }
      });
    }

    return queries;
  }

  static generateWhereCondition(queryParamters, dropdownField) {
    const where = [];
    const preDropdownChild = [];

    Object.keys(queryParamters).forEach(key => {
      const query = queryParamters[key];

      if (query.length > 0) {
        const preQuery = [];

        const group = _.groupBy(query, 'colId');
        Object.keys(group).forEach(columnName => {
          const columnConditions = group[columnName];

          switch (columnName) {
            case 'filterWithBusinessType':
              preQuery.push(`LOCATE((SELECT id FROM customer_master.businessType WHERE deleted = 0 AND name IN ${columnConditions[0].text}), J.businessTypeIds) > 0`);
              break;

              case 'code':
                case 'name':
                  if (columnConditions.length > 0) {
                    const preQueryChild = [];
    
                    _.forEach(columnConditions, columnCondition => {
                      switch (columnCondition.operator) {
                        case 'IN':
                        case 'BETWEEN':
                          dropdownField == true ?  preDropdownChild.push(`${key}.${columnName} ${columnCondition.operator} ${columnCondition.text}`) : 
                          preQueryChild.push(`${key}.${columnName} ${columnCondition.operator} ${columnCondition.text}`)
                          ;
                         
                          break;
    
                        default:
                          dropdownField == true ?  preDropdownChild.push(`${key}.${columnName} ${columnCondition.operator} '${columnCondition.text}'`) : 
                          preQueryChild.push(`${key}.${columnName} ${columnCondition.operator} '${columnCondition.text}'`)
                          ;
                          break;
                      }
                    });
                     dropdownField == true &&  preDropdownChild.length > 1 ? preQuery.push('(' + preDropdownChild.join(' OR ') + ')') 
                     : preQueryChild.length >= 1 ?  preQuery.push('(' + preQueryChild.join(' OR ') + ')') : '';
                    //preQuery.push('(' + preQueryChild.join(' OR ') + ')');
                  }
                
                  break;
                  
            default:
              if (columnConditions.length > 0) {
                const preQueryChild = [];

                _.forEach(columnConditions, columnCondition => {
                  switch (columnCondition.operator) {
                    case 'IN':
                    case 'BETWEEN':
                      preQueryChild.push(`${key}.${columnName} ${columnCondition.operator} ${columnCondition.text}`);
                      break;

                    default:
                      preQueryChild.push(`${key}.${columnName} ${columnCondition.operator} '${columnCondition.text}'`);
                      break;
                  }
                });

                preQuery.push('(' + preQueryChild.join(' OR ') + ')');
              }
              break;
          }
        });

        where.push('(' + preQuery.join(' AND ') + ')');
      }
    });

    return where;
  }

  static generateOrderCondition(order) {
    const orders = [];

    if (order) {
      const col = this.convertField(order.columnName);

      if (col.keys) {
        _.forEach(col.keys, (key) => {
          orders.push(`${col.table}.${key} ${order.direction}`);
        });
      } else {
        orders.push(`${col.table}.${col.key} ${order.direction}`);
      }
    }

    return orders;
  }

  static getSearchSql(whereStatement, orderStatement, offset, limit, showAll) {
    const limitQuery = showAll ? '' : `LIMIT ${offset}, ${limit}`;

    const sql = `
      SELECT DISTINCT
        A.id
        , A.code
        , A.name
        , CONCAT(A.code, ' - ', A.name) as fullName
        , A.address1
        , A.address2
        , A.address3
        , B.id		AS companyId
        , B.code	AS companyCode
        , B.name	AS companyName
        , C.id		AS countryId
        , C.code	AS countryCode
        , C.name	AS countryName
        , D.id		AS currencyId
        , D.code	AS currencyCode
        , D.name	AS currencyName
        , E.id		AS postcodeId
        , E.code	AS postcodeCode
        , F.id		AS cityId
        , F.code	AS cityCode
        , F.name 	AS cityName
        , G.id		AS stateId
        , G.code	AS stateCode
        , G.name	AS stateName
        , H.id 		AS costCenterId
        , H.code	AS costCenterCode
        , H.name	AS costCenterName
        , I.id		AS profitCenterId
        , I.code	AS profitCenterCode
        , I.name 	AS profitCenterName
      
      FROM customer_master.branch 	A
        LEFT JOIN customer_master.company 	  B ON B.deleted = 0 AND B.id = A.companyId
        LEFT JOIN general_master.country		  C ON C.deleted = 0 AND C.id = A.countryId
        LEFT JOIN general_master.currency 	  D ON D.deleted = 0 AND D.id = A.currencyId
        LEFT JOIN general_master.postcode		  E ON E.deleted = 0 AND E.id = A.postcodeId
        LEFT JOIN general_master.city			    F ON F.deleted = 0 AND F.id = A.cityId
        LEFT JOIN general_master.state			  G ON G.deleted = 0 AND G.id = A.stateId
        LEFT JOIN service_master.costCenter	  H ON H.deleted = 0 AND H.id = A.costCenterId
        LEFT JOIN service_master.profitCenter	I ON I.deleted = 0 AND I.id = A.profitCenterId
        
        LEFT JOIN customer_master.branchMakeBusinessType J ON J.deleted = 0 AND J.branchId = A.id

			WHERE ${whereStatement}
			ORDER BY ${orderStatement}
			${limitQuery}`;

    const sqlCount = `
      SELECT COUNT(distinct A.id) AS count
      
      FROM customer_master.branch 	A
        LEFT JOIN customer_master.company 	  B ON B.deleted = 0 AND B.id = A.companyId
        LEFT JOIN general_master.country		  C ON C.deleted = 0 AND C.id = A.countryId
        LEFT JOIN general_master.currency 	  D ON D.deleted = 0 AND D.id = A.currencyId
        LEFT JOIN general_master.postcode		  E ON E.deleted = 0 AND E.id = A.postcodeId
        LEFT JOIN general_master.city			    F ON F.deleted = 0 AND F.id = A.cityId
        LEFT JOIN general_master.state			  G ON G.deleted = 0 AND G.id = A.stateId
        LEFT JOIN service_master.costCenter	  H ON H.deleted = 0 AND H.id = A.costCenterId
        LEFT JOIN service_master.profitCenter	I ON I.deleted = 0 AND I.id = A.profitCenterId
        
        LEFT JOIN customer_master.branchMakeBusinessType J ON J.deleted = 0 AND J.branchId = A.id
      WHERE ${whereStatement}`;

    return { sql, sqlCount };
  }

  static generateSearchSql(page, limit, order, search, filter, showAll, dropdownField = false) {
    const queryParamter = this.generateQueryParameter(search, filter);
    const where = this.generateWhereCondition(queryParamter, dropdownField);
    const orders = this.generateOrderCondition(order);

    const whereStatement = where.join(' AND ');
    const orderStatement = orders.join(', ');
    const offset = limit * (page - 1);

    return this.getSearchSql(whereStatement, orderStatement, offset, limit, showAll);
  }

  static getBranchBankAccountSql(branchIds) {
    const ids = branchIds.map(x => `'${x}'`);

    return `
      SELECT id, accountName, accountNumber, branchId
      FROM customer_master.branchBankAccounts
      WHERE deleted = 0 AND branchId IN (${ids.join(',')})
    `;
  }
}

module.exports = SearchFunction;