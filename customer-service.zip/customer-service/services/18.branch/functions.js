const Sequelize = require("sequelize");
const Op = Sequelize.Op;
var _ = require('lodash');

const db = require('@driveit/driveit-databases/databases/customerMaster');

const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');
const generalCache = require('../cache-request/general-api');

const BranchModel = require('@driveit/driveit-databases/databases/customerMaster/models/18.branch');
const StorageLocationModel = require('@driveit/driveit-databases/databases/customerMaster/models/20.storageLocation');
const StorageModel = require('@driveit/driveit-databases/databases/customerMaster/models/25.storage');
const BranchRouteModel = require('@driveit/driveit-databases/databases/customerMaster/models/31.branchRoutes')
const CompanyBranch = require('@driveit/driveit-databases/databases/customerMaster/models/24.companyBranch');
const CompanyModel = require('@driveit/driveit-databases/databases/customerMaster').Company;
const BranchMakeBusinessTypeModel = require('@driveit/driveit-databases/databases/customerMaster/models/36.branchMakeBusinessTypes');
const ClockIndicatorModel = require('@driveit/driveit-databases/databases/serviceMaster/models/110.clockIndicator');

const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const CurrencyModel = require('@driveit/driveit-databases/databases/generalMaster/models/14.currency');
const PostCodeModel = require('@driveit/driveit-databases/databases/generalMaster/models/04.postcode');
const CityModel = require('@driveit/driveit-databases/databases/generalMaster/models/03.city');
const StateModel = require('@driveit/driveit-databases/databases/generalMaster/models/02.state');
const RegionModel = require('@driveit/driveit-databases/databases/generalMaster/models/07.region');
const ProfitCenterModel = require('@driveit/driveit-databases/databases/serviceMaster').ProfitCenter;

const BranchBankAccounts = require('@driveit/driveit-databases/databases/customerMaster/models/37.branchBankAccounts')

const searchFunction = require('./function.search');
const customerMasterDb = require('@driveit/driveit-databases/databases/customerMaster');

class Functions {

    static async search(page, limit, order, searches, filter, basicSearch = false, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };

        if (searches) {
            let excludedSearch = _.remove(searches, (o) => { return o.colId === 'stateName' || o.colId === 'cityName' || o.colId === 'postcodeCode' || o.colId === 'countryCode'; });
            let searched = await this.prepQry(excludedSearch);
            searches = _.concat(searches, searched);
        }

        let attr = null;
        let orderBy = [order.columnName, order.direction];


        let isFilterWithBsTypeService = false;

        const filterWithBusinessType = filter ? filter.find(x => x.colId === 'filterWithBusinessType') : null;

        let businessTypeServiceId = '';

        if (filterWithBusinessType) {
            if (filterWithBusinessType.text.find(x => x === 'service')) {
                isFilterWithBsTypeService = true;
                const sql = `SELECT * FROM customer_master.businessType
                            WHERE code = 20 AND deleted = 0
                            LIMIT 1`
                const businessTypeService = await db.sequelize.query(sql, { type: Sequelize.QueryTypes.SELECT });

                if (businessTypeService.length > 0) {
                    businessTypeServiceId = businessTypeService[0].id;
                }
            }

            filter = filter.filter(x => x.colId !== 'filterWithBusinessType');
        }

        const filterWithBusinessTypeMake = filter ? filter.find(x => x.colId === 'filterWithBusinessTypeMake') : null;

        let BusinessTypeMakeId = '';

        if (filterWithBusinessTypeMake) {
            BusinessTypeMakeId = filterWithBusinessTypeMake.text[0];
            filter = filter.filter(x => x.colId !== 'filterWithBusinessTypeMake');
        }


        let recordResults;
        if (basicSearch) {
            // attr = ['id', 'code', 'name', 'companyId'];
            recordResults = await BranchModel.searchAll(searches, attr, pagination, orderBy, filter, true, showAll, false, [], null, distKeys, searchOrCond);
        } else {
            recordResults = await BranchModel.searchAll(searches, attr, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
        }
        if (!basicSearch && recordResults && recordResults.rows && _.size(recordResults.rows) > 0) {

            if (isFilterWithBsTypeService && businessTypeServiceId) {
                recordResults.rows = _.filter(recordResults.rows, (branch) => {
                    if (_.size(branch.branchMakeBusinessTypes) > 0) {
                        const branchWithBusinessTypeService = branch.branchMakeBusinessTypes.find(branchMakeBusinessType => {
                            const isService = branchMakeBusinessType.businessTypeIds.search(businessTypeServiceId);
                            let isMake = true;

                            if (BusinessTypeMakeId) {
                                isMake = (branchMakeBusinessType.makeId === BusinessTypeMakeId);
                            }

                            if (isService !== -1 && isMake) {
                                return true;
                            }
                        });
                        if (branchWithBusinessTypeService) {
                            return true;
                        }
                    } else {
                        return true;
                    }

                    return false;
                });
                recordResults.count = recordResults.rows.length;
            }

            let currencyIds = _.uniq(_.without(_.map(recordResults.rows, 'currencyId'), null, ''));
            let regionIds = _.uniq(_.without(_.map(recordResults.rows, 'regionId'), null, ''));
            let companyIds = _.uniq(_.without(_.map(recordResults.rows, 'companyId'), null, ''));
            let profitCenterId = _.uniq(_.without(_.map(recordResults.rows, 'profitCenterId'), null, ''));

            let searchGeneralMaster = [];
            searchGeneralMaster.push({
                masterdata: "currency",
                search: [{ colId: "id", text: !_.isEmpty(currencyIds) ? currencyIds : [null] }],
                skipInclude: true,
                attributes: ['id', 'code', 'name', 'updatedAt']
            });
            searchGeneralMaster.push({
                masterdata: "region",
                search: [{ colId: "id", text: !_.isEmpty(regionIds) ? regionIds : [null] }],
                skipInclude: true,
                attributes: ['id', 'code', 'name', 'updatedAt']
            });

            let queryResult = await generalCache.getMasterDataByQuery(searchGeneralMaster);
            let currencies = queryResult && queryResult.currency ? _.map(queryResult.currency, 'dataValues') : [];
            let regions = queryResult && queryResult.region ? _.map(queryResult.region, 'dataValues') : [];
            const company = await CompanyModel.getOne({
                id: companyIds
            })
            let profitCenter = await ProfitCenterModel.getOne({
                id: profitCenterId
            })

            _.forEach(recordResults.rows, (r) => {
                let foundCurrency = _.find(currencies, (o) => { return o.id === r.currencyId; });
                r.dataValues['currencyName'] = foundCurrency ? foundCurrency.name : null;
                r.dataValues['currencyCode'] = foundCurrency ? foundCurrency.code : null;

                let foundRegion = _.find(regions, (o) => { return o.id === r.regionId; });
                r.dataValues['regionName'] = foundRegion ? foundRegion.name : null;
                r.dataValues['regionCode'] = foundRegion ? foundRegion.code : null;

                r.dataValues['companyName'] = company ? company.name : null;
                r.dataValues['companyCode'] = company ? company.code : null;

                r.dataValues['profitCenterName'] = profitCenter ? profitCenter.name : null
                r.dataValues['profitCenterCode'] = profitCenter ? profitCenter.code : null;
            });
        }

        return recordResults;
    }

    static async searchForDropdown(page, limit, order, search, filter, showAll = false, source, dropdownField = false) {
        const sqlStatement = searchFunction.generateSearchSql(page, limit, order, search, filter, showAll, dropdownField);

        const countResult = await customerMasterDb.sequelize.query(sqlStatement.sqlCount, { type: Sequelize.QueryTypes.SELECT });
        const result = await customerMasterDb.sequelize.query(sqlStatement.sql, { type: Sequelize.QueryTypes.SELECT });

        if (result && result.length && source === 'OrderEdit') {
            const branchIds = result.map(x => x.id);

            const branchBankAccountSql = searchFunction.getBranchBankAccountSql(branchIds);
            const branchBankAccounts = await customerMasterDb.sequelize.query(branchBankAccountSql, { type: Sequelize.QueryTypes.SELECT });

            return {
                count: countResult && countResult.length > 0 ? countResult[0].count : 0,
                rows: result.map(x => ({
                    ...x,
                    branchBankAccounts: branchBankAccounts && branchBankAccounts.length
                        ? branchBankAccounts.filter(y => y.branchId === x.id)
                        : []
                }))
            };
        }

        return {
            count: countResult && countResult.length > 0 ? countResult[0].count : 0,
            rows: result
        };
    }

    static async prepQry(searches) {
        let likeArr = [];
        let searchMasterDatas = [];
        for (let i = 0; i < _.size(searches); i++) {
            if (searches[i].colId === 'stateName' || searches[i].colId === 'cityName' || searches[i].colId === 'postcodeCode' || searches[i].colId === 'countryCode') {

                if (searches[i].colId === 'stateName') {
                    searchMasterDatas.push({
                        masterdata: 'state',
                        search: [{ colId: "name", text: searches[i].text }]
                    });
                }

                if (searches[i].colId === 'cityName') {
                    searchMasterDatas.push({
                        masterdata: 'city',
                        search: [{ colId: "name", text: searches[i].text }]
                    });
                }

                if (searches[i].colId === 'postcodeCode') {
                    searchMasterDatas.push({
                        masterdata: 'postcode',
                        search: [{ colId: "code", text: searches[i].text }]
                    });
                }

                if (searches[i].colId === 'countryCode') {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "code", text: searches[i].text }]
                    });
                }
            }
        }

        let queryResult = await generalCache.getMasterDataByQuery(searchMasterDatas);
        if (queryResult) {
            if (queryResult.state) {
                let stateIds = [];
                queryResult.state.forEach((state) => {
                    stateIds.push(state.id);
                });
                likeArr.push({ colId: 'stateId', text: !_.isEmpty(stateIds) ? stateIds : ['00000000-0000-0000-0000-000000000000'] });
            }

            if (queryResult.city) {
                let cityIds = [];
                queryResult.city.forEach((city) => {
                    cityIds.push(city.id);
                });
                likeArr.push({ colId: 'cityId', text: !_.isEmpty(cityIds) ? cityIds : ['00000000-0000-0000-0000-000000000000'] });
            }

            if (queryResult.postcode) {
                let postcodeIds = [];
                queryResult.postcode.forEach((postcode) => {
                    postcodeIds.push(postcode.id);
                });
                likeArr.push({ colId: 'postcodeId', text: !_.isEmpty(postcodeIds) ? postcodeIds : ['00000000-0000-0000-0000-000000000000'] });
            }

            if (queryResult.country) {
                let countrycodeIds = [];
                queryResult.country.forEach((country) => {
                    countrycodeIds.push(country.id);
                });
                likeArr.push({ colId: 'countryId', text: !_.isEmpty(countrycodeIds) ? countrycodeIds : ['00000000-0000-0000-0000-000000000000'] });
            }
        }
        return likeArr;
    }

    static async getAll(page) {
        const pagination = {
            limit: page.limit,
            offset: limit ? limit * (page - 1) : undefined,
        }
        let q = {};
        let attr = null;

        return BranchModel.getAll(q, likeArr, attr, pagination, orderBy, filter).then((recordResults) => {
            let masterdataTypes = ["country", "currency", "postcode", "city", "state", "region"];
            let token = page.token ? page.token : null;
            return generalCache.processMasterdataResult(recordResults.rows, masterdataTypes, token).then((mdResults) => {
                _.forEach(recordResults.rows, (row) => {
                    let mObj = {};
                    _.forEach(recordResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if (c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });
                        if (mObj[key] && mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    });
                });
                generalCache.processRowRecords(recordResults, mdResults);
                return recordResults;
            });
        });
    }

    static async addMany(branches, who) {
        let promises = [];

        for (let t = 0; t < branches.length; t++) {
            let branch = branches[t];
            branch['updatedBy'] = who;
            branch['createdBy'] = who;

            promises.push(BranchModel.addRecord(branch));
        }

        return Promise.all(promises);
    }

    static async addStorageLocationsNRoutes(branches, result, who) {
        var promises = [];
        if (!_.isEmpty(branches)) {
            for (let a = 0; a < branches.length; a++) {
                let branch = branches[a];
                let foundBranch = _.find(result, (o) => { return o.code === branch.code && o.name === branch.name });
                if (branch && !_.isEmpty(branch.storageLocations)) {
                    for (let b = 0; b < branch.storageLocations.length; b++) {
                        let storageLocation = branch.storageLocations[b];

                        // handle for MAIN ADDRESS
                        if (storageLocation['storageId'] === null) {
                            let foundStorage = await StorageModel.getId({ code: storageLocation.storage.code, name: storageLocation.storage.name });
                            if (foundStorage) {
                                storageLocation['storageId'] = foundStorage.id;
                            } else {
                                let addStorage = await StorageModel.addRecord({
                                    code: storageLocation.storage.code,
                                    name: storageLocation.storage.name,
                                    createdBy: 'system',
                                    updatedBy: 'system'
                                });
                                if (addStorage) {
                                    storageLocation['storageId'] = addStorage.id;
                                }
                            }
                        }

                        storageLocation['branchId'] = foundBranch ? foundBranch.id : null;
                        storageLocation['createdBy'] = who;
                        storageLocation['updatedBy'] = who;

                        if (storageLocation.rfIdPoleNo && !_.isEmpty(storageLocation.rfIdPoleNo)) {
                            let rfIdPoleNo = _.cloneDeep(storageLocation.rfIdPoleNo);
                            if (Utils.isJsonString(storageLocation.rfIdPoleNo)) {
                                rfIdPoleNo = JSON.stringify(_.sortBy(JSON.parse(storageLocation.rfIdPoleNo)));
                            } else {
                                if (_.isArray(storageLocation.rfIdPoleNo)) {
                                    rfIdPoleNo = JSON.stringify(_.sortBy(storageLocation.rfIdPoleNo));
                                }
                            }

                            storageLocation['rfIdPoleNo'] = rfIdPoleNo;
                        }

                        let p = StorageLocationModel.addNew(storageLocation);
                        promises.push(p);

                    }
                }
                _.forEach(branch.routes, (route) => {
                    route['branchId'] = foundBranch ? foundBranch.id : null;
                    route['createdBy'] = who;
                    route['updatedBy'] = who;
                    let p2 = BranchRouteModel.addNew(route);
                    promises.push(p2);
                });


                let companyBranch = {
                    countryId: branch.countryId,
                    companyId: branch.companyId,
                    branchId: foundBranch.id,
                    //status: this.status.value ? "enabled" : "disabled",
                    //inactivateReason: this.inactivateReason.value,
                    updatedBy: who,
                    createdBy: who
                };
                let p3 = CompanyBranch.addRecord(companyBranch);
                promises.push(p3);

                let dataInsert = [];
                _.forEach(branch.makes, (make) => {
                    dataInsert.push({
                        branchId: foundBranch.id,
                        makeId: make.parentId,
                        businessTypeIds: JSON.stringify(make.id),
                        createdBy: who,
                        updatedBy: who,
                    });
                });
                const branchMakeBusinessType = BranchMakeBusinessTypeModel.bulkCreate(dataInsert);
                promises.push(branchMakeBusinessType);

                if (branch.bankAccounts && branch.bankAccounts.length) {
                    _.forEach(branch.bankAccounts, (r) => {
                        r['branchId'] = foundBranch ? foundBranch.id : null;
                        r['createdBy'] = who;
                        r['updatedBy'] = who;
                        promises.push(BranchBankAccounts.addNew(r));
                    });
                }

            }
        }
        return Promise.all(promises);
    }

    static async addClockIndicator(result, who) {
        let promises = [];
        const branchIds = result.map(x => x.id);
        const clockIndicators = await ClockIndicatorModel.getAll({ branchId: { [Op.in]: branchIds }, deleted: { [Op.not]: true } });

        _.forEach(result, (branch) => {
            if (!clockIndicators.find(x => x.branchId === branch.id)) {
                const clockIndicator = {
                    branchId: branch.id,
                    indicatorCode: '01',
                    indicatorName: 'Time Recording Terminal',
                    status: 'enabled',
                    deleted: false,
                    createdBy: who,
                    updatedBy: who
                };
                promises.push(ClockIndicatorModel.addRecord(clockIndicator));
            }
        });

        return Promise.all(promises);
    }

    static async update(id, branch, who) {
        let promises = [];
        const where = {
            id
        };

        branch['updatedBy'] = who;
        branch['id'] = id;

        await BranchRouteModel.deleteHard({ branchId: id });
        if (branch.routes && branch.routes.length) {
            _.forEach(branch.routes, (route) => {
                route['updatedBy'] = who;
                route['createdBy'] = who;
                route['branchId'] = id;
                let a = BranchRouteModel.addRecord(route);
                promises.push(a);
            });
        }

        await BranchBankAccounts.deleteHard({ branchId: id });
        if (branch.bankAccounts && branch.bankAccounts.length) {
            _.forEach(branch.bankAccounts, (route) => {
                route['updatedBy'] = who;
                route['createdBy'] = who;
                route['branchId'] = id;
                let a = BranchBankAccounts.addRecord(route);
                promises.push(a);
            });
        }

        await BranchMakeBusinessTypeModel.deleteHard({ branchId: id });
        const dataInsert = [];
        _.forEach(branch.makes, (make) => {
            const data = {
                branchId: id,
                makeId: make.parentId,
                businessTypeIds: JSON.stringify(make.id),
                createdBy: who,
                updatedBy: who,
            }
            dataInsert.push(data);
        });
        if (!_.isEmpty(dataInsert)) {
            promises.push(BranchMakeBusinessTypeModel.bulkCreate(dataInsert));
        }

        // storage locations
        let promises2 = [];
        if (!_.isEmpty(branch.storageLocations)) {
            let ids = _.without(_.map(branch.storageLocations, 'id'), null, '', undefined);
            let filterArr = [
                { colId: 'branchId', text: [id] },
                { colId: 'id', text: [ids], filterCondition: [{ direction: "notIn" }] }
            ];
            let slResult = await StorageLocationModel.searchAll([], ['id', 'updatedAt'], {}, ['updatedAt', 'desc'], filterArr, true, false, true);
            let idsToDelete = _.map(slResult, 'id');
            await StorageLocationModel.deleteHard({ id: { [Op.in]: idsToDelete } });

            for (let a = 0; a < branch.storageLocations.length; a++) {
                let p = branch.storageLocations[a];

                // handle for MAIN ADDRESS
                if (p.storageId === undefined || p.storageId === null) {
                    let foundStorage = await StorageModel.getId({ code: p.storage.code, name: p.storage.name });
                    if (foundStorage) {
                        p['storageId'] = foundStorage.id;
                    } else {
                        let addStorage = await StorageModel.addRecord({
                            code: p.storage.code,
                            name: p.storage.name,
                            createdBy: 'system',
                            updatedBy: 'system'
                        });
                        if (addStorage) {
                            p['storageId'] = addStorage.id;
                        }
                    }
                }


                if (p.rfIdPoleNo && !_.isEmpty(p.rfIdPoleNo)) {
                    let rfIdPoleNo = _.cloneDeep(p.rfIdPoleNo);
                    if (Utils.isJsonString(p.rfIdPoleNo)) {
                        rfIdPoleNo = JSON.stringify(_.sortBy(JSON.parse(p.rfIdPoleNo)));
                    } else {
                        if (_.isArray(p.rfIdPoleNo)) {
                            rfIdPoleNo = JSON.stringify(_.sortBy(p.rfIdPoleNo));
                        }
                    }

                    p['rfIdPoleNo'] = rfIdPoleNo;
                }


                if (p.id !== undefined) {
                    promises2.push(StorageLocationModel.updateStorageLocation(_.omit(p, ['id']), { id: p.id }));
                } else {
                    p['branchId'] = id;
                    p['createdBy'] = who;
                    p['updatedBy'] = who;
                    promises2.push(StorageLocationModel.addNew(p));
                }
            }
        }

        await Promise.all(promises2);

        let record = await BranchModel.updateRecord(branch, where);
        if (record) {
            // let BId = record.id
            const companyBranch = {
                countryId: branch.countryId,
                companyId: branch.companyId,
                // branchId: where.id,
                updatedBy: who
                // createdBy: who
            };
            const AddcompanyBranch = {
                countryId: branch.countryId,
                companyId: branch.companyId,
                branchId: where.id,
                updatedBy: who,
                createdBy: who
            };
            let whereId = { branchId: where.id, deleted: false };
            let resp = await CompanyBranch.getOne(whereId);
            if (resp) {
                promises.push(CompanyBranch.updateCompanyBranch(companyBranch, whereId));
            } else {
                promises.push(CompanyBranch.addRecord(AddcompanyBranch));
            }

            await Promise.all(promises);

            return BranchModel.getOne({ id });
        }
    }

    static async deleteMany(ids, option, who) {
        var promises = [];
        ids.forEach((id) => {
            return Functions.delete(id, option, who).then((record) => {
                if (record) {
                    let where = {
                        'branchId': id
                    }
                    let t = CompanyBranch.deleteHard(where);
                    promises.push(t);
                }
            })

            // promises.push(Functions.delete(id, option, who).catch((error) => {
            //     return errorDef.compileError(error);
            // }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return BranchModel.deleteHard(where).then((record) => {
                return BranchModel.getOne(where);
            });
        } else if (option === 'soft') {

            return BranchModel.deleteSoft(where, who).then(() => {
                return BranchModel.getOne(where);
            });

        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

    static async getBranchByDealer(page, limit, order, searches, filter, headers) {
        let whereConditions = [{
            deleted: false
        }]; //for filtering deleted
        let likeArr = []

        if (searches) {
            for (let i = 0; i < searches.length; i++) {
                if (searches[i].colId === 'stateName' || searches[i].colId === 'cityName' || searches[i].colId === 'postcodeCode' || searches[i].colId === 'countryCode') {
                    let searchMasterDatas = [];
                    if (searches[i].colId === 'stateName') {
                        searchMasterDatas.push({
                            masterdata: 'state',
                            search: [{ colId: "name", text: searches[i].text }]
                        });
                    }

                    if (searches[i].colId === 'cityName') {
                        searchMasterDatas.push({
                            masterdata: 'city',
                            search: [{ colId: "name", text: searches[i].text }]
                        });
                    }

                    if (searches[i].colId === 'postcodeCode') {
                        searchMasterDatas.push({
                            masterdata: 'postcode',
                            search: [{ colId: "code", text: searches[i].text }]
                        });
                    }

                    if (searches[i].colId === 'countryCode') {
                        searchMasterDatas.push({
                            masterdata: 'country',
                            search: [{ colId: "code", text: searches[i].text }]
                        });
                    }


                    let queryResult = await generalCache.getMasterDataByQuery(searchMasterDatas, headers.authorization);
                    if (queryResult.state) {
                        let stateIds = [];
                        queryResult.state.forEach((state) => {
                            stateIds.push(state.id);
                        })
                        _.forEach(stateIds, (id) => {
                            likeArr.push({ colId: 'stateId', text: `%${id}%` });
                        })
                    }

                    if (queryResult.city) {
                        let cityIds = [];
                        queryResult.city.forEach((city) => {
                            cityIds.push(city.id);
                        })
                        _.forEach(cityIds, (id) => {
                            likeArr.push({ colId: 'cityId', text: `%${id}%` });
                        })
                    }

                    if (queryResult.postcode) {
                        let postcodeIds = [];
                        queryResult.postcode.forEach((postcode) => {
                            postcodeIds.push(postcode.id);
                        })
                        _.forEach(postcodeIds, (id) => {
                            likeArr.push({ colId: 'postcodeId', text: `%${id}%` });
                        })
                    }

                    if (queryResult.country) {
                        let countrycodeIds = [];
                        queryResult.country.forEach((country) => {
                            countrycodeIds.push(country.id);
                        })
                        _.forEach(countrycodeIds, (id) => {
                            likeArr.push({ colId: 'countryId', text: `%${id}%` });
                        })
                    }

                } else {
                    if (searches && searches.length > 0) {
                        let prepQry = [];

                        searches.forEach((search) => {
                            search.text.forEach((text) => {
                                let qry = {};
                                qry[search.colId] = {
                                    [Op.like]: '%' + text + '%'
                                };
                                prepQry.push(qry);
                                likeArr.push({ colId: search.colId, text: '%' + text + '%' });
                            })
                        })

                        if (prepQry && prepQry.length > 0) {
                            whereConditions.push({
                                [Op.or]: prepQry
                            });
                        }

                    }
                }
            };
        }
        let attr = null;

        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        }

        let orderBy = order.columnName.split('.');
        orderBy.push(order.direction);

        const where = {
            [Op.and]: whereConditions
        };

        return BranchModel.getBranchByDealer(likeArr, attr, pagination, orderBy, filter, false, true).then(async (recordResults) => {
            // COUNTRY IDs
            let countryIds = _.without(_.uniq(_.map(recordResults.rows, 'countryId')), '', null);
            let filterCountry = [{ colId: 'id', text: !_.isEmpty(countryIds) ? countryIds : ['00000000-0000-0000-0000-000000000000'] }]
            let countryRes = await CountryModel.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], filterCountry, true, true, true);
            let countries = countryRes ? _.map(countryRes, 'dataValues') : [];

            // CURRENCY IDs
            let currencyIds = _.without(_.uniq(_.map(recordResults.rows, 'currencyId')), '', null);
            let filterCurrency = [{ colId: 'id', text: !_.isEmpty(currencyIds) ? currencyIds : ['00000000-0000-0000-0000-000000000000'] }]
            let currencyRes = await CurrencyModel.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], filterCurrency, true, true, true);
            let currencies = currencyRes ? _.map(currencyRes, 'dataValues') : [];

            // POSTCODE IDs
            let postcodeIds = _.without(_.uniq(_.map(recordResults.rows, 'postcodeId')), '', null);
            let filterPostcode = [{ colId: 'id', text: !_.isEmpty(postcodeIds) ? postcodeIds : ['00000000-0000-0000-0000-000000000000'] }]
            let postCodeRes = await PostCodeModel.searchAll([], ['id', 'code', 'updatedAt'], {}, ['updatedAt', 'desc'], filterPostcode, true, true, true);
            let postcodes = postCodeRes ? _.map(postCodeRes, 'dataValues') : [];

            // CITY IDs
            let cityIds = _.without(_.uniq(_.map(recordResults.rows, 'cityId')), '', null);
            let filterCity = [{ colId: 'id', text: !_.isEmpty(cityIds) ? cityIds : ['00000000-0000-0000-0000-000000000000'] }]
            let cityRes = await CityModel.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], filterCity, true, true, true);
            let cities = cityRes ? _.map(cityRes, 'dataValues') : [];

            // STATE IDs
            let stateIds = _.without(_.uniq(_.map(recordResults.rows, 'stateId')), '', null);
            let filterState = [{ colId: 'id', text: !_.isEmpty(stateIds) ? stateIds : ['00000000-0000-0000-0000-000000000000'] }]
            let stateRes = await StateModel.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], filterState, true, true, true);
            let states = stateRes ? _.map(stateRes, 'dataValues') : [];

            // REGION IDs
            let regionIds = _.without(_.uniq(_.map(recordResults.rows, 'regionId')), '', null);
            let filterRegion = [{ colId: 'id', text: !_.isEmpty(regionIds) ? regionIds : ['00000000-0000-0000-0000-000000000000'] }]
            let regionRes = await RegionModel.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], filterRegion, true, true, true);
            let regions = regionRes ? _.map(regionRes, 'dataValues') : [];

            _.forEach(recordResults.rows, (rw) => {
                let foundCountry = _.find(countries, (o) => { return o.id === rw.countryId; });
                rw.dataValues['countryCode'] = foundCountry ? foundCountry.code : null;
                rw.dataValues['countryName'] = foundCountry ? foundCountry.name : null;

                let foundCurrency = _.find(currencies, (o) => { return o.id === rw.currencyId; });
                rw.dataValues['currencyCode'] = foundCurrency ? foundCurrency.code : null;
                rw.dataValues['currencyName'] = foundCurrency ? foundCurrency.name : null;

                let foundPostcode = _.find(postcodes, (o) => { return o.id === rw.postcodeId; });
                rw.dataValues['postcodeCode'] = foundPostcode ? foundPostcode.code : null;

                let foundCity = _.find(cities, (o) => { return o.id === rw.cityId; });
                rw.dataValues['cityCode'] = foundCity ? foundCity.code : null;
                rw.dataValues['cityName'] = foundCity ? foundCity.name : null;

                let foundState = _.find(states, (o) => { return o.id === rw.stateId; });
                rw.dataValues['stateCode'] = foundState ? foundState.code : null;
                rw.dataValues['stateName'] = foundState ? foundState.name : null;

                let foundRegion = _.find(regions, (o) => { return o.id === rw.regionId; });
                rw.dataValues['regionCode'] = foundRegion ? foundRegion.code : null;
                rw.dataValues['regionName'] = foundRegion ? foundRegion.name : null;
            });

            return recordResults;
        });
    }

    static async getAllBranchOfDealerByCompanyId(companyId, offset, limit, order, headers) {
        let sql = `SELECT * FROM branch WHERE companyId in (
            SELECT id FROM company WHERE dealerGroupId in (
                SELECT dealerGroupId FROM company WHERE id in ('${companyId}')
            )
        ) `;
        if (order && order.columnName && order.direction) {
            sql += ` order by ${order.columnName} ${order.direction} limit ${offset}, ${limit};`;
        } else {
            sql += ` limit ${offset}, ${limit};`;
        }
        return db.sequelize.query(sql, { type: Sequelize.QueryTypes.SELECT }).then((result) => {
            return {
                order,
                page: offset,
                limit,
                rows: result,
                count: result.length,
            }
        });
    }

    static async getBranchMakes(branchId) {
        let filterBranchMakeBusinessType = [{ colId: 'branchId', text: [branchId] }];
        let result = await BranchMakeBusinessTypeModel.searchAll([], ['id', 'makeId', 'updatedAt'], {}, ['updatedAt', 'desc'], filterBranchMakeBusinessType, true, false, true);
        if (result && !_.isEmpty(result)) {
            return _.without(_.uniq(_.map(result, 'makeId')), null, '');
        }
        return null;
    }

    static async getBranchByTenant(tenantId, search, page, limit, order) {

        const TenantModel = require('@driveit/driveit-databases/databases/auth/models/tenants');
        const tenantRes = await TenantModel.findAll({ where: {id: tenantId}, attributes: ['id', 'companyId', 'branchId']})
        let companyList = _.uniq(_.compact(tenantRes.map((v) => v.companyId)));

        const company01Res = await CompanyModel.findAll({ where: {parentCompanyId: companyList}, attributes: ['id', 'name', 'parentCompanyId']})
        const company01Ids = _.uniq(_.compact(company01Res.map((v) => v.id)));
        companyList = companyList.concat(company01Ids);
        // 2nd level ========================================
        if(company01Ids.length) {
            const company02Res = await CompanyModel.findAll({ where: {parentCompanyId: company01Ids}, attributes: ['id', 'name', 'parentCompanyId']})
            const company02Ids = _.uniq(_.compact(company02Res.map((v) => v.id)));
            companyList = companyList.concat(company02Ids);
        // 3rd level ========================================
            if(company02Ids.length) { 
                const company03Res = await CompanyModel.findAll({ where: {parentCompanyId: company02Ids, deleted: false}, attributes: ['id', 'code', 'name']})
                const company03Ids = _.uniq(_.compact(company03Res.map((v) => v.id)));
                companyList = companyList.concat(company03Ids);
            }
        }
        if (companyList.length) {
            const pagination = {
                limit,
                offset: limit ? limit * (page - 1) : undefined,
            }
            const getBranchRes = await CompanyBranch.findAll({ where: {companyId: companyList, deleted: false}, attributes: ['companyId', 'branchId'], ...pagination })
            const branchIds = _.uniq(_.compact(getBranchRes.map((v) => v.branchId)))

            let branchRes;
            
            if (search) {
                let filterBranch = [{ colId: 'id', text: [branchIds] }];
                branchRes = await BranchModel.searchAll(search, ['id', 'code', 'name', 'updatedAt'], {}, [order.columnName, order.direction], filterBranch, true, false, true);
                branchRes = branchRes ? _.map(branchRes, 'dataValues') : [];
            } else {
                branchRes = await BranchModel.findAll({ where: {id: branchIds, deleted: false}, attributes: ['id', 'code', 'name', 'updatedAt'], order: [[order.columnName, order.direction]]})
            }

            let result = branchIds.map((b) => {
                let branchObj = branchRes.find((br) => br.id == b)
                return branchObj
            })
            result = _.uniq(_.compact(result))

            return { rows: result.length ? result : []};
        }
        return {rows: []}

    }

}


module.exports = Functions;
