
const errorcodes = require('../services.config/error.codes');
const self = module.exports = {

    validateAddBranchData: (req, res, next) => {
        req.checkBody('branch', 'branch parameter missing').trim().notEmpty().isArray();
        req.checkBody('branch.*.code', 'code paramter is missing').trim().notEmpty();
        req.checkBody('branch.*.name', 'name paramter is missing').trim().notEmpty();
        req.checkBody('branch.*.companyId', 'companyId paramter is missing').trim().notEmpty();
        //req.checkBody('branch.*.companyRegistrationNo', 'companyRegistrationNo paramter is missing').trim().notEmpty();
        req.checkBody('branch.*.address1', 'address1 paramter is missing').trim().notEmpty();
        req.checkBody('branch.*.postcodeId', 'postcodeId paramter is missing').trim().notEmpty();
        req.checkBody('branch.*.cityId', 'cityId paramter is missing').trim().notEmpty();
        req.checkBody('branch.*.stateId', 'stateId paramter is missing').trim().notEmpty();
        req.checkBody('branch.*.countryId', 'countryId paramter is missing').trim().notEmpty();
        //req.checkBody('branch.*.currencyId', 'currencyId paramter is missing').trim().notEmpty();
        req.checkBody('branch.*.status', 'status paramter is missing').trim().notEmpty();
        req.checkBody('branch.*.inactivateReason', 'Inactivate Reason paramter is missing').trim().notEmpty().optional();


        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },
    validateUpdateBranchData: (req, res, next) => {
        req.checkBody('id', 'id parameter missing').trim().notEmpty();
        req.checkBody('branch', 'branch parameter missing').custom(val => {
            return new Promise((resolve, reject) => {
                if (val.code === null || val.code === undefined || val.code === '') {
                    reject();
                } else if (val.name === null || val.name === undefined || val.name === '') {
                    reject();
                } else if (val.companyId === null || val.companyId === undefined || val.companyId === '') {
                    reject();
                } else if (val.address1 === null || val.address1 === undefined || val.address1 === '') {
                    reject();
                } else if (val.postcodeId === null || val.postcodeId === undefined || val.postcodeId === '') {
                    reject();
                } else if (val.stateId === null || val.stateId === undefined || val.stateId === '') {
                    reject();
                } else if (val.cityId === null || val.cityId === undefined || val.cityId === '') {
                    reject();
                } else if (val.countryId === null || val.countryId === undefined || val.countryId === '') {
                    reject();
                } else if (val.status === null || val.status === undefined || val.status === '') {
                    reject();
                } else if (val.status === 'disabled') {
                    if (val.inactivateReason === null || val.inactivateReason === undefined || val.inactivateReason === '') {
                        reject();
                    } else {
                        resolve();
                    }
                } else {
                    resolve();
                }
            })


        });
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateSearchBranchData: (req, res, next) => {
        req.checkBody('page', 'page parameter missing').trim().notEmpty();
        req.checkBody('limit', 'limit parameter missing').trim().notEmpty();
        req.checkBody('order', 'order parameter missing').trim().notEmpty();
        req.checkBody('order.columnName', 'columnName parameter missing').trim().notEmpty();
        req.checkBody('order.direction', ' direction parameter missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateDeleteBranchData: (req, res, next) => {
        req.checkBody('ids', 'id parameter missing').trim().notEmpty().isArray();
        req.checkBody('option', 'option parameter missing').trim().notEmpty();

        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    }

}