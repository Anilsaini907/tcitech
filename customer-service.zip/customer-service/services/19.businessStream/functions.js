const BusinessStreamModel = require('@driveit/driveit-databases/databases/customerMaster/models/19.businessStream');

var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };

        const orderBy = [order.columnName, order.direction];
        

        return await BusinessStreamModel.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
    }

    static async addMany(datas, who) {
        let promises = [];

        for(let t=0; t<datas.length; t++){
            let data = datas[t];
            if(datas.length == 1){ //for singles
                return Functions.add(data, who);
            }

            //else multiple
            promises.push(Functions.add(data, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        }
     

        return Promise.all(promises);
    }

    static async add(data, who) {

        data['updatedBy'] = who;
        data['createdBy'] = who;

        return BusinessStreamModel.addRecord(data).then((record) => {
            return record;
        });
    }

    static async update(id, data, who) {
        const where = {
            id
        }
        data['updatedBy'] = who;
        data['id']= id;

        return BusinessStreamModel.updateRecord(data, where).then((record) => {
            return BusinessStreamModel.getOne({id});
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return BusinessStreamModel.deleteHard(where).then((record) => {
                return BusinessStreamModel.getOne(where);
            });
        } else if (option === 'soft') {
            
            return BusinessStreamModel.deleteSoft(where, who).then(() => {
                return BusinessStreamModel.getOne(where);
            });
            
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

}


module.exports = Functions;