const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');
const customVal = require('./validation');

/**
 * Search for BusinessStream listing
 * 
 * @route POST /businessStream/search
 * @operationId businessStreamSearch
 * @group BusinessStream API
 * @param {BusinessStreamSearch.model} BusinessStreamSearch.body - Search. Show all if not provided.
 * @returns {BusinessStreamSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        search.forEach((searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]); 
        })
    }
    errorDef.parameterHandler([order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond).then((resp) => {

        return res.status(200).send({
            ...resp,
            order,
            page,
            limit,
            search,
            filter
        });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add BusinessStream
 * 
 * @route PUT /businessStream/add
 * @operationId businessStreamAdd
 * @group BusinessStream API
 * @param {AddBusinessStream.model} AddBusinessStream.body.required - required AddBusinessStream
 * @returns {Array.<BusinessStreamData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.put('/add',[customVal.validateAddBusinessStreamData], async function (req, res, next) {
    const businessStreams = req.body.businessStream;

    errorDef.parameterHandler([businessStreams]);
    businessStreams.forEach((businessStream) => {
        errorDef.parameterHandler([businessStream.code, businessStream.name, businessStream.status]);
    })
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addMany(businessStreams, userInfo.id).then((result) => {
                return res.status(200).send(result);
            })
            .catch((reason) => {
                next(reason);
            });
    }
});

/**
 * Update BusinessStream
 * 
 * @route PUT /businessStream/update
 * @operationId businessStreamUpdate
 * @group BusinessStream API
 * @param {UpdateBusinessStream.model} UpdateBusinessStream.body.required - required UpdateBusinessStream
 * @returns {BusinessStreamData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.put('/update',[customVal.validateUpdateBusinessStreamhData], async function (req, res, next) {
    const id = req.body.id;
    const businessStream = req.body.businessStream;
    
    errorDef.parameterHandler([id, businessStream]);

    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.update(id, businessStream, userInfo.id).then((record) => {
            if (!record) {
                throw errorDef.RECORD_NOT_FOUND
            }
            return res.status(200).send(record);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete BusinessStream
 * 
 * @route DELETE /businessStream/delete
 * @operationId businessStreamDelete
 * @group BusinessStream API
 * @param {DeleteBusinessStream.model} DeleteBusinessStream.body.required - required DeleteBusinessStream
 * @returns {BusinessStreamData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete',[customVal.validateDeleteBusinessStreamData], async function (req, res, next) {
    const ids = req.body.ids;
    const option = req.body.option;

    errorDef.parameterHandler([ids]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.deleteMany(ids, option, userInfo.id).then((response) => {
            return res.status(200).send(response);
        }).catch((reason) => {
            next(reason);
        });
    }
});
module.exports = router;