const PaymentTermsModel = require('@driveit/driveit-databases/databases/customerMaster/models/2.paymentTerms');
const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
var _ = require('lodash');

class Functions {

    static async getPaymentTerms(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        if (search) {
            let excludedSearch = _.remove(search, (o) => { return o.colId === 'countryCode' || o.colId === 'countryName'; });
            let searched = await this.prepQry(excludedSearch, token);
            search = _.concat(search, searched);
        }

        let attr = null;

        let paymentTermsRes = await PaymentTermsModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond);
        
        let resp = await CountryModel.searchAll([], ['id', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], [], true, true, true);
        let countries = resp && !_.isEmpty(resp) ? _.map(resp, 'dataValues') : [];
    
        _.forEach(paymentTermsRes.rows, (row) => {
            let found = _.find(countries, (o) => { return _.isEqual(o.id, row.countryId); });
            if (found) {
                row.dataValues['countryName'] = found.name ? found.name : '';
            }
        });
        
        return {
            ...paymentTermsRes,
            page: page.page,
            limit: page.limit
        };
    }

    static async prepQry(search, token) {
        let likeArr = [];
        let searchMasterDatas = [];
        for(let i = 0; i < _.size(search); i++) {
            
            if (search[i].colId === 'countryName') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "name", text: search[i].text }],
                        skipInclude: true
                    });
                } else {
                    let found = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found) {
                        found.search.push({ colId: "name", text: search[i].text });
                    }
                }
            } else if (search[i].colId === 'countryCode') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "code", text: search[i].text }],
                        skipInclude: true
                    });
                } else {
                    let found1 = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found1) {
                        found1.search.push({ colId: "code", text: search[i].text });
                    }
                }
            }
        }

        let queryResult = await generalCache.getMasterDataByQuery(searchMasterDatas, token);
        if (queryResult) {
            if (queryResult.country) {
                let countryIds = [];
                queryResult.country.forEach((country) => {
                    countryIds.push(country.id);
                });
                likeArr.push({ colId: 'countryId', text: !_.isEmpty(countryIds) ? countryIds : ['00000000-0000-0000-0000-000000000000'] });
            }
        }
        
        return likeArr;
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        
        //temp fix for PBI 663. Task 729. to display country Name
        return PaymentTermsModel.getAll(q, attr, pagination, page.order).then((paymentTermsRes) => {
            let masterdataTypes = ["country"];
            let token = page.token? page.token : null;
            return generalCache.processMasterdataResult(paymentTermsRes.rows, masterdataTypes, token).then((mdResults) => {
                _.forEach(paymentTermsRes.rows, (row) => {
                    let mObj = {};
                    _.forEach(mdResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if(c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });
                        
                        if(mObj[key] && mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    });
                });
                return {
                    ...paymentTermsRes,
                    page: page.page,
                    limit: page.limit
                };
            });
        });
        
        // return {
        //     ...await PaymentTermsModel.getAll(q, attr, pagination, page.order),
        //     page: page.page,
        //     limit: page.limit
        // };
    }

    static async updateDefault(paymentdata){
        const data={default:'disabled'}
        const where={countryId:paymentdata.countryId,deleted:0,default:'enabled',status:'enabled'}
        const getDefaultValue=await PaymentTermsModel.findAll({where:where});
        if(getDefaultValue.length>0){
            var result=await PaymentTermsModel.update(data, {where:{id:getDefaultValue[0].id}});
        }
        return result;
    }

    static async addPaymentTerms(paymentTermsObj, who) {

        if(paymentTermsObj[0].default==='enabled'){
            const data={default:"disabled"}
            const where={countryId:paymentTermsObj[0].countryId,deleted:0,status:'enabled'}
            await PaymentTermsModel.update(data, {where:where});
        }
        return PaymentTermsModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(paymentTermsObj, async(addPaymentTermsObj) => {
                addPaymentTermsObj['createdBy'] = who;
                addPaymentTermsObj['updatedBy'] = who;
                const p = PaymentTermsModel.addNew(addPaymentTermsObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    static async updatePaymentTerms(paymentTerms, where, who) {
        if(paymentTerms.default==='enabled'){
            const data={default:"disabled"}
            const where={countryId:paymentTerms.countryId,deleted:0,status:'enabled'}
            await PaymentTermsModel.update(data, {where:where})
        }
        paymentTerms['updatedBy'] = who;
        paymentTerms['id'] = where.id;
        return await PaymentTermsModel.updatePaymentTerms(paymentTerms, where).then(()=>{
            return PaymentTermsModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deletePaymentTerms(where, who, type = "soft") {
        if(type == "soft") {
            return await PaymentTermsModel.deleteSoft(where, who).then(()=>{
                return PaymentTermsModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await PaymentTermsModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }

}


module.exports = Functions;