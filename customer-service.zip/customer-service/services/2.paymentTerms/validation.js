const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreatePaymentTerms: (req, res, next) => {
        req.checkBody('paymentTerms', 'Payment Terms object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('paymentTerms.*.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('paymentTerms.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('paymentTerms.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.checkBody('paymentTerms.*.countryId', 'Country parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdatePaymentTerms: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('paymentTerms', 'Payment Terms object parameter is missing').trim().notEmpty();
        req.checkBody('paymentTerms.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('paymentTerms.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('paymentTerms.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.checkBody('paymentTerms.countryId', 'Country parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeletePaymentTerms: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}