const StorageLocationModel = require('@driveit/driveit-databases/databases/customerMaster/models/20.storageLocation');
const BranchModel = require('@driveit/driveit-databases/databases/customerMaster/models/18.branch');
const StorageModel = require('@driveit/driveit-databases/databases/customerMaster/models/25.storage');
const employeeModel = require('@driveit/driveit-databases/databases/auth/models/employees');
const RfidPoleLocationModel = require('@driveit/driveit-databases/databases/generalMaster/models/50.rfidPoleLocation');
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
var _ = require('lodash');
const Utils = require('../../utilities/utils');

const db = require('@driveit/driveit-databases/databases/customerMaster');
const Sequelize = require("sequelize");

class Functions {

    static async getStorageLocation(searches, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        let token = page.token ? page.token : null;

        let orCondition = '';
        let replacements = {};
        if (searches && searches.length > 0) {
            searches.forEach((search) => {
                if (search.colId === 'storage.name') {
                    orCondition += searchOrCond ? ` OR s.name LIKE :storageName ` : ` AND s.name LIKE :storageName `;
                    replacements.storageName = "%" + search.text[0].trim() + "%";
                } else if (search.colId === 'storage.code') {
                    orCondition += searchOrCond ? ` OR s.code LIKE :storageCode ` : ` AND s.code LIKE :storageCode `;
                    replacements.storageCode = "%" + search.text[0].trim() + "%";
                } else if (search.colId === 'branch.name') {
                    orCondition += searchOrCond ? ` OR b.name LIKE :branchName ` : ` AND b.name LIKE :branchName `;
                    replacements.branchName = "%" + search.text[0].trim() + "%";
                } else if (search.colId === 'branch.code') {
                    orCondition += searchOrCond ? ` OR b.code LIKE :branchCode ` : ` AND b.code LIKE :branchCode `;
                    replacements.branchCode = "%" + search.text[0].trim() + "%";
                // } else if (search.colId === 'branch.code+branch.name') {
                //     orCondition += searchOrCond ? ` OR b.code LIKE :branchCode ` : ` AND b.code LIKE :branchCode `;
                //     replacements.branchCode = "%" + search.text[0].trim() + "%";
                //     orCondition += searchOrCond ? ` OR b.name LIKE :branchName ` : ` AND b.name LIKE :branchName `;
                //     replacements.branchName = "%" + search.text[0].trim() + "%";
                } else {
                    orCondition += searchOrCond ? ` OR sl.${search.colId} LIKE :${search.colId} ` : ` AND sl.${search.colId} LIKE :${search.colId} `;
                    replacements[search.colId] = "%" + search.text[0].trim() + "%";
                }
            });
        }

        let AND_PREFIX = " AND";
        if (!_.isEmpty(orCondition)) {
            let OR_PREFIX = " OR";
            if (orCondition.startsWith(OR_PREFIX)) {
                orCondition = orCondition.slice(OR_PREFIX.length);
            }
            if (orCondition.startsWith(AND_PREFIX)) {
                orCondition = orCondition.slice(AND_PREFIX.length);
            }
        }

        let andCondition = '';
        if (filter && filter.length > 0) {
            filter.forEach((filt) => {
                if (filt.colId === 'storage.name') {
                    andCondition += ` AND s.name IN (${JSON.stringify(filt.text).replace(/[\[\]]/g, "")}) `;
                    // replacements.storageName = replc;
                } else if (filt.colId === 'storage.code') {
                    andCondition += ` AND s.code IN (${JSON.stringify(filt.text).replace(/[\[\]]/g, "")}) `;
                    // replacements.storageCode = replc;
                } else if (filt.colId === 'branch.name') {
                    andCondition += ` AND b.name IN (${JSON.stringify(filt.text).replace(/[\[\]]/g, "")}) `;
                    // replacements.branchName = replc;
                } else if (filt.colId === 'branch.code') {
                    andCondition += ` AND b.code IN (${JSON.stringify(filt.text).replace(/[\[\]]/g, "")}) `;
                    // replacements.branchCode = replc;
                } else {
                    andCondition += ` AND sl.${filt.colId} IN (${JSON.stringify(filt.text).replace(/[\[\]]/g, "")}) `;
                    // replacements[filt.colId] = replc;
                }
            });
        }
        
        if (_.isEmpty(orCondition)) {
            if (!_.isEmpty(andCondition)) {
                if (andCondition.startsWith(AND_PREFIX)) {
                    andCondition = andCondition.slice(AND_PREFIX.length);
                }
            }
        }
        

        const OFFSET = page.limit ? page.limit * (page.page - 1) : 0;

        let optionQuery = {
            type: Sequelize.QueryTypes.SELECT,
            row: true
        }
        if (replacements) {
            optionQuery.replacements = replacements;
        }

        if (page.order[0] === 'branch.code') {
            page.order[0] = 'branchCode';
        } else if (page.order[0] === 'branch.name') {
            page.order[0] = 'branchName';
        } else if (page.order[0] === 'storage.code') {
            page.order[0] = 'storageCode';
        } else if (page.order[0] === 'storage.name') {
            page.order[0] = 'storageName';
        } else {
            page.order[0] = 'sl.' + page.order[0];
        }


        const sqlSelect = `SELECT sl.id, sl.zone, sl.regionId, sl.telephone, sl.fax, sl.area, sl.primaryContact, sl.shipToAddress1, sl.shipToAddress2, sl.shipToAddress3, sl.postcodeId, sl.cityId, sl.stateId, sl.countryId, sl.rfIdPoleNo, sl.status, sl.deleted, sl.inactivateReason, sl.createdBy, sl.updatedBy, sl.createdAt, sl.updatedAt, sl.branchId, sl.storageId, sl.followMainAddress, sl.telId, sl.faxId, sl.contactId, b.name AS branchName, b.code AS branchCode, s.name AS storageName, s.code AS storageCode`;
        const sqlCount = `SELECT COUNT(sl.id) count `;
        const pageing = `LIMIT ${page.limit} OFFSET ${OFFSET}`;
        let andOrCond = _.isEmpty(orCondition) && _.isEmpty(andCondition) ? `` : (showAll ? `${orCondition}${andCondition}` : `AND${orCondition}${andCondition}`);
        const sqlCommand = `FROM customer_master.storageLocation sl LEFT JOIN customer_master.storage AS s ON s.id = sl.storageId LEFT JOIN customer_master.branch AS b ON b.id = sl.branchId WHERE${showAll ? `` : ` sl.deleted = false`} ${andOrCond}`;
        let orderby = `ORDER BY ${page.order[0]} ${page.order[1]}`;
        let groupby = ``;
        if (distKeys) {
            let grpDk = '';
            _.forEach(distKeys, (dk, index) => {
                grpDk += index === _.size(distKeys) ? dk : dk + ',';
            });
            groupby = ` GROUP BY ${grpDk}`;
        }
        let count = 0;
        const countResp = await db.sequelize.query(sqlCount + sqlCommand + groupby.trim(), optionQuery);
        if (countResp) {
            count = countResp[0].count;
        }

        let storageLocationRes = await db.sequelize.query(
            `${sqlSelect} ${sqlCommand}${orderby}${groupby} ${pageing}`,
            optionQuery
        );


        let countryIds = _.without(_.uniq(_.map(storageLocationRes, 'countryId')), null, '');
        let searchCountryMaster = [];
        searchCountryMaster.push({
            masterdata: 'country',
            attributes: ['id', 'code', 'name', 'updatedAt'],
            search: [{ colId: 'id', text: countryIds }],
            skipInclude: true
        });
        let queryResult = await generalCache.getMasterDataByQuery(searchCountryMaster, token);
        let countries = queryResult && queryResult.country && !_.isEmpty(queryResult.country) ? queryResult.country : [];
        

        let branchIds = _.without(_.uniq(_.map(storageLocationRes, 'branchId')), null, '');
        let filterBranch = [{ colId: 'id', text: branchIds }];
        let branchResp = await BranchModel.searchAll([], ['id', 'code', 'name'], {}, ['updatedAt', 'desc'], filterBranch, true, false, true);
        let branches = branchResp ? _.map(branchResp, 'dataValues') : [];

        let storageIds = _.without(_.uniq(_.map(storageLocationRes, 'storageId')), null, '');
        let filterStorage = [{ colId: 'id', text: storageIds }];
        let storageResp = await StorageModel.searchAll([], ['id', 'code', 'name'], {}, ['updatedAt', 'desc'], filterStorage, true, false, true);
        let storages = storageResp ? _.map(storageResp, 'dataValues') : [];

        _.forEach(storageLocationRes, (row) => {
            let foundCountry = _.find(countries, (o) => { return o.id === row.countryId; });
            row['countryCode'] = foundCountry ? foundCountry.code : null;
            let foundBranch = _.find(branches, (o) => { return o.id === row.branchId; });
            row['branch'] = foundBranch ? foundBranch : null;
            let foundStorage = _.find(storages, (o) => { return o.id === row.storageId; });
            row['storage'] = foundStorage ? foundStorage : null;
        });

        return {
            rows: storageLocationRes,
            count: count,
            page: page.page,
            limit: page.limit
        };
    }

    static async getAll(page) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};

        let attr = null;
        let token = page.token ? page.token : null;

        let storageLocationRes = await StorageLocationModel.getAll(q, attr, pagination, page.order);
        let countryIds = _.without(_.uniq(_.map(storageLocationRes.rows, 'countryId')), null, '');
        let searchCountryMaster = [];
        searchCountryMaster.push({
            masterdata: 'country',
            attributes: ['id', 'code', 'name', 'updatedAt'],
            search: [{ colId: 'id', text: countryIds }],
            skipInclude: true
        });
        let queryResult = await generalCache.getMasterDataByQuery(searchCountryMaster, token);
        let countries = queryResult && queryResult.country && !_.isEmpty(queryResult.country) ? queryResult.country : [];

        // branch
        let branchIds = _.without(_.uniq(_.map(storageLocationRes.rows, 'branchId')), null, '');
        let filterBranch = [{ colId: 'id', text: branchIds }];
        let branches = await BranchModel.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], filterBranch, true);

        _.forEach(storageLocationRes.rows, (row) => {
            let foundCountry = _.find(countries, (o) => { return o.id === row.countryId; });
            row.dataValues['countryCode'] = foundCountry ? foundCountry.code : null;
            let foundBranch = _.find(branches.rows, (o) => { return o.id === row.branchId; });
            row.dataValues['branch'] = foundBranch ? foundBranch : null;
        });

        return {
            ...storageLocationRes,
            page: page.page,
            limit: page.limit
        };
    }

    static async addStorageLocation(storageLocationObj, who) {
        return StorageLocationModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(storageLocationObj, (addStorageLocationObj) => {
                addStorageLocationObj['createdBy'] = who;
                addStorageLocationObj['updatedBy'] = who;

                if (addStorageLocationObj.rfIdPoleNo && !_.isEmpty(addStorageLocationObj.rfIdPoleNo)) {
                    let rfIdPoleNo = _.cloneDeep(addStorageLocationObj.rfIdPoleNo);
                    if (Utils.isJsonString(addStorageLocationObj.rfIdPoleNo)) {
                        rfIdPoleNo = JSON.stringify(_.sortBy(JSON.parse(addStorageLocationObj.rfIdPoleNo)));
                    } else {
                        if (_.isArray(addStorageLocationObj.rfIdPoleNo)) {
                            rfIdPoleNo = JSON.stringify(_.sortBy(addStorageLocationObj.rfIdPoleNo));
                        }
                    }

                    addStorageLocationObj['rfIdPoleNo'] = rfIdPoleNo;
                }

                promises.push(StorageLocationModel.addNew(addStorageLocationObj, t));
            });
            return Promise.all(promises);
        });
    }

    static async updateStorageLocation(storageLocation, where, who) {
        storageLocation['updatedBy'] = who;
        storageLocation['id'] = where.id;

        if (storageLocation.rfIdPoleNo && !_.isEmpty(storageLocation.rfIdPoleNo)) {
            let rfIdPoleNo = _.cloneDeep(storageLocation.rfIdPoleNo);
            if (Utils.isJsonString(storageLocation.rfIdPoleNo)) {
                rfIdPoleNo = JSON.stringify(_.sortBy(JSON.parse(storageLocation.rfIdPoleNo)));
            } else {
                if (_.isArray(storageLocation.rfIdPoleNo)) {
                    rfIdPoleNo = JSON.stringify(_.sortBy(storageLocation.rfIdPoleNo));
                }
            }

            storageLocation['rfIdPoleNo'] = rfIdPoleNo;
        }

        return await StorageLocationModel.updateStorageLocation(storageLocation, where).then(() => {
            return StorageLocationModel.getId(where).then((resp) => {
                if (!resp) {
                    throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }

    static async deleteStorageLocation(where, who, type = "soft") {
        if (type == "soft") {
            return await StorageLocationModel.deleteSoft(where, who).then(() => {
                return StorageLocationModel.getAll(where, null).then((resp) => {
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await StorageLocationModel.deleteHard(where).then((resp) => {
                if (!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }

    static async getRfIdPoles(page, who) {
        const token = page.token ? page.token : null;

        let filterEmployee = [
            { colId: 'internalUserId', text: [who] },
            { colId: 'id', text: [['OFFICE_SALE']], filterCondition: [{direction: 'notIn'}] },
            { colId: 'vendorId', text: [null], filterCondition: [{direction: 'not'}] }
        ];
        let employeeRes = await employeeModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterEmployee, true, false, true);

        let gBranchId = null;
        if (employeeRes && !_.isEmpty(employeeRes)) {
            gBranchId = employeeRes[0].branchId;
        }

        if (gBranchId) {
            let filterStorageLoc = [{ colId: 'branchId', text: [gBranchId] }];
            let storageLocRes = await StorageLocationModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterStorageLoc, false, false, true);
            let storageLocs = storageLocRes && !_.isEmpty(storageLocRes) ? _.map(storageLocRes, 'dataValues') : [];

            let rfidPole = _.map(storageLocs, (l) => {
                if (l.rfIdPoleNo && !_.isEmpty(l.rfIdPoleNo) && Utils.isJsonString(l.rfIdPoleNo)) {
                    return JSON.parse(l.rfIdPoleNo);
                }
                return null;
            });

            rfidPole = _.without(rfidPole, null);
            let allPoles = [];
            _.forEach(rfidPole, (d) => {
                allPoles = _.concat(allPoles, d);
            });

            if (!_.isEmpty(allPoles)) {
                let filterRfidPoleLoc = [{ colId: 'id', text: allPoles }];
                let rfidPoleLocRes = await RfidPoleLocationModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterRfidPoleLoc, true, false, true);
                let rfidPoleLocs = rfidPoleLocRes && !_.isEmpty(rfidPoleLocRes) ? _.map(rfidPoleLocRes, 'dataValues') : [];

                let returnRes = [];
                _.forEach(rfidPoleLocs, (r) => {

                    let filteredStorageLocs = _.filter(storageLocs, (o) => {
                        if (o.rfIdPoleNo && !_.isEmpty(o.rfIdPoleNo) && Utils.isJsonString(o.rfIdPoleNo)) {
                            let parsed = JSON.parse(o.rfIdPoleNo);
                            if (!_.isEmpty(parsed)) {
                                return _.includes(parsed, r.id);
                            }
                        }
                        return false;
                    });
                    let storageLocationsDisplay = '';
                    _.forEach(filteredStorageLocs, (loc) => {
                        if (loc.storage) {
                            storageLocationsDisplay += loc.storage.code + ' | ';
                        }
                    });
                    storageLocationsDisplay = storageLocationsDisplay.trim();
                    if (storageLocationsDisplay.lastIndexOf('|') !== -1) {
                        if (storageLocationsDisplay.length === (storageLocationsDisplay.lastIndexOf('|') + 1)) {
                            storageLocationsDisplay = storageLocationsDisplay.substring(0, storageLocationsDisplay.length - 1);
                        }
                    }

                    let storageLocations = _.map(filteredStorageLocs, (n) => {
                        return {
                            id: n.id,
                            storageCode: n.storage ? n.storage.code : null,
                            storageName: n.storage ? n.storage.name : null
                        };
                    });
                    returnRes.push({
                        id: r.id,
                        code: r.code,
                        name: r.name,
                        storageLocations,
                        storageLocationsDisplay
                    });
                });

                return returnRes;
            }
        }

        return [];
    }

}


module.exports = Functions;