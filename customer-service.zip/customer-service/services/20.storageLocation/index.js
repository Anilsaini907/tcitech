const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customVal = require('./validation');

/**
 * Search StorageLocation Masterdata service
 * 
 * @route POST /storageLocation/search
 * @operationId searchStorageLocation
 * @group Storage Location API
 * @param {StorageLocationSearch.model} StorageLocationSearch.body - Search. Show all if not provided.
 * @returns {StorageLocationSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };
    
    return functions.getStorageLocation(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({...resp, order, search, filter});
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add StorageLocation Masterdata service
 * 
 * @route POST /storageLocation/add
 * @operationId addStorageLocation
 * @group Storage Location API
 * @param {AddStorageLocation.model} AddStorageLocation.body.required - required StorageLocation
 * @returns {Array.<StorageLocationData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customVal.validateAddStorageLocationData], async function (req, res, next) {
    const storageLocation = req.body.storageLocation;
    errorDef.parameterHandler([storageLocation]);
    _.forEach(storageLocation, (storageLocationObj) => {
        errorDef.parameterHandler([
            storageLocationObj.branchId,
            storageLocationObj.storageId,
            storageLocationObj.countryId,
            // storageLocationObj.areaOfUsageId,
            // storageLocationObj.zone,
            storageLocationObj.regionId,
            storageLocationObj.shipToAddress1,
            storageLocationObj.postcodeId,
            storageLocationObj.cityId,
            storageLocationObj.stateId
        ]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addStorageLocation(storageLocation, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Update StorageLocation Masterdata service
 * 
 * @route POST /storageLocation/update
 * @operationId updateStorageLocation
 * @group Storage Location API
 * @param {UpdateStorageLocation.model} UpdateStorageLocation.body.required - required StorageLocation
 * @returns {StorageLocationData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update',[customVal.validateUpdateStorageLocationData], async function (req, res, next) {
    const storageLocationId = req.body.id;
    const storageLocation = req.body.storageLocation;
    errorDef.parameterHandler([storageLocationId]);
    errorDef.parameterHandler([storageLocation]);
    // errorDef.parameterHandler([storageLocation.code, storageLocation.name]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: storageLocationId };
        return functions.updateStorageLocation(storageLocation, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete StorageLocation Masterdata service
 * 
 * @route DELETE /storageLocation/delete
 * @operationId deleteStorageLocation
 * @group Storage Location API
 * @param {DeleteStorageLocation.model} DeleteStorageLocation.body.required - required StorageLocation
 * @returns {Array.<StorageLocationData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete',[customVal.validateDeleteStorageLocationData], async function (req, res, next) {
    const storageLocationId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([storageLocationId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: storageLocationId };
        return functions.deleteStorageLocation(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

router.post('/searchRfIdPoles', async function (req, res, next) {
    // const employeeId = req.body.employeeId;
    
    // remove string Bearer
    if (req.headers.authorization && req.headers.authorization.startsWith("Bearer")) {
        req.headers.authorization = req.headers.authorization.substring(req.headers.authorization.indexOf("Bearer") + 7);
    }
    const token = req.headers.authorization;

    let pageObj = {
        token
    };
    
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.getRfIdPoles(pageObj, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
    
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

module.exports = router;