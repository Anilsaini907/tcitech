
const errorcodes = require('../services.config/error.codes');
const self = module.exports = {

    validateAddStorageLocationData: (req, res, next) => {
        req.checkBody('storageLocation', 'storageLocation parameter missing').trim().notEmpty().isArray();
        req.checkBody('storageLocation.*.branchId', 'branchId paramter is missing').trim().notEmpty();
        req.checkBody('storageLocation.*.storageId', 'storageId paramter is missing').trim().notEmpty();
        req.checkBody('storageLocation.*.shipToAddress1', 'shipToAddress1 paramter is missing').trim().notEmpty();
        req.checkBody('storageLocation.*.postcodeId', 'postcodeId paramter is missing').trim().notEmpty();
        req.checkBody('storageLocation.*.cityId', 'cityId paramter is missing').trim().notEmpty();
        req.checkBody('storageLocation.*.stateId', 'stateId paramter is missing').trim().notEmpty();
        req.checkBody('storageLocation.*.countryId', 'countryId paramter is missing').trim().notEmpty();
        // req.checkBody('storageLocation.*.zone', 'zone paramter is missing').trim().notEmpty();
        req.checkBody('storageLocation.*.regionId', 'regionId paramter is missing').trim().notEmpty();
        // req.checkBody('storageLocation.*.status', 'status paramter is missing').trim().notEmpty();
        req.checkBody('industry.*.status', 'status paramter is missing').custom(val => {
            return new Promise((resolve, reject) => {
                if (val.status === 'disabled') {
                    if (val.inactivateReason === null || val.inactivateReason === undefined || val.inactivateReason === '') {
                        reject();
                    } else {
                        resolve();
                    }
                }
            })


        });


        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },
    validateUpdateStorageLocationData: (req, res, next) => {
        req.checkBody('id', 'id parameter missing').trim().notEmpty();
        req.checkBody('storageLocation', 'storageLocation parameter missing').custom(val => {
            return new Promise((resolve, reject) => {
                if (val.branchId === null || val.branchId === undefined || val.branchId === '') {
                    reject();
                } else if (val.storageId === null || val.storageId === undefined || val.storageId === '') {
                    reject();
                } else if (val.shipToAddress1 === null || val.shipToAddress1 === undefined || val.shipToAddress1 === '') {
                    reject();
                // } else if (val.zone === null || val.zone === undefined || val.zone === '') {
                //     reject();
                } else if (val.postcodeId === null || val.postcodeId === undefined || val.postcodeId === '') {
                    reject();
                } else if (val.stateId === null || val.stateId === undefined || val.stateId === '') {
                    reject();
                } else if (val.status === null || val.status === undefined || val.status === '') {
                    reject();
                } else if (val.cityId === null || val.cityId === undefined || val.cityId === '') {
                    reject();
                } else if (val.regionId === null || val.regionId === undefined || val.regionId === '') {
                    reject();
                } else if (val.countryId === null || val.countryId === undefined || val.countryId === '') {
                    reject();
                } else if (val.status === 'disabled') {
                    if (val.inactivateReason === null || val.inactivateReason === undefined || val.inactivateReason === '') {

                        reject();
                    } else {
                        resolve();
                    }
                } else {
                    resolve();
                }
            })


        });
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateSearchStorageLocationData: (req, res, next) => {
        req.checkBody('page', 'page parameter missing').trim().notEmpty();
        req.checkBody('limit', 'limit parameter missing').trim().notEmpty();
        req.checkBody('order', 'order parameter missing').trim().notEmpty();
        req.checkBody('order.columnName', 'columnName parameter missing').trim().notEmpty();
        req.checkBody('order.direction', ' direction parameter missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateDeleteStorageLocationData: (req, res, next) => {
        req.checkBody('id', 'id parameter missing').trim().notEmpty();
        req.checkBody('option', 'option parameter missing').trim().notEmpty();

        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    }

}