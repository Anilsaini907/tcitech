const BusinessTypeModel = require('@driveit/driveit-databases/databases/customerMaster/models/21.businessType');
const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
var _ = require('lodash');

class Functions {

    static async getBusinessType(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };

        let attr = null;

        let distributionChannelRes = await BusinessTypeModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond);
    

        let resp = await CountryModel.searchAll([], ['id', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], [], true, true, true);
        let countries = resp && !_.isEmpty(resp) ? _.map(resp, 'dataValues') : [];
        
        _.forEach(distributionChannelRes.rows, (row) => {
            let found = _.find(countries, (o) => { return _.isEqual(o.id, row.countryId); });
            if (found) {
                row.dataValues['countryName'] = found.name ? found.name : '';
            }
        });
        

        return {
            ...distributionChannelRes,
            page: page.page,
            limit: page.limit
        };
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        
        //temp fix for PBI 663. Task 729. to display country Name
        return customerGroupModel.getAll(q, attr, pagination, page.order).then((customerGroupRes) => {
            let masterdataTypes = ["country"];
            let token = page.token? page.token : null;
            return generalCache.processMasterdataResult(customerGroupRes.rows, masterdataTypes, token).then((mdResults) => {
                _.forEach(customerGroupRes.rows, (row) => {
                    let mObj = {};
                    _.forEach(mdResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if(c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });
                        
                        if(mObj[key] && mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    });
                });
                return {
                    ...customerGroupRes,
                    page: page.page,
                    limit: page.limit
                };
            });
        });

        // return {
        //     ...await customerGroupModel.getAll(q, attr, pagination, page.order),
        //     page: page.page,
        //     limit: page.limit
        // };
    }

    static async addBusinessType(distributionChannelObj, who) {
        return BusinessTypeModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(distributionChannelObj, (addBusinessTypeObj) => {
                addBusinessTypeObj['createdBy'] = who;
                addBusinessTypeObj['updatedBy'] = who;
                const p = BusinessTypeModel.addNew(addBusinessTypeObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    static async updateBusinessType(distributionChannel, where, who) {
        distributionChannel['updatedBy'] = who;
        distributionChannel['id'] = where.id;
        return await BusinessTypeModel.updateBusinessType(distributionChannel, where).then(()=>{
            return BusinessTypeModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteBusinessType(where, who, type = "soft") {
        if(type == "soft") {
            return await BusinessTypeModel.deleteSoft(where, who).then(()=>{
                return BusinessTypeModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await BusinessTypeModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }

}


module.exports = Functions;