const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customVal = require('./validation');
/**
 * Search businesstype Masterdata service
 * 
 * @route POST /businessType/search
 * @operationId searchbusinessType
 * @group Business Type API
 * @param {BusinessTypeSearch.model} BusinessTypeSearch.body - Search. Show all if not provided.
 * @returns {BusinessTypeSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    return functions.getBusinessType(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});
/**
 * Add businessType Masterdata service
 * 
 * @route POST /businessType/add
 * @operationId addbusinessType
 * @group Business Type API
 * @param {AddBusinessType.model} AddBusinessType.body.required - required businessType
 * @returns {Array.<BusinessTypeData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', async function (req, res, next) {
    const businessType = req.body.businessType;

    errorDef.parameterHandler([businessType]);
    _.forEach(businessType, (businessTypeObj) => {
        errorDef.parameterHandler([businessTypeObj.code]);
        errorDef.parameterHandler([businessTypeObj.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addBusinessType(businessType, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update businessType Masterdata service
 * 
 * @route POST /businessType/update
 * @operationId updatebusinessType
 * @group Business Type API
 * @param {UpdateBusinessType.model} UpdateBusinessType.body.required - required businessType
 * @returns {BusinessTypeData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customVal.validateUpdateBusinessTypeData], async function (req, res, next) {
    const businessTypeId = req.body.id;
    const businessType = req.body.businessType;
    errorDef.parameterHandler([businessTypeId]);
    errorDef.parameterHandler([businessType]);
    // errorDef.parameterHandler([businessType.code, businessType.name]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: businessTypeId };
        return functions.updateBusinessType(businessType, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete businessType Masterdata service
 * 
 * @route DELETE /businessType/delete
 * @operationId deletebusinessType
 * @group Business Type API
 * @param {DeleteBusinessType.model} DeleteBusinessType.body.required - required businessType
 * @returns {Array.<BusinessTypeData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customVal.validateDeleteBusinessTypeData], async function (req, res, next) {
    const businessTypeId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([businessTypeId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: businessTypeId };
        return functions.deleteBusinessType(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 *   Export businessType Masterdata service
 * 
 * @route POST /businessType/export
 * @operationId exportbusinessType
 * @group Business Type API
 * @param {BusinessTypeSearch.model} BusinessTypeSearch.body - Search. Show all if not provided.
 * @returns {BusinessTypeSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }

    return functions.getBusinessType(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows: resp.rows,
            filename: 'distribution_channel'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});

module.exports = router;