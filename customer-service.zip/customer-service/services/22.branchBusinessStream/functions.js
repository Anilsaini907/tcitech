const BranchBusinessStreamModel = require('@driveit/driveit-databases/databases/customerMaster/models/22.branchBusinessStream');
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const Utils = require('../../utilities/utils');

class Functions {

    static async getBranchBusinessStream(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        if(search) {
            _.forEach(search, (searchObj) => {
                if(searchObj.colId === 'branchName') {
                    searchObj.colId = 'branch.name';
                } else if(searchObj.colId === 'branchCode') {
                    searchObj.colId = 'branch.code';
                } else if(searchObj.colId === 'businessStreamName') {
                    searchObj.colId = 'businessStream.name';
                } else if(searchObj.colId === 'businessStreamCode') {
                    searchObj.colId = 'businessStream.code';
                }
            });
        }

        let orderBy = page.order;
        
        return BranchBusinessStreamModel.searchAll(search, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond).then(async (branchBusinessStreamRes) => {
            // Country IDs
            let countryIds = _.without(_.uniq(_.map(branchBusinessStreamRes.rows, 'countryId')), '', null);
            let filterCountry = [{ colId: 'id', text: !_.isEmpty(countryIds) ? countryIds : ['00000000-0000-0000-0000-000000000000'] }];
            let countryRes = await CountryModel.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], filterCountry, true, true, true);
            let countries = countryRes ? _.map(countryRes, 'dataValues') : [];

            _.forEach(branchBusinessStreamRes.rows, (row) => {
                let foundCountry = _.find(countries, (o) => { return o.id === row.countryId; });
                row.dataValues['countryCode'] = foundCountry ? foundCountry.code : null;
                row.dataValues['countryName'] = foundCountry ? foundCountry.name : null;

                row.dataValues['branchCode'] = row.branch && row.branch.dataValues && row.branch.dataValues.code ? row.branch.dataValues.code : '';
                row.dataValues['branchName'] = row.branch && row.branch.dataValues && row.branch.dataValues.name ? row.branch.dataValues.name : '';
                row.dataValues['businessStreamCode'] = row.businessStream && row.businessStream.dataValues && row.businessStream.dataValues.code ? row.businessStream.dataValues.code : '';
                row.dataValues['businessStreamName'] = row.businessStream && row.businessStream.dataValues && row.businessStream.dataValues.name ? row.businessStream.dataValues.name : '';
                
                // row.dataValues = _.omit(row.dataValues, ['branch', 'businessStream']);
                // row = _.omit(row, ['branch', 'businessStream']);
            });

            
            return {
                ...branchBusinessStreamRes,
                page: page.page,
                limit: page.limit
            };
        });
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        
        //temp fix for PBI 663. Task 729. to display country Name
        return BranchBusinessStreamModel.getAll(q, attr, pagination, page.order).then((branchBusinessStreamRes) => {
            let masterdataTypes = ["country"];
            let token = page.token? page.token : null;
            return generalCache.processMasterdataResult(branchBusinessStreamRes.rows, masterdataTypes, token).then((mdResults) => {
                _.forEach(branchBusinessStreamRes.rows, (row) => {
                    let mObj = {};
                    _.forEach(mdResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if(c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });
                        
                        if(mObj[key] && mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    });
                });
                return {
                    ...branchBusinessStreamRes,
                    page: page.page,
                    limit: page.limit
                };
            });
        });

        // return {
        //     ...await BranchBusinessStreamModel.getAll(q, attr, pagination, page.order),
        //     page: page.page,
        //     limit: page.limit
        // };
    }

    static async addBranchBusinessStream(BranchBusinessStreamObj, who) {    
        var promises = [];
        _.forEach(BranchBusinessStreamObj, (addBranchBusinessStreamObj) => {
            addBranchBusinessStreamObj['createdBy'] = who;
            addBranchBusinessStreamObj['updatedBy'] = who;
            const p = 
            BranchBusinessStreamModel.getId({
                branchId: addBranchBusinessStreamObj.branchId,
                businessStreamId: addBranchBusinessStreamObj.businessStreamId
            }).then((branchBusinessStream) => {
                if (branchBusinessStream) {
                    throw errorDef.NOT_UNIQUE;
                } else {
                    return BranchBusinessStreamModel.addRecord(addBranchBusinessStreamObj);
                }
            });
            promises.push(p);
        });
        return Promise.all(promises);
    }

    static async updateBranchBusinessStream(BranchBusinessStream, where, who) {
        BranchBusinessStream['updatedBy'] = who;
        BranchBusinessStream['id'] = where.id;

        let resp = await BranchBusinessStreamModel.searchAll([], null, {}, ['updatedAt', 'desc'], [], true, false, true);
        
        let recordArr = resp ? _.map(resp, 'dataValues') : [];
        _.remove(recordArr, (o) => { return _.isEqual(o.id, where.id); });
        let found = _.find(recordArr, (o) => {
            return _.isEqual(o.branchId, BranchBusinessStream.branchId) && 
                _.isEqual(o.businessStreamId, BranchBusinessStream.businessStreamId)
        });
            
        if (found) {
            throw errorDef.NOT_UNIQUE;
        } else {
            
            await BranchBusinessStreamModel.updateRecord(BranchBusinessStream, where);
            let resp = await BranchBusinessStreamModel.getId(where);
            if(!resp) { 
                throw errorDef.MASTERDATA_NOT_FOUND;
            }
            return resp;  
        }
    }
    
    static async deleteBranchBusinessStream(where, who, type = "soft") {
        if(type == "soft") {
            return await BranchBusinessStreamModel.deleteSoft(where, who).then(()=>{
                return BranchBusinessStreamModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await BranchBusinessStreamModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }

}


module.exports = Functions;