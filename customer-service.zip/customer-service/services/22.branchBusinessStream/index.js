const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customVal = require('./validation');
/**
 * Search BranchBusinessStream Masterdata service
 * 
 * @route POST /branchBusinessStream/search
 * @operationId searchBranchBusinessStream
 * @group Branch Business Stream API
 * @param {BranchBusinessStreamSearch.model} BranchBusinessStreamSearch.body - Search. Show all if not provided.
 * @returns {BranchBusinessStreamSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search',  function async(req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    return functions.getBranchBusinessStream(search, pageObj, filter, showAll, distKeys, searchOrCond).then(resp => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    })
});
/**
 * Add BranchBusinessStream Masterdata service
 * 
 * @route POST /branchBusinessStream/add
 * @operationId addBranchBusinessStream
 * @group Branch Business Stream API
 * @param {AddBranchBusinessStream.model} AddBranchBusinessStream.body.required - required BranchBusinessStream
 * @returns {Array.<BranchBusinessStreamData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customVal.validateAddBranchBusinessStreamData], async function (req, res, next) {
    const branchBusinessStream = req.body.BranchBusinessStream;
    errorDef.parameterHandler([branchBusinessStream]);
    _.forEach(branchBusinessStream, (branchBusinessStream) => {
        errorDef.parameterHandler([branchBusinessStream.countryId, branchBusinessStream.branchId, branchBusinessStream.businessStreamId]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addBranchBusinessStream(branchBusinessStream, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update BranchBusinessStream Masterdata service
 * 
 * @route POST /branchBusinessStream/update
 * @operationId updateBranchBusinessStream
 * @group Branch Business Stream API
 * @param {UpdateBranchBusinessStream.model} UpdateBranchBusinessStream.body.required - required BranchBusinessStream
 * @returns {BranchBusinessStreamData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customVal.validateUpdateBranchBusinessStreamData], async function (req, res, next) {
    const BranchBusinessStreamId = req.body.id;
    const BranchBusinessStream = req.body.BranchBusinessStream;
    errorDef.parameterHandler([BranchBusinessStreamId]);
    errorDef.parameterHandler([BranchBusinessStream]);
    // errorDef.parameterHandler([BranchBusinessStream.code, BranchBusinessStream.name]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: BranchBusinessStreamId };
        return functions.updateBranchBusinessStream(BranchBusinessStream, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete BranchBusinessStream Masterdata service
 * 
 * @route DELETE /branchBusinessStream/delete
 * @operationId deleteBranchBusinessStream
 * @group Branch Business Stream API
 * @param {DeleteBranchBusinessStream.model} DeleteBranchBusinessStream.body.required - required BranchBusinessStream
 * @returns {Array.<BranchBusinessStreamData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customVal.validateDeleteBranchBusinessStreamData], async function (req, res, next) {
    const BranchBusinessStreamId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([BranchBusinessStreamId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: BranchBusinessStreamId };
        return functions.deleteBranchBusinessStream(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

module.exports = router;