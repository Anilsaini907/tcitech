const BranchBusinessTypeModel = require('@driveit/driveit-databases/databases/customerMaster/models/23.branchBusinessType');
const BranchModel = require('@driveit/driveit-databases/databases/customerMaster/models/18.branch');
const BusinessTypeModel = require('@driveit/driveit-databases/databases/customerMaster/models/21.businessType');
const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const Sequelize = require("sequelize");
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
var _ = require('lodash');
const customerMasterDb = require('@driveit/driveit-databases/databases/customerMaster');
const searchFunction = require('./functions.search');
const Op = Sequelize.Op;

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const sqlStatement = searchFunction.generateSearchSql(page, limit, order, searches, filter);

        const countResult = await customerMasterDb.sequelize.query(sqlStatement.sqlCount, { type: Sequelize.QueryTypes.SELECT });
        const result = await customerMasterDb.sequelize.query(sqlStatement.sql, { nest: true, type: Sequelize.QueryTypes.SELECT });

        result.forEach((row) => {
            row['countryCode'] = row.country ? row.country.code : null;
            row['countryName'] = row.country ? row.country.name : null;
        })

        return {
            count: countResult && countResult.length > 0 ? countResult[0].count : 0,
            rows: result
        };
    }

    static async getBranchBusinessType(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        const orderBy = page.order;

        let branchBusinessTypeRes = await BranchBusinessTypeModel.searchAll(search, null, pagination, orderBy, filter, true, showAll, false, [], null, distKeys, searchOrCond)

        let countryIds = _.uniq(_.compact(branchBusinessTypeRes.rows.map((bbt) => bbt.countryId)));
        let countries = await CountryModel.findAll({
            where: {id: countryIds, deleted: 0},
            attributes: ['id', 'code', 'name']
        })
        let branchIds = _.uniq(_.compact(branchBusinessTypeRes.rows.map((bbt) => bbt.branchId)));
        let branches = await BranchModel.findAll({
            where: {id: branchIds, deleted: 0},
            attributes: ['id', 'code', 'name']
        })
        let businessTypeIds = _.uniq(_.compact(branchBusinessTypeRes.rows.map((bbt) => bbt.businessTypeId)));
        let businessTypes = await BusinessTypeModel.findAll({
            where: {id: businessTypeIds, deleted: 0},
            attributes: ['id', 'code', 'name']
        })

        _.forEach(branchBusinessTypeRes.rows, (row) => {
            let foundCountry = _.find(countries, (o) => { return o.id === row.countryId; });
            row.dataValues['countryCode'] = foundCountry ? foundCountry.code : null;
            row.dataValues['countryName'] = foundCountry ? foundCountry.name : null;

            let foundBranch = _.find(branches, (o) => { return o.id === row.branchId; });
            row.dataValues['branch'] = foundBranch;
            
            let foundBusinessType = _.find(businessTypes, (o) => { return o.id === row.businessTypeId; });
            row.dataValues['businessType'] = foundBusinessType;
        });

        
        return {
            ...branchBusinessTypeRes,
            page: page.page,
            limit: page.limit
        };
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        
        //temp fix for PBI 663. Task 729. to display country Name
        return BranchBusinessTypeModel.getAll(q, attr, pagination, page.order).then((branchBusinessTypeRes) => {
            let masterdataTypes = ["country"];
            let token = page.token? page.token : null;
            return generalCache.processMasterdataResult(branchBusinessTypeRes.rows, masterdataTypes, token).then((mdResults) => {
                _.forEach(branchBusinessTypeRes.rows, (row) => {
                    let mObj = {};
                    _.forEach(mdResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if(c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });
                        
                        if(mObj[key] && mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    });
                });
                return {
                    ...branchBusinessTypeRes,
                    page: page.page,
                    limit: page.limit
                };
            });
        });

        // return {
        //     ...await customerGroupModel.getAll(q, attr, pagination, page.order),
        //     page: page.page,
        //     limit: page.limit
        // };
    }

    static async addBranchBusinessType(branchBusinessTypeObj, who) {
        var promises = [];
        _.forEach(branchBusinessTypeObj, (addBranchBusinessTypeObj) => {
            addBranchBusinessTypeObj['createdBy'] = who;
            addBranchBusinessTypeObj['updatedBy'] = who;
            const p = 
            BranchBusinessTypeModel.getId({
                branchId: addBranchBusinessTypeObj.branchId,
                businessTypeId: addBranchBusinessTypeObj.businessTypeId
            }).then((branchBusinessType) => {
                if (branchBusinessType) {
                    throw errorDef.NOT_UNIQUE;
                } else {
                    return BranchBusinessTypeModel.addRecord(addBranchBusinessTypeObj);
                }
            });
            promises.push(p);
        });
        return Promise.all(promises);
    }

    static async updateBranchBusinessType(branchBusinessType, where, who) {
        branchBusinessType['updatedBy'] = who;
        branchBusinessType['id'] = where.id;
        
        let resp = await BranchBusinessTypeModel.searchAll([], null, {}, ['updatedAt', 'desc'], [], true, false, true);
        
        let recordArr = resp ? _.map(resp, 'dataValues') : [];
        _.remove(recordArr, (o) => { return _.isEqual(o.id, where.id); });
        let found = _.find(recordArr, (o) => {
            return _.isEqual(o.branchId, branchBusinessType.branchId) && 
                _.isEqual(o.businessTypeId, branchBusinessType.businessTypeId)
        });
        
        if (found) {
            throw errorDef.NOT_UNIQUE;
        } else {
            
            await BranchBusinessTypeModel.updateRecord(branchBusinessType, where);
            let resp = await BranchBusinessTypeModel.getId(where);
            if(!resp) { 
                throw errorDef.MASTERDATA_NOT_FOUND;
            }
            return resp;
        }
    }

    static async deleteBranchBusinessType(where, who, type = "soft") {
        if(type == "soft") {
            return await BranchBusinessTypeModel.deleteSoft(where, who).then(()=>{
                return BranchBusinessTypeModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await BranchBusinessTypeModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }

}

module.exports = Functions;