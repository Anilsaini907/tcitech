var _ = require('lodash');

class SearchFunction {
    static convertField(flatField) {
    switch (flatField) {
        case 'businessType.code+businessType.name':
        return {
            keys: ['code', 'name'],
            table: 'businessType'
        };
        case 'businessType.code':
        return {
            keys: ['code'],
            table: 'businessType'
        };
        case 'businessType.name':
        return {
            keys: ['name'],
            table: 'businessType'
        };
        case 'branch.code':
        return {
            keys: ['code'],
            table: 'branch'
        };
        case 'branch.name':
        return {
            keys: ['name'],
            table: 'branch'
        };

        default:
        return {
            key: flatField,
            table: 'A'
        };
    }
    }

    static generateQueryParameter(search, filter) {
    const queries = {
        'A': [{ colId: 'deleted', operator: '=', text: '0' }],
        'country': [],
        'branch': [],
        'businessType': [],
    };

    if (search) {
        _.forEach(search, (searchObj) => {
        const col = this.convertField(searchObj.colId);
        if (col.keys) {
            _.forEach(searchObj.text, (likeArrItem) => {
            queries[col.table].push({ colId: searchObj.colId, keys: col.keys, operator: 'LIKE', text: `%${likeArrItem}%` });
            });
        } else {
            _.forEach(searchObj.text, (likeArrItem) => {
            queries[col.table].push({ colId: col.key, operator: 'LIKE', text: `%${likeArrItem}%` });
            });
        }
        });
    }

    if (filter) {
        _.forEach(filter, (filterObj) => {
        const col = this.convertField(filterObj.colId);

        queries[col.table].push({ colId: col.key, operator: '=', text: filterObj.text[0] });
        });
    }

    return queries;
    }

    static generateWhereCondition(queryParamters) {
    const where = [];

    Object.keys(queryParamters).forEach(key => {
        const query = queryParamters[key];

        if (query.length > 0) {
        const preQuery = [];

        const group = _.groupBy(query, 'colId');
        Object.keys(group).forEach(columnName => {
            const columnConditions = group[columnName];

            switch (columnName) {
            case 'make.code+make.name':
            case 'branch.code':
            case 'branch.name':
            case 'businessType.code':
            case 'businessType.name':
                const preCustomChild = [];

                _.forEach(columnConditions[0].keys, sepreatedKey => {
                preCustomChild.push(`${key}.${sepreatedKey} ${columnConditions[0].operator} '${columnConditions[0].text}'`);
                });

                preQuery.push('(' + preCustomChild.join(' OR ') + ')');
                break;

            default:
                if (columnConditions.length > 0) {
                    const preQueryChild = [];
    
                    _.forEach(columnConditions, columnCondition => {
                        switch (columnCondition.operator) {
                            case 'IN':
                            case 'BETWEEN':
                            preQueryChild.push(`${key}.${columnName} ${columnCondition.operator} ${columnCondition.text}`);
                            break;
        
                            default: 
                            if (key === 'SQL') {
                                preQueryChild.push(`${columnName} ${columnCondition.operator} '${columnCondition.text}'`);
                                break;
                            }
        
                            if (columnCondition.type && columnCondition.type === 'number') {
                                preQueryChild.push(`${key}.${columnName} ${columnCondition.operator} ${columnCondition.text}`);
                                break;
                            }
        
                            preQueryChild.push(`${key}.${columnName} ${columnCondition.operator} '${columnCondition.text}'`);
                            break;
                        }
                    });
    
                    preQuery.push('(' + preQueryChild.join(' OR ') + ')');
                }
                break;
            }
        });

        where.push('(' + preQuery.join(' AND ') + ')');
        }
    });

    return where;
    }

    static generateOrderCondition(order) {
        const orders = [];

        if (order) {
        const col = this.convertField(order.columnName);

        if (col.keys) {
            _.forEach(col.keys, (key) => {
            orders.push(`${col.table}.${key} ${order.direction}`);
            });
        } else {
            orders.push(`${col.table}.${col.key} ${order.direction}`);
        }
        }

        return orders;
    }

    static getSearchSql(whereStatement, orderStatement, offset, limit) {
    const sql = `
        SELECT 
        A.id,
        A.countryId,
        A.branchId,
        A.businessTypeId,
        A.status,
        A.deleted,
        A.inactivateReason,
        A.createdBy,
        A.updatedBy,
        A.createdAt,
        A.updatedAt,
        country.id AS 'country.id',
        country.code AS 'country.code',
        country.name AS 'country.name',
        branch.id AS 'branch.id',
        branch.code AS 'branch.code',
        branch.name AS 'branch.name',
        businessType.id AS 'businessType.id',
        businessType.code AS 'businessType.code',
        businessType.name AS 'businessType.name'
        FROM
        customer_master.branchBusinessType A
            LEFT JOIN
        general_master.country country ON A.countryId = country.id
            AND country.deleted = 0
            LEFT JOIN
        customer_master.branch branch ON A.branchId = branch.id
            AND branch.deleted = 0
            LEFT JOIN
        customer_master.businessType businessType ON A.businessTypeId = businessType.id
            AND businessType.deleted = 0
        WHERE ${whereStatement}
        ORDER BY ${orderStatement}
        LIMIT ${offset}, ${limit}
                `;

        const sqlCount = `
        SELECT COUNT(1) AS count
        FROM
        customer_master.branchBusinessType A
            LEFT JOIN
        general_master.country country ON A.countryId = country.id
            AND country.deleted = 0
            LEFT JOIN
        customer_master.branch branch ON A.branchId = branch.id
            AND branch.deleted = 0
            LEFT JOIN
        customer_master.businessType businessType ON A.businessTypeId = businessType.id
            AND businessType.deleted = 0
        WHERE ${whereStatement}
        `;

        return { sql, sqlCount };
    }

    static generateSearchSql(page, limit, order, search, filter) {
        const queryParamter = this.generateQueryParameter(search, filter);
        const where = this.generateWhereCondition(queryParamter);
        const orders = this.generateOrderCondition(order);

        const whereStatement = where.join(' AND ');
        const orderStatement = orders.join(', ');
        const offset = limit * (page - 1);

        return this.getSearchSql(whereStatement, orderStatement, offset, limit);
    }
}

module.exports = SearchFunction;
