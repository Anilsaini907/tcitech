const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customVal = require('./validation');
/**
 * Search distributionchannel Masterdata service
 * 
 * @route POST /branchBusinessType/search
 * @operationId searchbranchBusinessType
 * @group Branch Business Type API API
 * @param {BranchBusinessTypeSearch.model} BranchBusinessTypeSearch.body - Search. Show all if not provided.
 * @returns {BranchBusinessTypeSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };

    // return functions.getBranchBusinessType(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
    return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});
/**
 * Add distributionchannel Masterdata service
 * 
 * @route POST /branchBusinessType/add
 * @operationId addbranchBusinessType
 * @group Branch Business Type API API
 * @param {AddBranchBusinessType.model} AddBranchBusinessType.body.required - required distributionchannel
 * @returns {Array.<BranchBusinessTypeData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customVal.validateAddBranchBusinessTypeData], async function (req, res, next) {
    const branchBusinessType = req.body.branchBusinessType;

    errorDef.parameterHandler([branchBusinessType]);
    _.forEach(branchBusinessType, (branchBusinessTypeObj) => {
        errorDef.parameterHandler([
            branchBusinessTypeObj.countryId,
            branchBusinessTypeObj.branchId,
            branchBusinessTypeObj.businessTypeId,
            branchBusinessTypeObj.status
        ]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addBranchBusinessType(branchBusinessType, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update branchBusinessType Masterdata service
 * 
 * @route POST /branchBusinessType/update
 * @operationId updatebranchBusinessType
 * @group Branch Business Type API API
 * @param {UpdateBranchBusinessType.model} UpdateBranchBusinessType.body.required - required distributionchannel
 * @returns {BranchBusinessTypeData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customVal.validateUpdateBranchBusinessTypeData], async function (req, res, next) {
    const branchBusinessTypeId = req.body.id;
    const branchBusinessType = req.body.branchBusinessType;

    errorDef.parameterHandler([branchBusinessTypeId]);
    errorDef.parameterHandler([branchBusinessType]);
    // errorDef.parameterHandler([distributionchannel.code, distributionchannel.name]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: branchBusinessTypeId };
        return functions.updateBranchBusinessType(branchBusinessType, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete branchBusinessType Masterdata service
 * 
 * @route DELETE /branchBusinessType/delete
 * @operationId deletebranchBusinessType
 * @group Branch Business Type API API
 * @param {DeleteBranchBusinessType.model} DeleteBranchBusinessType.body.required - required distributionchannel
 * @returns {Array.<BranchBusinessTypeData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customVal.validateDeleteBranchBusinessTypeData], async function (req, res, next) {
    const branchBusinessTypeId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([branchBusinessTypeId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: branchBusinessTypeId };
        return functions.deleteBranchBusinessType(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 *   Export branchBusinessType Masterdata service
 * 
 * @route POST /branchBusinessType/export
 * @operationId exportbranchBusinessType
 * @group Branch Business Type API API
 * @param {BranchBusinessTypeSearch.model} BranchBusinessTypeSearch.body - Search. Show all if not provided.
 * @returns {BranchBusinessTypeSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };

    return functions.getBranchBusinessType(search, pageObj, filter).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows: resp.rows,
            filename: 'branch_business_type'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});

module.exports = router;