const CompanyBranchModel = require('@driveit/driveit-databases/databases/customerMaster/models/24.companyBranch');
const CompanyModel = require('@driveit/driveit-databases/databases/customerMaster/models/7.company');
const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const BranchModel = require('@driveit/driveit-databases/databases/customerMaster/models/18.branch');
const Sequelize = require("sequelize");
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
const db = require('@driveit/driveit-databases/databases/customerMaster');
var _ = require('lodash');
const Utils = require('@driveit/driveit-databases/utils/database.utils');

const Op = Sequelize.Op;

class Functions {

    static async getCompanyBranch(search, page, filter, basicSearch = false, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        };
        let orderBy = page.order;


        if (search) {
            let excludedSearch = _.remove(search, (o) => { return o.colId === 'countryCode' || o.colId === 'countryName'; });
            let searched = await this.prepQry(excludedSearch);
            search = _.concat(search, searched);
        }


        //* Process filtering BusinessType Start

        let isFilterWithBsTypeService = false;

        const filterWithBusinessType = filter ? filter.find(x => x.colId === 'filterWithBusinessType') : null;

        let businessTypeServiceId = '';

        if (filterWithBusinessType) {
            if (filterWithBusinessType.text.find(x => x === 'service')) {
                isFilterWithBsTypeService = true;
                const sql = `SELECT * FROM customer_master.businessType
                            WHERE code = 20 AND deleted = 0
                            LIMIT 1`
                const businessTypeService = await db.sequelize.query(sql, { type: Sequelize.QueryTypes.SELECT });

                if (businessTypeService.length > 0) {
                    businessTypeServiceId = businessTypeService[0].id;
                }
            }

            filter = filter.filter(x => x.colId !== 'filterWithBusinessType');
        }

        const filterWithBusinessTypeMake = filter ? filter.find(x => x.colId === 'filterWithBusinessTypeMake') : null;

        let BusinessTypeMakeId = '';

        if (filterWithBusinessTypeMake) {
            BusinessTypeMakeId = filterWithBusinessTypeMake.text[0];
            filter = filter.filter(x => x.colId !== 'filterWithBusinessTypeMake');
        }

        // Process filtering BusinessType End

        if (basicSearch) {
            const attr = ['id', 'countryId', 'branchId', 'companyId'];
            let companyBranchRes = await CompanyBranchModel.searchAll(search, attr, pagination, orderBy, filter, true, showAll, true, [], null, distKeys, searchOrCond);
            return {
                rows: companyBranchRes,
                page: page.page,
                limit: page.limit
            };
        }

        let companyBranchRes = await CompanyBranchModel.searchAll(search, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
        if (isFilterWithBsTypeService && businessTypeServiceId) {
            companyBranchRes.rows = companyBranchRes.rows.filter(companyBranch => {
                const branchWithBusinessTypeService = companyBranch.branch.branchMakeBusinessTypes.find(branchMakeBusinessType => {
                    const isService = branchMakeBusinessType.businessTypeIds.search(businessTypeServiceId);
                    let isMake = true;

                    if (BusinessTypeMakeId) {
                        isMake = (branchMakeBusinessType.makeId === BusinessTypeMakeId);
                    }

                    if (isService !== -1 && isMake) {
                        return true;
                    }
                });
                if (branchWithBusinessTypeService) {
                    return true;
                }
            });
        }

        companyBranchRes.count = companyBranchRes.rows.length;

        _.forEach(companyBranchRes.rows, (row) => {
            row.dataValues['companyName'] = row.company && row.company.dataValues && row.company.dataValues.name ? row.company.dataValues.name : '';
            row.dataValues['companyCode'] = row.company && row.company.dataValues && row.company.dataValues.code ? row.company.dataValues.code : '';
            row.dataValues['branchName'] = row.branch && row.branch.dataValues && row.branch.dataValues.name ? row.branch.dataValues.name : '';
            row.dataValues['branchCode'] = row.branch && row.branch.dataValues && row.branch.dataValues.code ? row.branch.dataValues.code : '';
            row.dataValues['stateId'] = row.branch && row.branch.dataValues && row.branch.dataValues.stateId ? row.branch.dataValues.stateId : '';
            row.dataValues['countryId'] = row.branch && row.branch.dataValues && row.branch.dataValues.countryId ? row.branch.dataValues.countryId : '';
            // row.dataValues = _.omit(row.dataValues, ['company', 'branch']);
            // row = _.omit(row, ['company', 'branch']);
        });

        let countryIds = _.without(_.map(companyBranchRes.rows, (r) => {
            if (r.dataValues) {
                return r.dataValues.countryId;
            }
            return null;
        }), null);

        let filterCountry = [{ colId: 'id', text: !_.isEmpty(countryIds) ? countryIds : ['00000000-0000-0000-0000-000000000000'] }];
        let countryRes = await CountryModel.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], filterCountry, true, false, true);
        let countries = countryRes ? _.map(countryRes, 'dataValues') : [];

        _.forEach(companyBranchRes.rows, (rw) => {
            let foundCountry = _.find(countries, (o) => { return o.id === rw.dataValues.countryId; });
            rw.dataValues['countryCode'] = foundCountry ? foundCountry.code : null;
        });

        return {
            ...companyBranchRes,
            page: page.page,
            limit: page.limit
        };
    }

    static async prepQry(search) {
        let likeArr = [];
        let searchMasterDatas = [];
        for (let i = 0; i < _.size(search); i++) {

            if (search[i].colId === 'countryName') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "name", text: search[i].text }],
                        skipInclude: true
                    });
                } else {
                    let found = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found) {
                        found.search.push({ colId: "name", text: search[i].text });
                    }
                }
            } else if (search[i].colId === 'countryCode') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "code", text: search[i].text }],
                        skipInclude: true
                    });
                } else {
                    let found1 = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found1) {
                        found1.search.push({ colId: "code", text: search[i].text });
                    }
                }
            }
        }

        let queryResult = await generalCache.getMasterDataByQuery(searchMasterDatas);
        if (queryResult) {
            if (queryResult.country) {
                let countryIds = [];
                queryResult.country.forEach((country) => {
                    countryIds.push(country.id);
                })
                likeArr.push({ colId: 'countryId', text: !_.isEmpty(countryIds) ? countryIds : ['00000000-0000-0000-0000-000000000000'] });
            }
        }

        return likeArr;
    }

    static async getCompanyBranchV2(page, limit, order, searches, filter, attribute, basicSearch = false, distKeys = null) {
        let where = {
            deleted: false,
        };

        const andFilter = Utils.filterGenerator(filter);
        if (andFilter.length > 0) {
            _.forEach(andFilter, (val) => {
                _.forEach(val, (v, k) => {
                    where[k] = v;
                });
            });
        }

        const orSearch = Utils.searchGeneratorV2(searches);
        if (orSearch && orSearch.length) {
            where = {
                ...where,
                [Op.or]: orSearch
            };
        }

        if (attribute !== undefined && _.isArray(attribute)) {
        }

        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };

        return CompanyBranchModel.getRecords3({
            pagination,
            where,
            orderBy: order,
            include: basicSearch ? [] : null,
            group: distKeys
        }).then(async (recordResults) => {
            if (basicSearch) {
                return {
                    ...recordResults,
                    page: page,
                    limit: limit
                };
            }

            return {
                ...recordResults,
                page: page,
                limit: limit
            };
        });
    }

    static async getCompanyBranchId(payload) {
        if (payload.companyId) {
            const sql = `
                -- 1. Get list of companyBranch where companyId IN (list company where parentCompanyId = tenants.companyId)  
                SELECT A.branchId
                FROM customer_master.companyBranch A 
                    INNER JOIN customer_master.company B ON B.id = A.companyId AND B.deleted = 0 AND B.status = 'enabled' 
                WHERE A.deleted = 0 
                    AND A.status = 'enabled' 
                    AND B.parentCompanyId = :companyId
                UNION

                -- 2. Get list of companyBranch where companyId = tenants.companyId 
                SELECT branchId
                FROM customer_master.companyBranch 
                WHERE deleted = 0 
                    AND status = 'enabled' 
                    AND companyId = :companyId
                UNION

                -- Get list of companyBranch from company where parentCompanyId = (list company where parentCompanyId = tenants.companyId))
                SELECT A.branchId
                FROM customer_master.companyBranch 		A 
                    INNER JOIN customer_master.company 	B ON B.id = A.companyId AND B.deleted = 0 AND B.status = 'enabled'
                WHERE A.deleted = 0 
                    AND A.status = 'enabled' 
                    AND B.parentCompanyId IN (
                        SELECT id 
                        FROM customer_master.company 
                        WHERE parentCompanyId = :companyId
                    )
                ;
            `;

            const result = await db.sequelize.query(sql, { replacements: { companyId: payload.companyId }, type: Sequelize.QueryTypes.SELECT });

            if (result && result.length) {
                return result.map(x => x.branchId);
            }
        }

        return [];
    }

    static async getAll(page) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;

        //temp fix for PBI 663. Task 729. to display country Name
        return CompanyBranchModel.getAll(q, attr, pagination, page.order).then((companyBranchRes) => {
            let masterdataTypes = ["country"];
            let token = page.token ? page.token : null;
            return generalCache.processMasterdataResult(companyBranchRes.rows, masterdataTypes, token).then((mdResults) => {
                _.forEach(companyBranchRes.rows, (row) => {
                    let mObj = {};
                    _.forEach(mdResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if (c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });

                        if (mObj[key]) {
                            if (mObj[key].code) {
                                let masterDataNameStr = `${key}Code`;
                                row.dataValues[masterDataNameStr] = mObj[key].code;
                            }
                        }
                    });
                });
                return {
                    ...companyBranchRes,
                    page: page.page,
                    limit: page.limit
                };
            });
        });
    }

    static async addCompanyBranch(companyBranchArr, who) {
        var promises = [];
        _.forEach(companyBranchArr, (addCompanyBranchObj) => {
            addCompanyBranchObj['createdBy'] = who;
            addCompanyBranchObj['updatedBy'] = who;

            const p =
                CompanyBranchModel.getId({ companyId: addCompanyBranchObj.companyId, branchId: addCompanyBranchObj.branchId }).then((companyBranch) => {
                    if (companyBranch) {
                        throw errorDef.NOT_UNIQUE;
                    } else {
                        return CompanyBranchModel.addRecord(addCompanyBranchObj);
                    }
                });
            promises.push(p);
        });
        return Promise.all(promises);
    }

    static async updateCompanyBranch(companyBranch, where, who) {
        companyBranch['updatedBy'] = who;
        companyBranch['id'] = where.id;

        let resp = await CompanyBranchModel.searchAll([], null, {}, ['updatedAt', 'desc'], [], true, false, true);
        let recordArr = resp ? _.map(resp, 'dataValues') : [];

        _.remove(recordArr, (o) => { return _.isEqual(o.id, where.id); });
        let found = _.find(recordArr, (o) => { return _.isEqual(o.companyId, companyBranch.companyId) && _.isEqual(o.branchId, companyBranch.branchId); });
        if (found) {
            throw errorDef.NOT_UNIQUE;
        } else {
            await CompanyBranchModel.updateRecord(companyBranch, where);
            let resp = await CompanyBranchModel.getId(where);
            if (!resp) {
                throw errorDef.MASTERDATA_COMPANY_VS_BRANCH_NOT_FOUND;
            }
            return resp;
        }
    }

    static async deleteCompanyBranch(where, who, type = "soft") {
        if (type == "soft") {
            return await CompanyBranchModel.deleteSoft(where, who).then(() => {
                return CompanyBranchModel.getAll(where, null).then((resp) => {
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await CompanyBranchModel.deleteHard(where).then((resp) => {
                if (!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }

}

module.exports = Functions;