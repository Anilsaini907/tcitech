const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customVal = require('./validation');
/**
 * Search Company vs branch Masterdata service
 * 
 * @route POST /companyBranch/search
 * @operationId searchCompanyBranch
 * @group Company Vs Branch API
 * @param {CompanyBranchSearch.model} CompanyBranchSearch.body - Search. Show all if not provided.
 * @returns {CompanyBranchSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const basicSearch = req.body.basicSearch;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };

    return functions.getCompanyBranch(search, pageObj, filter, basicSearch, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_COMPANY_VS_BRANCH_NOT_FOUND;
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});

router.post('/searchV2', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;

    const attribute = req.body.attribute;
    const basicSearch = req.body.basicSearch;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;

    const token = req.headers.authorization;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.getCompanyBranchV2(page, limit, order, search, filter, attribute, basicSearch, distKeys).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_COMPANY_VS_BRANCH_NOT_FOUND;
        }

        return res.status(200).send({ ...resp, order, search, filter, attribute });
    }).catch((reason) => {
        next(reason);
    });
});

router.post('/getCompanyBranchId', async (req, res, next) => {
    return functions.getCompanyBranchId(req.body)
        .then((result) => res.status(200).send(result))
        .catch((reason) => next(reason));
});

/**
 * Add Company vs branch Masterdata service
 * 
 * @route POST /companyBranch/add
 * @operationId addCompanyBranch
 * @group Company Vs Branch API
 * @param {AddCompanyBranch.model} AddCompanyBranch.body.required - required CompanyBranch
 * @returns {Array.<CompanyBranchData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customVal.validateAddCompanyBranchData], async function (req, res, next) {
    const companyBranch = req.body.companyBranch;

    errorDef.parameterHandler([companyBranch]);
    _.forEach(companyBranch, (companyBranchObj) => {
        errorDef.parameterHandler([
            companyBranchObj.countryId,
            companyBranchObj.companyId,
            companyBranchObj.branchId,
            companyBranchObj.status
        ]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addCompanyBranch(companyBranch, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_COMPANY_VS_BRANCH_NOT_FOUND;
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }

});
/**
 * Update Company vs branch Masterdata service
 * 
 * @route POST /companyBranch/update
 * @operationId updateCompanyBranch
 * @group Company Vs Branch API
 * @param {UpdateCompanyBranch.model} UpdateCompanyBranch.body.required - required CompanyBranch
 * @returns {CompanyBranchData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customVal.validateUpdateCompanyBranchData], async function (req, res, next) {
    const companyBranchId = req.body.id;
    const companyBranch = req.body.companyBranch;

    errorDef.parameterHandler([companyBranchId]);
    errorDef.parameterHandler([companyBranch]);

    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: companyBranchId };
        return functions.updateCompanyBranch(companyBranch, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_COMPANY_VS_BRANCH_NOT_FOUND;
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete Company vs branch Masterdata service
 * 
 * @route DELETE /companyBranch/delete
 * @operationId deleteCompanyBranch
 * @group Company Vs Branch API
 * @param {DeleteCompanyBranch.model} DeleteCompanyBranch.body.required - required CompanyBranch
 * @returns {Array.<CompanyBranchData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customVal.validateDeleteCompanyBranchData], async function (req, res, next) {
    const companyBranchId = req.body.id;
    const deleteOption = req.body.option;

    errorDef.parameterHandler([companyBranchId, deleteOption]);

    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: companyBranchId };
        return functions.deleteCompanyBranch(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_COMPANY_VS_BRANCH_NOT_FOUND;
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export Company vs branch Masterdata service
 * 
 * @route POST /companyBranch/export
 * @operationId exportCompanyBranch
 * @group Company Vs Branch API
 * @param {CompanyBranchSearch.model} CompanyBranchSearch.body - Search. Show all if not provided.
 * @returns {CompanyBranchSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };

    return functions.getCompanyBranch(search, pageObj, filter).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_COMPANY_VS_BRANCH_NOT_FOUND;
        }
        let data = {
            rows: resp.rows,
            filename: 'company-vs-branch'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});

module.exports = router;
