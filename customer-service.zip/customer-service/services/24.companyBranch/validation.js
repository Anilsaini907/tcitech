
const errorcodes = require('../services.config/error.codes');
const self = module.exports = {

    validateAddCompanyBranchData: (req, res, next) => {
        req.checkBody('companyBranch', 'companyBranch parameter missing').trim().notEmpty().isArray();
        req.checkBody('companyBranch.*.countryId', 'countryId paramter is missing').trim().notEmpty();
        req.checkBody('companyBranch.*.companyId', 'companyId paramter is missing').trim().notEmpty();
        req.checkBody('companyBranch.*.branchId', 'branchId paramter is missing').trim().notEmpty();
        req.checkBody('companyBranch.*.status', 'status paramter is missing').trim().notEmpty();
        // req.checkBody('companyBranch.*.inactivateReason', 'Inactivate Reason paramter is missing').trim().notEmpty().optional();


        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },
    validateUpdateCompanyBranchData: (req, res, next) => {
        req.checkBody('id', 'id parameter missing').trim().notEmpty();
        req.checkBody('companyBranch', 'companyBranch parameter missing').custom(val => {
            return new Promise((resolve, reject) => {
                if (val.countryId === null || val.countryId === undefined || val.countryId === '') {
                    reject();
                } else if (val.status === null || val.status === undefined || val.status === '') {
                    reject();
                } else if (val.status === 'disabled') {
                    if (val.inactivateReason === null || val.inactivateReason === undefined || val.inactivateReason === '') {

                        reject();
                    } else {
                        resolve();
                    }
                } else {
                    resolve();
                }
            })


        });
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateSearchCompanyBranchData: (req, res, next) => {
        req.checkBody('page', 'page parameter missing').trim().notEmpty();
        req.checkBody('limit', 'limit parameter missing').trim().notEmpty();
        req.checkBody('order', 'order parameter missing').trim().notEmpty();
        req.checkBody('order.columnName', 'columnName parameter missing').trim().notEmpty();
        req.checkBody('order.direction', ' direction parameter missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateDeleteCompanyBranchData: (req, res, next) => {
        req.checkBody('id', 'id parameter missing').trim().notEmpty();
        req.checkBody('option', 'option parameter missing').trim().notEmpty();

        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    }

}