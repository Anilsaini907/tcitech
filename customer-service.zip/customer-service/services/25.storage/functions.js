const StorageModel = require('@driveit/driveit-databases/databases/customerMaster/models/25.storage');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getStorage(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;

        let storageRes = await StorageModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond);
        
        return {
            ...storageRes,
            page: page.page,
            limit: page.limit
        };
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        
        return StorageModel.getAll(q, attr, pagination, page.order).then((storageRes) => {
            
            return {
                ...storageRes,
                page: page.page,
                limit: page.limit
            };
        });
    }

    static async addStorage(datas, who) {
        return StorageModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(datas, (obj) => {
                obj['createdBy'] = who;
                obj['updatedBy'] = who;
                const p = StorageModel.addRecord(obj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }

    static async updateStorage(data, where, who) {
        data['updatedBy'] = who;
        data['id'] = where.id;
        return StorageModel.updateRecord(data, where).then(()=>{
            return StorageModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }

    static async bulkUpdateStorage(datas, who) {
        const updatedIds = [];
        var promises = [];
        _.forEach(datas, (updateObj) => {
            updatedIds.push(updateObj.id);

            let where = { id: updateObj.id };
            updateObj['updatedBy'] = who;

            const p = StorageModel.updateRecord(updateObj, where);
            promises.push(p);
        });
        return Promise.all(promises).then((res) => {
            return StorageModel.getAll({ id: updatedIds }, null).then((resp) => {
                return resp.rows;
            });
        });
    }

    static async deleteStorage(where, who, type = "soft") {
        if(type == "soft") {
            return await StorageModel.deleteSoft(where, who).then(()=>{
                return StorageModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await StorageModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }

}


module.exports = Functions;