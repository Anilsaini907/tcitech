const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');


router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    return functions.getStorage(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND;
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});

router.post('/add', async function (req, res, next) {
    const datas = req.body.datas;
    errorDef.parameterHandler([datas]);
    _.forEach(datas, (data) => {
        errorDef.parameterHandler([data.code]);
        errorDef.parameterHandler([data.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addStorage(datas, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND;
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

router.post('/update', async function (req, res, next) {
    const id = req.body.id;
    const data = req.body.data;
    errorDef.parameterHandler([id]);
    errorDef.parameterHandler([data]);
    
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: id };
        return functions.updateStorage(data, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND;
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

router.post('/bulk-update', async function (req, res, next) {
    const datas = req.body.datas;
    errorDef.parameterHandler([datas]);
    _.forEach(datas, (data) => {
        errorDef.parameterHandler([data]);
    });
    
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.bulkUpdateStorage(datas, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND;
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

router.delete('/delete', async function (req, res, next) {
    const ids = req.body.ids;
    const deleteOption = req.body.option;
    errorDef.parameterHandler(ids);
    errorDef.parameterHandler([deleteOption]);

    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = {id : ids};
        return functions.deleteStorage(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND;
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

// router.post('/export', function (req, res, next) {
//     const search = req.body.search;
//     const page = req.body.page;
//     const limit = req.body.limit;
//     const order = req.body.order;

//     if (search) {
//         _.forEach(search, (searchObj) => {
//             errorDef.parameterHandler([searchObj.colId, searchObj.text]);
//         });
//     }
//     errorDef.parameterHandler([page, limit, order]);
//     errorDef.parameterHandler([order.columnName, order.direction]);
//     let pageObj = {
//         page,
//         limit,
//         order: [order.columnName, order.direction]
//     }

//     return functions.getBusinessType(search, pageObj, []).then((resp) => {
//         if (!resp) {
//             throw errorDef.MASTERDATA_NOT_FOUND
//         }
//         let data = {
//             rows: resp.rows,
//             filename: 'distribution_channel'
//         };

//         return ExportAPI.exportData(null, data).then(response => {
//             if (!response) {
//                 throw errorDef.EXPORTDATA_NOT_FOUND;
//             }
//             return res.status(200).send(response);
//         });

//     }).catch((reason) => {
//         next(reason);
//     });
// });

module.exports = router;