const EmploymentStatusModel = require('@driveit/driveit-databases/databases/customerMaster/models/27.employmentStatus');

var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")

class Functions {

    static async getEmploymentStatus(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };

        let attr = null;
        return {
            ...await EmploymentStatusModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        };
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await EmploymentStatusModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addEmploymentStatus(areaOfUsageObj, who) {
        return EmploymentStatusModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(areaOfUsageObj, (addEmploymentStatusObj) => {
                addEmploymentStatusObj['createdBy'] = who;
                addEmploymentStatusObj['updatedBy'] = who;
                
                const p = 
                EmploymentStatusModel.getId({code: addEmploymentStatusObj.code}).then((resp)=>{
                    if(!resp) {
                        return EmploymentStatusModel.addNew(addEmploymentStatusObj, t);
                    } else {
                        throw errorDef.NOT_UNIQUE;
                    }
                });
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    
    static async updateEmploymentStatus(employmentStatus, where, who) {
        employmentStatus['updatedBy'] = who;
        return EmploymentStatusModel.getId({code: employmentStatus.code}).then((resp)=>{
            if(resp && (resp.id !== where.id)) {
                throw errorDef.NOT_UNIQUE;
            } else {
                return EmploymentStatusModel.updateEmploymentStatus(employmentStatus, where).then(()=>{
                    return EmploymentStatusModel.getId(where).then((resp)=>{
                        if(!resp) {
                           throw errorDef.MASTERDATA_EMPLOYMENT_STATUS_NOT_FOUND;
                        }
                        return resp;
                    });
                });
            }
        });
    }
    static async deleteEmploymentStatus(where, who, type = "soft") {
        if(type == "soft") {
            return await EmploymentStatusModel.deleteSoft(where, who).then(()=>{
                return EmploymentStatusModel.getAll(where, null).then((resp)=>{
                    // if(!resp) {
                    // throw errorDef.MASTERDATA_NOT_FOUND;
                    // }
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await EmploymentStatusModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;