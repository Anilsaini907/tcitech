const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customVal = require('./validation');
/**
 * Search for EmploymentStatus listing
 * 
 * @route POST /employmentStatus/search
 * @operationId employmentStatusSearch
 * @group EmploymentStatus API
 * @param {EmploymentStatusSearch.model} EmploymentStatusSearch.body - Search. Show all if not provided.
 * @returns {EmploymentStatusSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search',  function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };

    return functions.getEmploymentStatus(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_AREA_OF_USAGE_NOT_FOUND
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add EmploymentStatus Masterdata service
 * 
 * @route POST /employmentStatus/add
 * @operationId addEmploymentStatus
 * @group EmploymentStatus API
 * @param {AddEmploymentStatus.model} AddEmploymentStatus.body.required - required AddEmploymentStatus
 * @returns {Array.<EmploymentStatusData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/add', [customVal.validateAddEmploymentStatusesData], async function (req, res, next) {
    const employmentStatuses = req.body.employmentStatuses;
    errorDef.parameterHandler([employmentStatuses]);
    _.forEach(employmentStatuses, (employmentStatusObj) => {
        errorDef.parameterHandler([employmentStatusObj.code, employmentStatusObj.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addEmploymentStatus(employmentStatuses, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_EMPLOYMENT_STATUS_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update EmploymentStatus
 * 
 * @route POST /employmentStatus/update
 * @operationId updateEmploymentStatus
 * @group EmploymentStatus API
 * @param {UpdateEmploymentStatus.model} UpdateEmploymentStatus.body.required - required UpdateEmploymentStatus
 * @returns {EmploymentStatusData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customVal.validateUpdateEmploymentStatusesData], async function (req, res, next) {
    const employmentStatusId = req.body.id;
    const employmentStatus = req.body.employmentStatus;
    errorDef.parameterHandler([employmentStatus]);

    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: employmentStatusId };
        return functions.updateEmploymentStatus(employmentStatus, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_EMPLOYMENT_STATUS_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete EmploymentStatus
 * 
 * @route DELETE /employmentStatus/delete
 * @operationId deleteEmploymentStatus
 * @group EmploymentStatus API
 * @param {DeleteEmploymentStatus.model} DeleteEmploymentStatus.body.required - required DeleteEmploymentStatus
 * @returns {Array.<EmploymentStatusData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customVal.validateDeleteEmploymentStatusesData], async function (req, res, next) {
    const ids = req.body.ids;
    const option = req.body.option;

    errorDef.parameterHandler([ids, option]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: ids };
        return functions.deleteEmploymentStatus(where, userInfo.id, option).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_EMPLOYMENT_STATUS_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export EmploymentStatus Masterdata service
 * 
 * @route POST /employmentStatus/export
 * @operationId exportEmploymentStatus
 * @group EmploymentStatus API
 * @param {EmploymentStatusSearch.model} EmploymentStatusSearch.body - Search. Show all if not provided.
 * @returns {EmploymentStatusSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };

    return functions.getEmploymentStatus(search, pageObj, filter).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_EMPLOYMENT_STATUS_NOT_FOUND;
        }
        let data = {
            rows: resp.rows,
            filename: 'area-of-usage'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});

module.exports = router;