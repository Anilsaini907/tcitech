const CustomerTypeModel = require('@driveit/driveit-databases/databases/customerMaster/models/28.customerType');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getCustomerType(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;
        return {
            ...await CustomerTypeModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        }
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await CustomerTypeModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addCustomerType(customerTypeObj, who) {
        return CustomerTypeModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(customerTypeObj, (addCustomerTypeObj) => {
                addCustomerTypeObj['createdBy'] = who;
                addCustomerTypeObj['updatedBy'] = who;
                const p = CustomerTypeModel.addNew(addCustomerTypeObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    
    static async updateCustomerType(customerType, where, who) {
        customerType['updatedBy'] = who;
        customerType['id'] = where.id;
        return await CustomerTypeModel.updateCustomerType(customerType, where).then(()=>{
            return CustomerTypeModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteCustomerType(where, who, type = "soft") {
        if(type == "soft") {
            return await CustomerTypeModel.deleteSoft(where, who).then(()=>{
                return CustomerTypeModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await CustomerTypeModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;