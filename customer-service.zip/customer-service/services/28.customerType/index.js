const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customVal = require('./validation');
/**
 * Search CustomerType Masterdata service
 * 
 * @route POST /customerType/search
 * @operationId searchCustomerType
 * @group CustomerType Options API
 * @param {CustomerTypeSearch.model} CustomerTypeSearch.body - Search. Show all if not provided.
 * @returns {CustomerTypeSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    return functions.getCustomerType(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});
/**
 * Add CustomerType Masterdata service
 * 
 * @route POST /customerType/add
 * @operationId addCustomerType
 * @group CustomerType Options API
 * @param {AddCustomerType.model} AddCustomerType.body.required - required CustomerType
 * @returns {Array.<CustomerTypeData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customVal.validateAddCustomerTypeData], async function (req, res, next) {
    const customerType = req.body.customerType;
    errorDef.parameterHandler([customerType]);
    _.forEach(customerType, (customerTypeObj) => {
        errorDef.parameterHandler([customerTypeObj.code, customerTypeObj.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addCustomerType(customerType, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update CustomerType Masterdata service
 * 
 * @route POST /customerType/update
 * @operationId updateCustomerType
 * @group CustomerType Options API
 * @param {UpdateCustomerType.model} UpdateCustomerType.body.required - required CustomerType
 * @returns {CustomerTypeData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customVal.validateUpdateCustomerTypeData], async function (req, res, next) {
    const customerTypeId = req.body.id;
    const customerType = req.body.customerType;
    errorDef.parameterHandler([customerTypeId]);
    errorDef.parameterHandler([customerType]);
    // errorDef.parameterHandler([customerType.code, customerType.name]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: customerTypeId };
        return functions.updateCustomerType(customerType, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete CustomerType Masterdata service
 * 
 * @route DELETE /customerType/delete
 * @operationId deleteCustomerType
 * @group CustomerType Options API
 * @param {DeleteCustomerType.model} DeleteCustomerType.body.required - required CustomerType
 * @returns {Array.<CustomerTypeData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customVal.validateDeleteCustomerTypeData], async function (req, res, next) {
    const customerTypeId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([customerTypeId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: customerTypeId };
        return functions.deleteCustomerType(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export CustomerType Masterdata service
 * 
 * @route POST /customerType/export
 * @operationId exportCustomerType
 * @group CustomerType Options API
 * @param {CustomerTypeSearch.model} CustomerTypeSearch.body - Search. Show all if not provided.
 * @returns {CustomerTypeSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }

    return functions.getCustomerType(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows: resp.rows,
            filename: 'customerType'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;