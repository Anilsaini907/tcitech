const DealerGroupModel = require('@driveit/driveit-databases/databases/customerMaster/models/29.dealerGroup');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const Sequelize = require("sequelize");
class Functions {
    static async getDealerGroup(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;
        return {
            ...await DealerGroupModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        }
    }

    static async getAll(page) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await DealerGroupModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addDealerGroup(dealerGroupObj, who) {
        return DealerGroupModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(dealerGroupObj, (addDealerGroupObj) => {
                addDealerGroupObj['createdBy'] = who;
                addDealerGroupObj['updatedBy'] = who;
                const p = DealerGroupModel.addNew(addDealerGroupObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }

    static async getDealerGroupByBranch(branchId) {
        return new Promise(async (resolve, reject) => {
            DealerGroupModel.sequelize.query(`
            SELECT customer_master.dealerGroup.code FROM customer_master.companyBranch 
            INNER Join customer_master.company on
            customer_master.company.id = customer_master.companyBranch.companyId
            Inner Join customer_master.dealerGroup on
            customer_master.company.dealerGroupId = customer_master.dealerGroup.id
            WHERE branchId = '${branchId}'
            AND customer_master.companyBranch.deleted = 0`, {
                type: DealerGroupModel.sequelize.QueryTypes.SELECT
            }).then(result => {
                resolve(result );
            })
        });
    }
    static async updateDealerGroup(dealerGroup, where, who) {
        dealerGroup['updatedBy'] = who;
        dealerGroup['id'] = where.id;
        return await DealerGroupModel.updateDealerGroup(dealerGroup, where).then(() => {
            return DealerGroupModel.getId(where).then((resp) => {
                if (!resp) {
                    throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteDealerGroup(where, who, type = "soft") {
        if (type == "soft") {
            return await DealerGroupModel.deleteSoft(where, who).then(() => {
                return DealerGroupModel.getAll(where, null).then((resp) => {
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await DealerGroupModel.deleteHard(where).then((resp) => {
                if (!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;