const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');
/**
 * Search DealerGroup Masterdata service
 * 
 * @route POST /dealerGroup/search
 * @operationId searchDealerGroup
 * @group DealerGroup API
 * @param {DealerGroupSearch.model} DealerGroupSearch.body - Search. Show all if not provided.
 * @returns {DealerGroupSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    return functions.getDealerGroup(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});
/**
 * Add DealerGroup Masterdata service
 * 
 * @route POST /dealerGroup/add
 * @operationId addDealerGroup
 * @group DealerGroup API
 * @param {AddDealerGroup.model} AddDealerGroup.body.required - required DealerGroup
 * @returns {Array.<DealerGroupData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customValidator.validateCreateTaxClass], async function (req, res, next) {
    const dealerGroup = req.body.dealerGroup;
    errorDef.parameterHandler([dealerGroup]);
    _.forEach(dealerGroup, (dealerGroupObj) => {
        errorDef.parameterHandler([dealerGroupObj.code, dealerGroupObj.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.addDealerGroup(dealerGroup, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update DealerGroup Masterdata service
 * 
 * @route POST /dealerGroup/update
 * @operationId updateDealerGroup
 * @group DealerGroup API
 * @param {UpdateDealerGroup.model} UpdateDealerGroup.body.required - required DealerGroup
 * @returns {DealerGroupData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customValidator.validateUpdateTaxClass], async function (req, res, next) {
    const dealerGroupId = req.body.id;
    const dealerGroup = req.body.dealerGroup;
    errorDef.parameterHandler([dealerGroupId]);
    errorDef.parameterHandler([dealerGroup]);
    // errorDef.parameterHandler([dealerGroup.code, dealerGroup.name]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: dealerGroupId };
        return functions.updateDealerGroup(dealerGroup, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete DealerGroup Masterdata service
 * 
 * @route DELETE /dealerGroup/delete
 * @operationId deleteDealerGroup
 * @group DealerGroup API
 * @param {DeleteDealerGroup.model} DeleteDealerGroup.body.required - required DealerGroup
 * @returns {Array.<DealerGroupData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteTaxClass], async function (req, res, next) {
    const dealerGroupId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([dealerGroupId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        let where = { id: dealerGroupId };
        return functions.deleteDealerGroup(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export DealerGroup Masterdata service
 * 
 * @route POST /dealerGroup/export
 * @operationId exportDealerGroup
 * @group DealerGroup API
 * @param {DealerGroupSearch.model} DealerGroupSearch.body - Search. Show all if not provided.
 * @returns {DealerGroupSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }

    return functions.getDealerGroup(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows: resp.rows,
            filename: 'dealerGroup'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});
router.post('/getDealerByBranch', function (req, res, next) {
    const branchId = req.body.branchId;
    return functions.getDealerGroupByBranch(branchId).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        return res.status(200).send(resp);
    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;