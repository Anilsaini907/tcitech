const BlockModel = require('@driveit/driveit-databases/databases/customerMaster/models/3.block');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getBlock(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;
        return {
            ...await BlockModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        }
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await BlockModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addBlock(blockObj, who) {
        return BlockModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(blockObj, (addBlockObj) => {
                addBlockObj['createdBy'] = who;
                addBlockObj['updatedBy'] = who;
                const p = BlockModel.addNew(addBlockObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    static async updateBlock(block, where, who) {
        block['updatedBy'] = who;
        block['id'] = where.id;
        return await BlockModel.updateBlock(block, where).then(()=>{
            return BlockModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteBlock(where, who, type = "soft") {
        if(type == "soft") {
            return await BlockModel.deleteSoft(where, who).then(()=>{
                return BlockModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await BlockModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;