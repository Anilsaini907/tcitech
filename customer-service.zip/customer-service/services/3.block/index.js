const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');
/**
 * Search Block Masterdata service
 * 
 * @route POST /block/search
 * @operationId searchBlock
 * @group Block Options API
 * @param {BlockSearch.model} BlockSearch.body - Search. Show all if not provided.
 * @returns {BlockSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
        return functions.getBlock(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }

            return res.status(200).send({...resp, order, search, filter});
        }).catch((reason) => {
            next(reason);
        });
});
/**
 * Add Block Masterdata service
 * 
 * @route POST /block/add
 * @operationId addBlock
 * @group Block Options API
 * @param {AddBlock.model} AddBlock.body.required - required Block
 * @returns {Array.<BlockData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customValidator.validateCreateBlock], async function (req, res, next) {
    const block = req.body.block;
    errorDef.parameterHandler([block]);
    _.forEach(block, (blockObj) => {
        errorDef.parameterHandler([blockObj.code, blockObj.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addBlock(block, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update Block Masterdata service
 * 
 * @route POST /block/update
 * @operationId updateBlock
 * @group Block Options API
 * @param {UpdateBlock.model} UpdateBlock.body.required - required Block
 * @returns {BlockData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customValidator.validateUpdateBlock], async function (req, res, next) {
    const blockId = req.body.id;
    const block = req.body.block;
    errorDef.parameterHandler([blockId]);
    errorDef.parameterHandler([block]);
    // errorDef.parameterHandler([block.code, block.name]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: blockId };
        return functions.updateBlock(block, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete Block Masterdata service
 * 
 * @route DELETE /block/delete
 * @operationId deleteBlock
 * @group Block Options API
 * @param {DeleteBlock.model} DeleteBlock.body.required - required Block
 * @returns {Array.<BlockData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteBlock], async function (req, res, next) {
    const blockId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([blockId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: blockId };
        return functions.deleteBlock(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export Block Masterdata service
 * 
 * @route POST /block/export
 * @operationId exportBlock
 * @group Block Options API
 * @param {BlockSearch.model} BlockSearch.body - Search. Show all if not provided.
 * @returns {BlockSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    
    return functions.getBlock(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows:resp.rows,
            filename:'block'
        };

        return ExportAPI.exportData(null, data).then(response =>{
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });
        
    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;