const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateBlock: (req, res, next) => {
        req.checkBody('block', 'Block object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('block.*.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('block.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('block.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateBlock: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('block', 'Block object parameter is missing').trim().notEmpty();
        req.checkBody('block.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('block.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('block.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteBlock: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}