const Sequelize = require("sequelize");
const Op = Sequelize.Op;
var _ = require('lodash');
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');

const generalCache = require('../cache-request/general-api');

const BranchRouteModel = require('@driveit/driveit-databases/databases/customerMaster/models/31.branchRoutes')
const BranchModel = require('@driveit/driveit-databases/databases/customerMaster/models/18.branch');
// const DropPointModel = require('@driveit/driveit-databases/databases/customerMaster/models/30.dropPoint');

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        const orderBy = [order.columnName, order.direction];
        

        return await BranchRouteModel.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
    }

    static async getAll(page) {
        const pagination = {
            limit: page.limit,
            offset: limit ? limit * (page - 1) : undefined,
        }
        let q = {};
        let attr = null;

        return BranchModel.getAll(q, likeArr, attr, pagination, orderBy, filter).then((recordResults) => {
            let masterdataTypes = ["country", "currency", "postcode", "city", "state", "region"];
            let token = page.token ? page.token : null;
            return generalCache.processMasterdataResult(recordResults.rows, masterdataTypes, token, headers.authorization).then((mdResults) => {
                _.forEach(recordResults.rows, (row) => {
                    let mObj = {};
                    _.forEach(recordResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if (c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });
                        if (mObj[key] && mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    });
                });
                generalCache.processRowRecords(recordResults, mdResults);
                return recordResults;
            });
        });
    }


    static async addMany(branches, who) {
        let promises = [];
        let dropPointData = branches[0].dropPoints;
        let routesData = branches[0].routes;

        for (let t = 0; t < branches.length; t++) {
            let branch = branches[t];
            if (branches.length == 1) { //for singles
                return Functions.add(branch, who).then((data) => {
                    var promises = []
                    // dropPointData.forEach((dropPointDataItem) => {
                    //     dropPointDataItem['branchId'] = data.id;
                    //     dropPointDataItem['createdBy'] = who;
                    //     dropPointDataItem['updatedBy'] = who;
                    //     let p = DropPointModel.addNew(dropPointDataItem)
                    //     promises.push(p);
                    // })
                    routesData.forEach((routeData) => {
                        routeData['branchId'] = data.id;
                        routeData['createdBy'] = who;
                        routeData['updatedBy'] = who;
                        let p = BranchRouteModel.addNew(routeData);
                        promises.push(p);
                    })
                    return Promise.all(promises);
                });
            }
            //else multiple
            promises.push(Functions.add(branch, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        }

        return Promise.all(promises).then((response) => {

        });
    }
    static async add(branch, who) {
        branch['updatedBy'] = who;
        branch['createdBy'] = who;
        return BranchModel.addRecord(branch).then((record) => {
            return record;
        });
    }

    static async update(id, branch, who) {
        const where = {
            id
        }
        branch['updatedBy'] = who;
        branch['id'] = id;
        Functions.deleteDropPoint(id, branch, who);
        return BranchModel.updateRecord(branch, where).then((record) => {
            return BranchModel.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];
        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return BranchModel.deleteHard(where).then((record) => {
                return BranchModel.getOne(where);
            });
        } else if (option === 'soft') {

            return BranchModel.deleteSoft(where, who).then(() => {
                return BranchModel.getOne(where);
            });

        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

    static async deleteDropPoint(id, branch, who) {
        const where = {
            branchId: id
        }
        if (branch.dropPoints) {
            branch.dropPoints.forEach(async p => {
                let option = 'hard';
                if (option === 'hard') {
                    // await DropPointModel.deleteHard(where);
                } else {
                    // throw errorDef.INVALID_OPTION;
                }
            })

            // await branch.dropPoints.forEach((dropPointDataItem) => {
            //     dropPointDataItem['branchId'] = id;
            //     dropPointDataItem['createdBy'] = who;
            //     dropPointDataItem['updatedBy'] = who;
            //     DropPointModel.addNew(dropPointDataItem);
            // })
        }
    }
}


module.exports = Functions;