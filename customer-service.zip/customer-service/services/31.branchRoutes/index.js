const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
const customVal = require('./validation');
/**
 * Search for Branch listing
 * 
 * @route POST /branch/search
 * @operationId branchSearch
 * @group Branch API
 * @param {BranchSearch.model} BranchSearch.body - Search. Show all if not provided.
 * @returns {BranchSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        search.forEach((searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        })
    }
    errorDef.parameterHandler([order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond).then((resp) => {

        return res.status(200).send({
            ...resp,
            order,
            page,
            limit,
            search,
            filter
        });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add Branch
 * 
 * @route PUT /branch/add
 * @operationId branchAdd
 * @group Branch API
 * @param {AddBranch.model} AddBranch.body.required - required AddBranch
 * @returns {Array.<BranchData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.put('/add', async function (req, res, next) {
    const branches = req.body.branch;
    if (req.body.branch.businessTypeIds === null || req.body.branch.businessTypeIds === undefined) {
        req.body.branch.businessTypeIds = "";
    }

    errorDef.parameterHandler([branches]);
    branches.forEach((branch) => {
        errorDef.parameterHandler([branch.code, branch.status]);
    })

    //testing
    // userInfo = { id: " --"} ;

    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });

    if (userInfo) {
        return functions.addMany(branches, userInfo.id).then((result) => {
            return res.status(200).send(result);
        })
            .catch((reason) => {
                next(reason);
            });
    }
});

/**
 * Update Branch
 * 
 * @route PUT /branch/update
 * @operationId branchUpdate
 * @group Branch API
 * @param {UpdateBranch.model} UpdateBranch.body.required - required UpdateBranch
 * @returns {BranchData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.put('/update', async function (req, res, next) {
    const id = req.body.id;
    if (req.body.branch.businessTypeIds === null || req.body.branch.businessTypeIds === undefined) {
        req.body.branch.businessTypeIds = "";
    }

    const branch = req.body.branch;

    errorDef.parameterHandler([id, branch]);

    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.update(id, branch, userInfo.id).then((record) => {
            if (!record) {
                throw errorDef.RECORD_NOT_FOUND
            }
            return res.status(200).send(record);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete Branch
 * 
 * @route DELETE /branch/delete
 * @operationId branchDelete
 * @group Branch API
 * @param {DeleteBranch.model} DeleteBranch.body.required - required DeleteBranch
 * @returns {BranchData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customVal.validateDeleteBranchData], async function (req, res, next) {
    const ids = req.body.ids;
    const option = req.body.option;

    errorDef.parameterHandler([ids]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.deleteMany(ids, option, userInfo.id).then((response) => {
            return res.status(200).send(response);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Export for Branch listing
 * 
 * @route POST /branch/Export
 * @operationId branchExport
 * @group Branch API
 * @param {BranchSearch.model} BranchSearch.body - Search. Show all if not provided.
 * @returns {BranchSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/export', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;
    const headers = req.body.headers;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }

    return functions.search(page, limit, order, search, filter, headers).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows: resp.rows,
            filename: 'branch'
        };

        return ExportAPI.exportData(null, data).then(response => {
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });

    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;