var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');
const CalendarIndicatorModel = require('@driveit/driveit-databases/databases/customerMaster/models/32.calendarIndicator');
const CompanyModel = require('@driveit/driveit-databases/databases/customerMaster/models/7.company');
class Functions {

   
    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        const orderBy = [order.columnName, order.direction];
        

        return await CalendarIndicatorModel.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
    }

    static async addMany(datas, who) {
        
        for (let i = 0; i < datas.length; i++) {
            datas[i].createdBy = who;
            datas[i].updatedBy = who;
        }
        return CalendarIndicatorModel.bulkAdd(datas).then(result => {
            return result
        }).catch(err => err);
    }

    static update(datas, companyId, who) {
        let promiseArr = [];
        for (let i = 0; i < datas.length; i++) {
            datas[i].updatedBy = who;
            datas[i].createdBy = datas[i].createdBy ? datas[i].createdBy : who;
            promiseArr.push(CalendarIndicatorModel.updateRecord(datas[i]));            
        }

        return Promise.all(promiseArr).then(async (result) => {
            let udpatedData = await this.getUpdatedRow(companyId);
            return Promise.resolve(udpatedData);
        }).catch((reason) => {
            return Promise.reject(reason);
        });
    }

    static getUpdatedRow(companyId) {
        let where = {companyId};
        return CalendarIndicatorModel.findWhere(where);
    }

    static getCompanyIds() {
        return CompanyModel.getAllCompanyIds();
    }
}


module.exports = Functions;