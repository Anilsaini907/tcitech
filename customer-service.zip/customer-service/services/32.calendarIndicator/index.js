const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
const customVal = require('./validation');

/**
 * Search for CalendarIndicator listing
 * 
 * @route POST /calendarIndicator/search
 * @operationId calendarIndicatorSearch
 * @group CalendarIndicator API
 * @param {CalendarIndicatorSearch.model} CalendarIndicatorSearch.body - Search. Show all if not provided.
 * @returns {CalendarIndicatorSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        search.forEach((searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        })
    }
    errorDef.parameterHandler([order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond).then((resp) => {

        return res.status(200).send({
            ...resp,
            order,
            page,
            limit,
            search,
            filter
        });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add CalendarIndicator
 * 
 * @route POST /calendarIndicator/add
 * @operationId calendarIndicatorAdd
 * @group CalendarIndicator API
 * @param {AddCalendarIndicator.model} AddCalendarIndicator.body.required - required AddCalendarIndicator
 * @returns {Array.<CalendarIndicatorData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/add', [customVal.validateAddTypeData], async function (req, res, next) {
    const datas = req.body.datas;
    const userInfo = await errorDef.userInfoHandler(req).catch(err => {
        next(err);
    });

    if (userInfo) {
        try {
            let result = await functions.addMany(datas, userInfo.id);
            return res.status(200).send(result);
        } catch (error) {
            next(error);
        }
    }
});

/**
 * Update CalendarIndicator
 * 
 * @route PUT /calendarIndicator/update
 * @operationId calendarIndicatorUpdate
 * @group CalendarIndicator API
 * @param {UpdateCalendarIndicator.model} UpdateCalendarIndicator.body.required - required UpdateCalendarIndicator
 * @returns {CalendarIndicatorData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', async function (req, res, next) {
    const datas = req.body.datas;
    const companyId = req.body.companyId;

    const userInfo = await errorDef.userInfoHandler(req).catch(err => {
        console.error(err);
        next(err);
    });
    
    if (userInfo) {
        return functions.update(datas, companyId, userInfo.id).then((record) => {
            return res.status(200).send(record);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete CalendarIndicator
 * 
 * @route DELETE /calendarIndicator/delete
 * @operationId calendarIndicatorDelete
 * @group CalendarIndicator API
 * @param {DeleteCalendarIndicator.model} DeleteCalendarIndicator.body.required - required DeleteCalendarIndicator
 * @returns {CalendarIndicatorData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', async function (req, res, next) {
    const ids = req.body.ids;
    const option = req.body.option;

    errorDef.parameterHandler([ids]);
    const userInfo = await errorDef.userInfoHandler(req)
        .catch(err => {
            console.error(err);
            next(err);
        });
    if (userInfo) {
        return functions.deleteMany(ids, option, userInfo.id).then((response) => {
            return res.status(200).send(response);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * InsertDefaultData CalendarIndicator
 * 
 * @route POST /calendarIndicator/insertDefaultData
 * @operationId calendarIndicatorInsertDefaultData
 * @group CalendarIndicator API
 * @param {AddCalendarIndicator.model} AddCalendarIndicator.body.required - required AddCalendarIndicator
 * @returns {Array.<CalendarIndicatorData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/insertDefaultData', async function (req, res, next) {
    let companyIds = await functions.getCompanyIds();
    let companyIdsArr = companyIds.map(e => e.id);
    let count = 0;
    companyIdsArr.forEach(async (ele) => {
        // default values calender  -- > getDefaultData
        let data = customVal.getDefaultData(ele);
        let result = await functions.addMany(data, "DEVELOPMENT");
        count++;
        if(count == companyIdsArr.length) {
            return res.status(200).send(companyIdsArr);
        }
    })
});

module.exports = router;