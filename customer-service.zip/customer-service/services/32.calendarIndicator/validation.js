
const errorcodes = require('../services.config/error.codes');
const self = module.exports = {

    getDefaultData: (companyId) => {
        return [
                    {
                        "colorName": "green",
                        "min": 0,
                        "max": 50,	
                        "companyId": `${companyId}`,
                    },
                    {
                        "colorName": "yellow",
                        "min": 51,
                        "max": 100,
                        "companyId": `${companyId}`,
                    },
                    {
                        "colorName": "orange",
                        "min": 101,
                        "max": 150,
                        "companyId": `${companyId}`,
                    },
                    {
                        "colorName": "red",
                        "min": 151,
                        "max": 200,
                        "companyId": `${companyId}`,
                    }
                ]
            }
,
    validateAddTypeData: (req, res, next) => {
        req.checkBody('datas', 'datas parameter missing').trim().notEmpty().isArray();
        req.checkBody('datas.*.colorName', 'Color name paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.min', 'Booking percentage from paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.max', 'Booking percentage to paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.companyId', 'companyId paramter is missing').trim().notEmpty();


        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateUpdateTypeData: (req, res, next) => {
        req.checkBody('datas', 'datas parameter missing').trim().notEmpty().isArray();
        req.checkBody('datas.*.colorName', 'Color name paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.min', 'Booking percentage from paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.max', 'Booking percentage to paramter is missing').trim().notEmpty()
        req.checkBody('datas.*.companyId', 'companyId paramter is missing').trim().notEmpty()
        .custom(val => {
            return new Promise((resolve, reject) => {
                if (val.code === null || val.code === undefined || val.code === '') {
                    reject();
                } else if (val.name === null || val.name === undefined || val.name === '') {
                    reject();
                } else if (val.status === null || val.status === undefined || val.status === '') {
                    reject();
                } else if (val.status === 'disabled') {
                    if (val.inactivateReason === null || val.inactivateReason === undefined || val.inactivateReason === '') {

                        reject();
                        }else{
                            resolve();
                        }
                } else {
                    resolve();
                }
            })
        });
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateSearchTypeData: (req, res, next) => {

        req.checkBody('datas.*.colorName', 'Color name paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.min', 'Booking percentage from paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.max', 'Booking percentage to paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.companyId', 'companyId paramter is missing').trim().notEmpty();

        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    },

    validateDeleteTypeData: (req, res, next) => {

        req.checkBody('datas.*.colorName', 'Color name paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.min', 'Booking percentage from paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.max', 'Booking percentage paramter is missing').trim().notEmpty();
        req.checkBody('datas.*.companyId', 'companyId paramter is missing').trim().notEmpty();


        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let resultError = errorcodes.INVALID_PARAMETER;
                resultError.errors = errors;
                return res.status(200).json({ resultError });
            }
        });
    }

}