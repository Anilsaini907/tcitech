const CustomerCorrespondenceAddress = require('@driveit/driveit-databases/databases/customerMaster').CustomerCorrespondenceAddress;
var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');
const CustomerCorrespondenceModel = require('@driveit/driveit-databases/databases/customerMaster/models/33.customerCorrespondenceAddress');
const generalCache = require('../cache-request/general-api');

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        const orderBy = [order.columnName, order.direction];

        const res = await CustomerCorrespondenceAddress.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);

        let searchMasterDatas = [];
        const postcodeIds = _.map(res.rows, 'postcodeId');
        if(postcodeIds && postcodeIds.length > 0) {
            searchMasterDatas.push({
                masterdata: 'postcode',
                filter: [{ colId: "id", text: postcodeIds }],
                attributes: ['id', 'code', 'updatedAt'],
                skipInclude: true
            });
        }
        const cityIds = _.map(res.rows, 'cityId');
        if(cityIds && cityIds.length > 0) {
            searchMasterDatas.push({
                masterdata: 'city',
                filter: [{ colId: "id", text: cityIds }],
                attributes: ['id', 'code', 'name', 'updatedAt'],
                skipInclude: true
            });
        }
        const stateIds = _.map(res.rows, 'stateId');
        if(stateIds && stateIds.length > 0) {
            searchMasterDatas.push({
                masterdata: 'state',
                filter: [{ colId: "id", text: stateIds }],
                attributes: ['id', 'code', 'name', 'updatedAt'],
                skipInclude: true
            });
        }
        const countryIds = _.map(res.rows, 'countryId');
        if(countryIds && countryIds.length > 0) {
            searchMasterDatas.push({
                masterdata: 'country',
                filter: [{ colId: "id", text: countryIds }],
                attributes: ['id', 'code', 'name', 'updatedAt'],
                skipInclude: true
            });
        }
        const telCodeIds = res.rows.map((row) => row.telCode);
        const faxCodeIds = res.rows.map((row) => row.faxCode);
        const mobileCodeIds = res.rows.map((row) => row.mobileCode);
        const areaOperatorCodeIds = [...telCodeIds, ...faxCodeIds, ...mobileCodeIds]
        if(areaOperatorCodeIds.length > 0) {
            searchMasterDatas.push({
                masterdata: 'areaOperatorCode',
                search: [{ colId: "id", text: areaOperatorCodeIds }],
                attributes: ['id', 'code', 'updatedAt'],
                skipInclude: true
            });
        }

        const masterdataRes = await generalCache.getMasterDataByQuery(searchMasterDatas);
        if (masterdataRes) {
            _.forEach(res.rows, (r) => {
                let foundPostcode = _.find(masterdataRes.postcode, (o) => { return o.id === r.dataValues.postcodeId; });
                r.dataValues['postcode'] = foundPostcode ? foundPostcode : null;
                let foundCity = _.find(masterdataRes.city, (o) => { return o.id === r.dataValues.cityId; });
                r.dataValues['city'] = foundCity ? foundCity : null;
                let foundState = _.find(masterdataRes.state, (o) => { return o.id === r.dataValues.stateId; });
                r.dataValues['state'] = foundState ? foundState : null;
                let foundCountry = _.find(masterdataRes.country, (o) => { return o.id === r.dataValues.countryId; });
                r.dataValues['country'] = foundCountry ? foundCountry : null;
                
                let telCodeObj = _.find(masterdataRes.areaOperatorCode, (o) => { return _.isEqual(o.id, r.telCode); });
                let faxCodeObj = _.find(masterdataRes.areaOperatorCode, (o) => { return _.isEqual(o.id, r.faxCode); });
                let mobileCodeObj = _.find(masterdataRes.areaOperatorCode, (o) => { return _.isEqual(o.id, r.mobileCode); });
                r.dataValues['telephone_display'] = r.telephone ? `(${telCodeObj.code})${r.telephone}` : r.telephone;
                r.dataValues['fax_display'] = r.fax ? `(${faxCodeObj.code})${r.fax}` : r.fax;
                r.dataValues['mobile_display'] = r.mobile ? `(${mobileCodeObj.code})${r.mobile}` : r.mobile;
                
            });
        }

        return res;
    }

    static async addMany(dataObj, who) {
        return CustomerCorrespondenceModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(dataObj, (addObj) => {
                addObj['createdBy'] = who;
                addObj['updatedBy'] = who;
                const p = CustomerCorrespondenceModel.addRecord(addObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }

    static async add(data, who) {
        const record = {
            ...data,
            updatedBy: who,
            createdBy: who
        }

        return CustomerCorrespondenceAddress.addRecord(record);
    }

    static async update(id, record, who) {
        const where = {
            id
        }
        record['updatedBy'] = who;
        record['id'] = id;

        return CustomerCorrespondenceAddress.updateRecord(record, where).then((results) => {
            console.log(results);
            return CustomerCorrespondenceAddress.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return CustomerCorrespondenceAddress.deleteRecord(where).then((results) => {
                return CustomerCorrespondenceAddress.getOne(where);
            });
        } else if (option === 'soft') {
            const record = {
                deleted: true,
                updatedBy: who
            }

            return CustomerCorrespondenceAddress.updateRecord(record, where).then((results) => {
                return CustomerCorrespondenceAddress.getOne(where);
            });
        } else if (option === 'restore') {
            const record = {
                deleted: false,
                updatedBy: who
            }

            return CustomerCorrespondenceAddress.updateRecord(record, where).then((results) => {
                return CustomerCorrespondenceAddress.getOne(where);
            });
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

}


module.exports = Functions;