const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
/**
 * Search for CustomerCorrespondenceAddress listing
 * 
 * @route POST /customerCorrespondenceAddress/search
 * @operationId CustomerCorrespondenceAddressSearch
 * @group Excise Type API
 * @param {CustomerCorrespondenceAddressSearch.model} CustomerCorrespondenceAddressSearch.body - Search. Show all if not provided.
 * @returns {CustomerCorrespondenceAddressSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        search.forEach((searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        })
    }
    errorDef.parameterHandler([order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond).then((resp) => {

        return res.status(200).send({
            ...resp,
            order,
            page,
            limit,
            search,
            filter
        });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add Excise Type
 * 
 * @route POST /customerCorrespondenceAddress/add
 * @operationId CustomerCorrespondenceAddressAdd
 * @group Excise Type API
 * @param {AddCustomerCorrespondenceAddress.model} AddCustomerCorrespondenceAddress.body.required - required AddCustomerCorrespondenceAddress
 * @returns {Array.<CustomerCorrespondenceAddressData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.put('/add', async function (req, res, next) {
    const datas = req.body.datas;
    errorDef.parameterHandler([datas]);
    // _.forEach(datas, (datasObj) => {
    //     errorDef.parameterHandler([datasObj.code, datasObj.name]);
    // });
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addMany(datas, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Update Excise Type
 * 
 * @route POST /customerCorrespondenceAddress/update
 * @operationId CustomerCorrespondenceAddressUpdate
 * @group Excise Type API
 * @param {UpdateCustomerCorrespondenceAddress.model} UpdateCustomerCorrespondenceAddress.body.required - required UpdateCustomerCorrespondenceAddress
 * @returns {CustomerCorrespondenceAddressData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.put('/update', async function (req, res, next) {
    const id = req.body.id;
    const data = req.body.data;

    errorDef.parameterHandler([id, data]);

    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){

        return functions.update(id, data, userInfo.id).then((record) => {
            console.log(record);
            if (!record) {
                throw errorDef.RECORD_NOT_FOUND
            }
            return res.status(200).send(record);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete Excise Type
 * 
 * @route DELETE /customerCorrespondenceAddress/delete
 * @operationId CustomerCorrespondenceAddressDelete
 * @group Excise Type API
 * @param {DeleteCustomerCorrespondenceAddress.model} DeleteCustomerCorrespondenceAddress.body.required - required DeleteCustomerCorrespondenceAddress
 * @returns {CustomerCorrespondenceAddressData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', async function (req, res, next) {
    const ids = req.body.ids;
    const option = req.body.option;

    errorDef.parameterHandler([ids]);
    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.deleteMany(ids, option, userInfo.id).then((response) => {
            return res.status(200).send(response);
        }).catch((reason) => {
            next(reason);
        });
    }
});

module.exports = router;