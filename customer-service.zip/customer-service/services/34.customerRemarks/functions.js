const CustomerRemarks = require('@driveit/driveit-databases/databases/customerMaster').CustomerRemarks;
var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');
const CustomerRemarksModel = require('@driveit/driveit-databases/databases/customerMaster/models/34.customerRemarks');

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        const orderBy = [order.columnName, order.direction];
        

        return await CustomerRemarks.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
    }

    static async addMany(dataObj, who) {
        return CustomerRemarksModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(dataObj, (addObj) => {
                addObj['createdBy'] = who;
                addObj['updatedBy'] = who;
                const p = CustomerRemarksModel.addRecord(addObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }

    static async add(data, who) {
        const record = {
            ...data,
            updatedBy: who,
            createdBy: who
        }

        return CustomerRemarks.addRecord(record);
    }

    static async update(id, record, who) {
        const where = {
            id
        }
        record['updatedBy'] = who;
        record['id'] = id;

        return CustomerRemarks.updateRecord(record, where).then((results) => {
            console.log(results);
            return CustomerRemarks.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return CustomerRemarks.deleteRecord(where).then((results) => {
                return CustomerRemarks.getOne(where);
            });
        } else if (option === 'soft') {
            const record = {
                deleted: true,
                updatedBy: who
            }

            return CustomerRemarks.updateRecord(record, where).then((results) => {
                return CustomerRemarks.getOne(where);
            });
        } else if (option === 'restore') {
            const record = {
                deleted: false,
                updatedBy: who
            }

            return CustomerRemarks.updateRecord(record, where).then((results) => {
                return CustomerRemarks.getOne(where);
            });
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

    static async groupUpdateCustomerRemark(deletedRemarks, customerRemarks, who) {
        return CustomerRemarksModel.sequelize.transaction((t) => {
            var promises = [];
            
            _.forEach(customerRemarks, (obj) => {
                obj['updatedBy'] = who;
                let p;
                if (obj.id !== undefined && obj.id !== null) {     // update
                    p = CustomerRemarksModel.updateRecord(_.omit(obj, 'id'), {id: obj.id}, t);
                } else {    // add
                    delete obj.id;
                    obj['createdBy'] = who;
                    p = CustomerRemarksModel.addRecord(obj, t);
                }
                promises.push(p);
            });

            //delete
            _.forEach(deletedRemarks, (id) => {
                let p2 = CustomerRemarksModel.deleteRecord({id}, t);
                promises.push(p2);
            });

            return Promise.all(promises);
        });
    }

}


module.exports = Functions;