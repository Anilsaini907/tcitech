const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
/**
 * Search for CustomerRemarks listing
 * 
 * @route POST /customerRemarks/search
 * @operationId CustomerRemarksSearch
 * @group Excise Type API
 * @param {CustomerRemarksSearch.model} CustomerRemarksSearch.body - Search. Show all if not provided.
 * @returns {CustomerRemarksSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        search.forEach((searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        })
    }
    errorDef.parameterHandler([order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond).then((resp) => {

        return res.status(200).send({
            ...resp,
            order,
            page,
            limit,
            search,
            filter
        });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add Excise Type
 * 
 * @route POST /customerRemarks/add
 * @operationId CustomerRemarksAdd
 * @group Excise Type API
 * @param {AddCustomerRemarks.model} AddCustomerRemarks.body.required - required AddCustomerRemarks
 * @returns {Array.<CustomerRemarksData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.put('/add', async function (req, res, next) {
    const datas = req.body.datas;
    errorDef.parameterHandler([datas]);
    if (datas && _.isEmpty(datas)) {
        return res.status(200).send({msg: 'datas is empty'});
    }
    // _.forEach(datas, (datasObj) => {
    //     errorDef.parameterHandler([datasObj.code, datasObj.name]);
    // });
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addMany(datas, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Update Excise Type
 * 
 * @route POST /customerRemarks/update
 * @operationId CustomerRemarksUpdate
 * @group Excise Type API
 * @param {UpdateCustomerRemarks.model} UpdateCustomerRemarks.body.required - required UpdateCustomerRemarks
 * @returns {CustomerRemarksData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.put('/update', async function (req, res, next) {
    const id = req.body.id;
    const data = req.body.data;

    errorDef.parameterHandler([id, data]);

    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){

        return functions.update(id, data, userInfo.id).then((record) => {
            console.log(record);
            if (!record) {
                throw errorDef.RECORD_NOT_FOUND
            }
            return res.status(200).send(record);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete Excise Type
 * 
 * @route DELETE /customerRemarks/delete
 * @operationId CustomerRemarksDelete
 * @group Excise Type API
 * @param {DeleteCustomerRemarks.model} DeleteCustomerRemarks.body.required - required DeleteCustomerRemarks
 * @returns {CustomerRemarksData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', async function (req, res, next) {
    const ids = req.body.ids;
    const option = req.body.option;

    errorDef.parameterHandler([ids]);
    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.deleteMany(ids, option, userInfo.id).then((response) => {
            return res.status(200).send(response);
        }).catch((reason) => {
            next(reason);
        });
    }
});

router.post('/groupUpdate', async function (req, res, next) {
    const customerRemarks = req.body.customerRemarks;
    const deletedRemarks = req.body.deletedRemarks;
    
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        // let where = { id: customerContactId };
        return functions.groupUpdateCustomerRemark(deletedRemarks, customerRemarks, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND;
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

module.exports = router;