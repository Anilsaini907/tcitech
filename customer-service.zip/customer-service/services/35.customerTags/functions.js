const CustomerTags = require('@driveit/driveit-databases/databases/customerMaster').CustomerTags;
var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');
const CustomerTagsModel = require('@driveit/driveit-databases/databases/customerMaster/models/35.customerTags');
const appointmentCache = require('../cache-request/appointment-api');

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        const orderBy = [order.columnName, order.direction];
        
        const res = await CustomerTags.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);

        let searchMasterDatas = [];
        const customerTagIds = res.rows.map((row) => row.customerTagId);
        if(customerTagIds && customerTagIds.length > 0) {
            searchMasterDatas.push({
                cacheKey: 'customerTag',
                filter: [{ colId: "id", text: customerTagIds }],
                attributes: ['id', 'code', 'name', 'updatedAt']
            });
        }
        
        const masterdataRes = await appointmentCache.getCacheByQuery(searchMasterDatas);
        
        _.forEach(res.rows, (r) => {
            let foundObj = masterdataRes && masterdataRes.customerTag && masterdataRes.customerTag.length > 0 ? masterdataRes.customerTag.find((o) => _.isEqual(o.id, r['customerTagId'])) : null;
            r.dataValues['customerTag'] = foundObj ? (foundObj.name ? foundObj.name: foundObj.code) : null;
        });
        

        return res;


    }

    static async addMany(dataObj, who) {
        return CustomerTagsModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(dataObj, (addObj) => {
                addObj['createdBy'] = who;
                addObj['updatedBy'] = who;
                const p = CustomerTagsModel.addRecord(addObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }

    static async add(data, who) {
        const record = {
            ...data,
            updatedBy: who,
            createdBy: who
        }

        return CustomerTags.addRecord(record);
    }

    static async update(id, record, who) {
        const where = {
            id
        }
        record['updatedBy'] = who;
        record['id'] = id;

        return CustomerTags.updateRecord(record, where).then((results) => {
            console.log(results);
            return CustomerTags.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return CustomerTags.deleteRecord(where).then((results) => {
                return CustomerTags.getOne(where);
            });
        } else if (option === 'soft') {
            const record = {
                deleted: true,
                updatedBy: who
            }

            return CustomerTags.updateRecord(record, where).then((results) => {
                return CustomerTags.getOne(where);
            });
        } else if (option === 'restore') {
            const record = {
                deleted: false,
                updatedBy: who
            }

            return CustomerTags.updateRecord(record, where).then((results) => {
                return CustomerTags.getOne(where);
            });
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

    static async groupUpdateCustomerTag(deletedTags, customerTags, who) {
        return CustomerTagsModel.sequelize.transaction((t) => {
            var promises = [];
            
            _.forEach(customerTags, (obj) => {
                obj['updatedBy'] = who;
                let p;
                if (obj.id !== undefined && obj.id !== null) {     // update
                    p = CustomerTagsModel.updateRecord(_.omit(obj, 'id'), {id: obj.id}, t);
                } else {    // add
                    delete obj.id;
                    obj['createdBy'] = who;
                    p = CustomerTagsModel.addRecord(obj, t);
                }
                promises.push(p);
            });

            //delete
            _.forEach(deletedTags, (id) => {
                let p2 = CustomerTagsModel.deleteRecord({id}, t);
                promises.push(p2);
            });

            return Promise.all(promises);
        });
    }
}


module.exports = Functions;