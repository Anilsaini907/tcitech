const Sequelize = require("sequelize");
const Op = Sequelize.Op;
var _ = require('lodash');
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');

const BranchBankAccounts = require('@driveit/driveit-databases/databases/customerMaster/models/37.branchBankAccounts')

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };
        const orderBy = [order.columnName, order.direction];
       

        return await BranchBankAccounts.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
    }

    static async addMany(dataObj, who) {
        return BranchBankAccounts.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(dataObj, (addObj) => {
                addObj['createdBy'] = who;
                addObj['updatedBy'] = who;
                const p = BranchBankAccounts.addRecord(addObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }

    static async add(data, who) {
        const record = {
            ...data,
            updatedBy: who,
            createdBy: who
        }

        return BranchBankAccounts.addRecord(record);
    }

    static async update(id, record, who) {
        const where = {
            id
        }
        record['updatedBy'] = who;
        record['id'] = id;

        return BranchBankAccounts.updateRecord(record, where).then((results) => {
            console.log(results);
            return BranchBankAccounts.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return BranchBankAccounts.deleteRecord(where).then((results) => {
                return BranchBankAccounts.getOne(where);
            });
        } else if (option === 'soft') {
            const record = {
                deleted: true,
                updatedBy: who
            }

            return BranchBankAccounts.updateRecord(record, where).then((results) => {
                return BranchBankAccounts.getOne(where);
            });
        } else if (option === 'restore') {
            const record = {
                deleted: false,
                updatedBy: who
            }

            return BranchBankAccounts.updateRecord(record, where).then((results) => {
                return BranchBankAccounts.getOne(where);
            });
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }
}


module.exports = Functions;