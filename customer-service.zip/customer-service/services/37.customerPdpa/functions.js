const CustomerPdpaModel = require('@driveit/driveit-databases/databases/customerMaster').CustomerPdpa;
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getCustomerPdpa(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;
        
        let custFinance = await CustomerPdpaModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond);
        return {
            ...custFinance,
            page: page.page,
            limit: page.limit
        };
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await CustomerPdpaModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addCustomerPdpa(data, who) {
        return CustomerPdpaModel.sequelize.transaction((t) => {
            data['createdBy'] = who;
            data['updatedBy'] = who;
            return CustomerPdpaModel.addNew(data, t);
        });
    }
    
    static async updateCustomerPdpa(data, where, who) {
        console.log('update CustomerPdpa')
        if(where.id) {
            data['updatedBy'] = who;
            data['id'] = where.id;
            return await CustomerPdpaModel.updateCustomerFinance(data, where).then(()=>{
                return CustomerPdpaModel.getId(where).then((resp)=>{
                    if(!resp) { 
                    throw errorDef.MASTERDATA_NOT_FOUND;
                    }
                    return resp;
                });
            });
        } else {
            delete data.id;
            return this.addCustomerPdpa(data, who)
        }
    }
    static async deleteCustomerPdpa(where, who, type = "soft") {
        if(type == "soft") {
            return await CustomerPdpaModel.deleteSoft(where, who).then(()=>{
                return CustomerPdpaModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await CustomerPdpaModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;