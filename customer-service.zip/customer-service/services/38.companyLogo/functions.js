const CompanyLogo = require('@driveit/driveit-databases/databases/customerMaster').CompanyLogo;
var _ = require('lodash');
const Sequelize = require("sequelize");
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');
const CompanyLogoModel = require('@driveit/driveit-databases/databases/customerMaster/models/39.companyLogo');

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        }
        const orderBy = [order.columnName, order.direction];

        
        const attr = null;
        return CompanyLogo.searchAll(searches, attr, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);

    }

    static async addMany(dataObj, who) {
        return CompanyLogoModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(dataObj, (addObj) => {
                addObj['createdBy'] = who;
                addObj['updatedBy'] = who;
                const p = CompanyLogoModel.addRecord(addObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }

    static async add(data, who) {
        const record = {
            ...data,
            updatedBy: who,
            createdBy: who
        }

        return CompanyLogo.addRecord(record);
    }

    static async update(id, record, who) {
        const where = {
            id
        }
        record['updatedBy'] = who;
        record['id'] = id;

        return CompanyLogo.updateRecord(record, where).then((results) => {
            console.log(results);
            return CompanyLogo.getOne({
                id
            });
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        }

        if (option === 'hard') {
            return CompanyLogo.deleteRecord(where).then((results) => {
                return CompanyLogo.getOne(where);
            });
        } else if (option === 'soft') {
            const record = {
                deleted: true,
                updatedBy: who
            }

            return CompanyLogo.updateRecord(record, where).then((results) => {
                return CompanyLogo.getOne(where);
            });
        } else if (option === 'restore') {
            const record = {
                deleted: false,
                updatedBy: who
            }

            return CompanyLogo.updateRecord(record, where).then((results) => {
                return CompanyLogo.getOne(where);
            });
        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

}


module.exports = Functions;