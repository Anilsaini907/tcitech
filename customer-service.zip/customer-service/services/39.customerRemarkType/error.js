module.exports = {
    Type: {
      Success: 'success',
      Info: 'info',
      Warning: 'warning',
      Error: 'error'
    },
  
    Message: {
      RecordExist: 'Customer Remark Type for this company already exist.',
      SuccessCreateCustomerRemark: 'Successfully create Customer Remark Type.',
      SuccessUpdateCustomerRemark: 'Successfully update Customer Remark Type.',
      SuccessDeleteCustomerRemark: 'Successfully delete Customer Remark Type.'
    }
  }