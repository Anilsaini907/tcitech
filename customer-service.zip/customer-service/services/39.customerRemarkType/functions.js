const Sequelize = require('sequelize');
const CompanyModel = require('@driveit/driveit-databases/databases/customerMaster/models/7.company');
const customerMasterDb = require('@driveit/driveit-databases/databases/customerMaster');
const errorModel = require('./error');
const Utils = require('../../utilities/utils');
const _ = require('lodash');
const Op = Sequelize.Op;

class Functions {
  static async getCustomerRemarkTypes(searches, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
    const pagination = {
      limit: page.limit,
      offset: page.limit * (page.page - 1),
    };
   
    const orderBy = page.order;

    return customerMasterDb.CustomerRemarkTypes.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
  }

  static async addCustomerRemarkTypes(payload, who) {
    const isExist = await customerMasterDb.CustomerRemarkTypes.findOne({
      where : {
        companyId: payload.companyId,
        customerRemarkTypeCode: payload.customerRemarkTypeCode,
        deleted: false
      }
    })

    if (isExist) {
      return {
        status: errorModel.Type.Error,
        message: errorModel.Message.RecordExist,
      }
    }

    const record = {
      ...payload,
      updatedBy: who,
      createdBy: who
    }

    const customerRemark = await customerMasterDb.CustomerRemarkTypes.create(record)

    return {
      status: errorModel.Type.Success,
      message: errorModel.Message.SuccessCreateCustomerRemark,
      data: {
        customerRemark
      }
    }
  }

  static async updateCustomerRemarkTypes(payload, who) {
    if (!payload.customerRemarkTypeCode) {
      const isExist = await customerMasterDb.CustomerRemarkTypes.findOne({
        where : {
          companyId: payload.companyId,
          customerRemarkTypeCode: payload.customerRemarkTypeCode,
          deleted: false
        }
      })
  
      if (isExist) {
        return {
          status: errorModel.Type.Error,
          message: errorModel.Message.RecordExist,
        }
      }

      delete payload.customerRemarkTypeCode
    }

    const record = {
      ...payload,
      updatedBy: who
    }

    delete record.id;
    return customerMasterDb.CustomerRemarkTypes.update(record, { where: { id: payload.id } }).then(() => {
      return {
        status: errorModel.Type.Success,
        message: errorModel.Message.SuccessUpdateCustomerRemark,
      }
    })
  }

  static async deleteCustomerRemarkTypes(id, who) {
    const record = {
      deleted: true,
      updatedBy: who
    }

    return customerMasterDb.CustomerRemarkTypes.update(record, { where: {id} }).then(() => {
      return {
        status: errorModel.Type.Success,
        message: errorModel.Message.SuccessDeleteCustomerRemark,
      }
    })
  }


  static handleOrder(order, includeArray) {
    if (order && order[0] && order[0].indexOf('+') !== -1) {
      let arrayField = [];
      let newOrder = [];

      arrayField.push(order[0].substring(0, order[0].indexOf('+')));
      arrayField.push(order[0].substring(order[0].indexOf('+')+1));
      arrayField.forEach(field => {
        const modelName = field.substring(0, field.indexOf('.'));
        const fieldName = field.substring(field.indexOf('.') + 1);
        const findModel = includeArray.find(item => item.modelName === modelName);

        newOrder.push([{ model: findModel.model, as: modelName }, fieldName, order[1]]);
      });

      return newOrder;
    }

    if (order && order[0] && order[0].indexOf('.') !== -1) {
      const modelName = order[0].substring(0, order[0].indexOf('.'));
      const fieldName = order[0].substring(order[0].indexOf('.') + 1);
      const findOrder = includeArray.find(item => item.modelName === modelName);
      if (findOrder) {
        order[0] = fieldName;
        order.unshift({ model: findOrder.model, as: modelName });
      }
    }

    return order;
  }
}

module.exports = Functions;