const express = require('express');
const router = express.Router();
const functions = require('./functions');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };
    return functions.getCustomerRemarkTypes(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({ ...resp, order, search, filter });
    }).catch((reason) => {
        next(reason);
    });
});

router.post('/create',async function (req, res, next) {
    const data = req.body.data;

    errorDef.parameterHandler([data]);
    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });

    if (userInfo) {
        return functions.addCustomerRemarkTypes(data, userInfo.id)
            .then((result) => {
                return res.status(200).send(result);
            })
            .catch((reason) => {
                next(reason);
            });
    }
})

router.post('/update',async function (req, res, next) {
    const data = req.body.data;

    errorDef.parameterHandler([data]);
    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });

    if (userInfo) {
        return functions.updateCustomerRemarkTypes(data, userInfo.id)
            .then((result) => {
                return res.status(200).send(result);
            })
            .catch((reason) => {
                next(reason);
            });
    }
})

router.post('/delete',async function (req, res, next) {
    const id = req.body.customerRemarkTypeId;

    errorDef.parameterHandler([id]);
    const userInfo = await errorDef.userInfoHandler(req).catch(err=>{
        console.error(err);
        next(err);
    });

    if (userInfo) {
        return functions.deleteCustomerRemarkTypes(id, userInfo.id)
            .then((result) => {
                return res.status(200).send(result);
            })
            .catch((reason) => {
                next(reason);
            });
    }
})

module.exports = router;