const LeadsModel = require('@driveit/driveit-databases/databases/customerMaster/models/4.leads');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getLeads(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };
        
        let attr = null;
        return {
            ...await LeadsModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        }
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await LeadsModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addLeads(leadsObj, who) {
        return LeadsModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(leadsObj, (addLeadsObj) => {
                addLeadsObj['createdBy'] = who;
                addLeadsObj['updatedBy'] = who;
                const p = LeadsModel.addNew(addLeadsObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    static async updateLeads(leads, where, who) {
        leads['updatedBy'] = who;
        leads['id'] = where.id;
        return await LeadsModel.updateLeads(leads, where).then(()=>{
            return LeadsModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteLeads(where, who, type = "soft") {
        if(type == "soft") {
            return await LeadsModel.deleteSoft(where, who).then(()=>{
                return LeadsModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await LeadsModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;