const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');
/**
 * Search Leads Masterdata service
 * 
 * @route POST /leads/search
 * @operationId searchLeads
 * @group Leads API
 * @param {LeadsSearch.model} LeadsSearch.body - Search. Show all if not provided.
 * @returns {LeadsSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
        return functions.getLeads(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }

            return res.status(200).send({...resp, order, search, filter});
        }).catch((reason) => {
            next(reason);
        });
});
/**
 * Add Leads Masterdata service
 * 
 * @route POST /leads/add
 * @operationId addLeads
 * @group Leads API
 * @param {AddLeads.model} AddLeads.body.required - required Leads
 * @returns {Array.<LeadsData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customValidator.validateCreateLeads], async function (req, res, next) {
    const leads = req.body.leads;
    errorDef.parameterHandler([leads]);
    _.forEach(leads, (leadsObj) => {
        errorDef.parameterHandler([leadsObj.code, leadsObj.name]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addLeads(leads, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update Leads Masterdata service
 * 
 * @route POST /leads/update
 * @operationId updateLeads
 * @group Leads API
 * @param {UpdateLeads.model} UpdateLeads.body.required - required Leads
 * @returns {LeadsData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customValidator.validateUpdateLeads], async function (req, res, next) {
    const leadsId = req.body.id;
    const leads = req.body.leads;
    errorDef.parameterHandler([leadsId]);
    errorDef.parameterHandler([leads]);
    // errorDef.parameterHandler([leads.code, leads.name]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: leadsId };
        return functions.updateLeads(leads, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete Leads Masterdata service
 * 
 * @route DELETE /leads/delete
 * @operationId deleteLeads
 * @group Leads API
 * @param {DeleteLeads.model} DeleteLeads.body.required - required Leads
 * @returns {Array.<LeadsData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteLeads], async function (req, res, next) {
    const leadsId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([leadsId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: leadsId };
        return functions.deleteLeads(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export Leads Masterdata service
 * 
 * @route POST /leads/export
 * @operationId exportLeads
 * @group Leads API
 * @param {LeadsSearch.model} LeadsSearch.body - Search. Show all if not provided.
 * @returns {LeadsSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    
    return functions.getLeads(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows:resp.rows,
            filename:'leads'
        };

        return ExportAPI.exportData(null, data).then(response =>{
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });
        
    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;