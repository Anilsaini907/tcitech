const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateLeads: (req, res, next) => {
        req.checkBody('leads', 'Lead Status object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('leads.*.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('leads.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('leads.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateLeads: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('leads', 'Lead Status object parameter is missing').trim().notEmpty();
        req.checkBody('leads.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('leads.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('leads.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteLeads: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}