const ContactRelationship = require('@driveit/driveit-databases/databases/customerMaster/models/5.contactRelationship');

var _ = require('lodash');
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const errorDef = require("../services.config/errorDef")
const Utils = require('../../utilities/utils');

class Functions {

    static async search(page, limit, order, searches, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit,
            offset: limit ? limit * (page - 1) : undefined,
        };

        const orderBy = [order.columnName, order.direction];
        
        return await ContactRelationship.searchAll(searches, null, pagination, orderBy, filter, false, showAll, false, [], null, distKeys, searchOrCond);
    }
    
    static async addMany(contactRelationships, who) {
        let promises = [];

        for(let t=0; t<contactRelationships.length; t++){
            let contactRelationship = contactRelationships[t];
            if(contactRelationships.length == 1){ //for singles
                return Functions.add(contactRelationship.code, contactRelationship.name, contactRelationship.status, who);
            }

            //else multiple
            promises.push(Functions.add(contactRelationship.code, contactRelationship.name, contactRelationship.status, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        }
     

        return Promise.all(promises);
    }

    static async add(code, name, status, who) {
        const contactRelationship = {
            code,
            name,
            status,
            updatedBy: who,
            createdBy: who
        }

        return ContactRelationship.addRecord(contactRelationship).then((record) => {
            return record;
        });
    }

    static async update(id, contactRelationship, who) {
        const where = {
            id
        }
        contactRelationship['updatedBy'] = who;
        contactRelationship['id']= id;

        return ContactRelationship.updateRecord(contactRelationship, where).then((record) => {
            return ContactRelationship.getOne({id});
        });
    }

    static async deleteMany(ids, option, who) {
        var promises = [];

        ids.forEach((id) => {
            promises.push(Functions.delete(id, option, who).catch((error) => {
                return errorDef.compileError(error);
            }));
        });

        return Promise.all(promises);
    }

    static async delete(id, option, who) {
        const where = {
            id
        };

        if (option === 'hard') {
            return ContactRelationship.deleteHard(where).then((record) => {
                return ContactRelationship.getOne(where);
            });
        } else if (option === 'soft') {
            
            return ContactRelationship.deleteSoft(where, who).then(() => {
                return ContactRelationship.getOne(where);
            });

        } else {
            throw errorDef.INVALID_OPTION;
        }

    }

}


module.exports = Functions;