const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
const customValidator = require('./validation');

/**
 * Search for ContactRelationship listing
 * 
 * @route POST /contactRelationship/search
 * @operationId contactRelationshipSearch
 * @group Contact Relationship API
 * @param {ContactRelationshipSearch.model} ContactRelationshipSearch.body - Search. Show all if not provided.
 * @returns {ContactRelationshipSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/search', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if (search) {
        search.forEach((searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]); 
        })
    }
    errorDef.parameterHandler([order]);
    errorDef.parameterHandler([order.columnName, order.direction]);

    return functions.search(page, limit, order, search, filter, showAll, distKeys, searchOrCond).then((resp) => {

        return res.status(200).send({
            ...resp,
            order,
            page,
            limit,
            search,
            filter
        });
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add ContactRelationship
 * 
 * @route PUT /contactRelationship/add
 * @operationId contactRelationshipAdd
 * @group Contact Relationship API
 * @param {AddContactRelationship.model} AddContactRelationship.body.required - required AddContactRelationship
 * @returns {Array.<ContactRelationshipData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.put('/add', [customValidator.validateCreateContactRelationship],  async function (req, res, next) {
    const contactRelationships = req.body.contactRelationship;

    errorDef.parameterHandler([contactRelationships]);
    contactRelationships.forEach((contactRelationship) => {
        errorDef.parameterHandler([contactRelationship.code, contactRelationship.name, contactRelationship.status]);
    })
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addMany(contactRelationships, userInfo.id).then((result) => {
                return res.status(200).send(result);
            })
            .catch((reason) => {
                next(reason);
            });
    }
});

/**
 * Update ContactRelationship
 * 
 * @route PUT /contactRelationship/update
 * @operationId contactRelationshipUpdate
 * @group Contact Relationship API
 * @param {UpdateContactRelationship.model} UpdateContactRelationship.body.required - required UpdateContactRelationship
 * @returns {ContactRelationshipData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.put('/update', [customValidator.validateUpdateContactRelationship], async function (req, res, next) {
    const id = req.body.id;
    const contactRelationship = req.body.contactRelationship;
    
    errorDef.parameterHandler([id, contactRelationship]);

    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.update(id, contactRelationship, userInfo.id).then((record) => {
            if (!record) {
                throw errorDef.RECORD_NOT_FOUND
            }
            return res.status(200).send(record);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete ContactRelationship
 * 
 * @route DELETE /contactRelationship/delete
 * @operationId contactRelationshipDelete
 * @group Contact Relationship API
 * @param {DeleteContactRelationship.model} DeleteContactRelationship.body.required - required DeleteContactRelationship
 * @returns {ContactRelationshipData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteContactRelationship], async function (req, res, next) {
    const ids = req.body.ids;
    const option = req.body.option;

    errorDef.parameterHandler([ids]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.deleteMany(ids, option, userInfo.id).then((response) => {
            return res.status(200).send(response);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export for ContactRelationship listing
 * 
 * @route POST /contactRelationship/export
 * @operationId contactRelationshipExport
 * @group Contact Relationship API
 * @param {ContactRelationshipSearch.model} ContactRelationshipSearch.body - Search. Show all if not provided.
 * @returns {ContactRelationshipSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request 
 * @security firebase
 */
router.post('/export', function (req, res, next) {
    const page = req.body.page;
    const limit = req.body.limit;
    const order = req.body.order;
    const search = req.body.search;
    const filter = req.body.filter;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    
    return functions.search(page, limit, order, search, filter).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows:resp.rows,
            filename:'contact_relationship'
        };

        return ExportAPI.exportData(null, data).then(response =>{
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });
        
    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;