const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateContactRelationship: (req, res, next) => {
        req.checkBody('contactRelationship', 'Contact Relationship object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('contactRelationship.*.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('contactRelationship.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('contactRelationship.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateContactRelationship: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('contactRelationship', 'Contact Relationship object parameter is missing').trim().notEmpty();
        req.checkBody('contactRelationship.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('contactRelationship.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('contactRelationship.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteContactRelationship: (req, res, next) => {
        req.checkBody('ids', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}