const CustomerAccountGroupModel = require('@driveit/driveit-databases/databases/customerMaster/models/6.customerAccountGroup');
const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
var _ = require('lodash');

class Functions {

    static async getCustomerAccountGroup(search, filterArr, page, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };

        if (search) {
            let excludedSearch = _.remove(search, (o) => { return o.colId === 'countryName' || o.colId === 'countryCode'; });
            let searched = await this.prepQry(excludedSearch);
            search = _.concat(search, searched);
        }

        let attr = null;

        let customerAccountGroupRes = await CustomerAccountGroupModel.searchAll(search, attr, pagination, page.order, filterArr, false, showAll, false, [], null, distKeys, searchOrCond);
        
        let resp = await CountryModel.searchAll([], ['id', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], [], true, true, true);
        let countries = resp && !_.isEmpty(resp) ? _.map(resp, 'dataValues') : [];
        
        _.forEach(customerAccountGroupRes.rows, (row) => {
            let found = _.find(countries, (o) => { return _.isEqual(o.id, row.countryId); });
            if (found) {
                row.dataValues['countryName'] = found.name ? found.name : '';
            }
        });

        return {
            ...customerAccountGroupRes,
            page: page.page,
            limit: page.limit
        };  
    }

    static async prepQry(search) {
        let likeArr = [];
        let searchMasterDatas = [];
        for(let u = 0; u < _.size(search); u++) {
            if (search[u].colId === 'countryName') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "name", text: search[u].text }],
                        skipInclude: true
                    });
                } else {
                    let found = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found) {
                        found.search.push({ colId: "name", text: search[u].text });
                    }
                }
            } else if (search[u].colId === 'countryCode') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "code", text: search[u].text }],
                        skipInclude: true
                    });
                } else {
                    let found1 = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found1) {
                        found1.search.push({ colId: "code", text: search[u].text });
                    }
                }
            }
        }
        

        let queryResult = await generalCache.getMasterDataByQuery(searchMasterDatas);
        if (queryResult) {
            if (queryResult.country) {
                let countryIds = [];
                queryResult.country.forEach((country) => {
                    countryIds.push(country.id);
                });
                likeArr.push({ colId: 'countryId', text: !_.isEmpty(countryIds) ? countryIds : ['00000000-0000-0000-0000-000000000000'] });
            }
        }
        return likeArr;
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let ids = [];
        let attr = null;
        
        //temp fix for PBI 663. Task 729. to display country Name
        return CustomerAccountGroupModel.getAllByIds(ids, attr, pagination, page.order).then((customerAccountGroupRes) => {
            let masterdataTypes = ["country"];
            let token = page.token? page.token : null;
            return generalCache.processMasterdataResult(customerAccountGroupRes.rows, masterdataTypes, token).then((mdResults) => {
                _.forEach(customerAccountGroupRes.rows, (row) => {
                    let mObj = {};
                    _.forEach(mdResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if(c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });
                        
                        if(mObj[key] && mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    });
                });
                return {
                    ...customerAccountGroupRes,
                    page: page.page,
                    limit: page.limit
                };
            });
        });

        // return {
        //     ...await CustomerAccountGroupModel.getAllByIds(ids, attr, pagination, page.order),
        //     page: page.page,
        //     limit: page.limit
        // };
    }

    static async addCustomerAccountGroup(customerAccountGroups, who) {
        return CustomerAccountGroupModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(customerAccountGroups, (customerAccountGroupObj) => {
                customerAccountGroupObj['updatedBy'] = who;
                customerAccountGroupObj['createdBy'] = who;

                const p = 
                CustomerAccountGroupModel.getId({code: customerAccountGroupObj.code}).then((resp)=>{
                    if(!resp) {
                        return CustomerAccountGroupModel.addNew(customerAccountGroupObj, t);
                    } else {
                        throw errorDef.NOT_UNIQUE;
                    }
                });
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }

    static async updateCustomerAccountGroup(customerAccountGroup, where, who) {
        customerAccountGroup['updatedBy'] = who;

        let resp = await CustomerAccountGroupModel.searchAll([], null, {}, ['updatedAt', 'desc'], [], true, false, true);

        
        let recordArr = resp ? _.map(resp, 'dataValues') : [];
        _.remove(recordArr, (o) => { return _.isEqual(o.id, where.id); });
        let found = _.find(recordArr, (o) => { return _.isEqual(o.code, customerAccountGroup.code); });
        if (found) {
            throw errorDef.NOT_UNIQUE;
        } else {
            await CustomerAccountGroupModel.updateCustomerAccountGroup(customerAccountGroup, where);
            let resp2 = await CustomerAccountGroupModel.getId(where)
            if(!resp2) {
                throw errorDef.MASTERDATA_CUSTOMER_ACCOUNT_GROUP_NOT_FOUND;
            }
            return resp2;
        }
    }

    static async deleteCustomerAccountGroup(ids, deleteOption, who) {
        if(deleteOption == "soft") {
            let obj = {};
            obj['updatedBy'] = who;
            return await CustomerAccountGroupModel.deleteSoft(ids, obj).then(()=>{
                return CustomerAccountGroupModel.getAllByIds(ids, null).then((resp)=>{
                    // if(!resp) {
                    // throw errorDef.MASTERDATA_NOT_FOUND;
                    // }
                    return resp;
                });
            });
        } else if (deleteOption == "hard") {
            return await CustomerAccountGroupModel.deleteHard(ids).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return {id: ids};
                }
            });
        }
    }

}

module.exports = Functions;