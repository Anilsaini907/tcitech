const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');

/**
 * Search Customer account group Masterdata service
 * 
 * @route POST /customerAccountGroup/search
 * @operationId searchCustomerAccountGroup
 * @group Customer Account Group API
 * @param {CustomerAccountGroupSearch.model} CustomerAccountGroupSearch.body - Search. Show all if not provided.
 * @returns {CustomerAccountGroupSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction],
    }
        return functions.getCustomerAccountGroup(search, filter, pageObj, showAll, distKeys, searchOrCond).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }

            return res.status(200).send({...resp, order, search});
        }).catch((reason) => {
            next(reason);
        });
});

/**
 * Add Customer account group Masterdata service
 * 
 * @route POST /customerAccountGroup/add
 * @operationId addCustomerAccountGroup
 * @group Customer Account Group API
 * @param {AddCustomerAccountGroup.model} AddCustomerAccountGroup.body.required - required CustomerAccountGroup
 * @returns {Array.<CustomerAccountGroupData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customValidator.validateCreateCustomerAccountGroup], async function (req, res, next) {
    const customerAccountGroup = req.body.customerAccountGroup;

    errorDef.parameterHandler([customerAccountGroup]);
    
    _.forEach(customerAccountGroup, (customerAccountGroupObj) => {
        errorDef.parameterHandler([customerAccountGroupObj.code, customerAccountGroupObj.name,customerAccountGroupObj.topicCode, customerAccountGroupObj.status]);
    });

    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addCustomerAccountGroup(customerAccountGroup, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Update Customer account group Masterdata service
 * 
 * @route POST /customerAccountGroup/update
 * @operationId updateCustomerAccountGroup
 * @group Customer Account Group API
 * @param {UpdateCustomerAccountGroup.model} UpdateCustomerAccountGroup.body.required - required CustomerAccountGroup
 * @returns {CustomerAccountGroupData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customValidator.validateUpdateCustomerAccountGroup], async function (req, res, next) {
    const customerAccountGroupId = req.body.id;
    const customerAccountGroup = req.body.customerAccountGroup;
    errorDef.parameterHandler([customerAccountGroupId]);
    errorDef.parameterHandler([customerAccountGroup]);

    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: customerAccountGroupId };
        return functions.updateCustomerAccountGroup(customerAccountGroup, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete Customer account group Masterdata service
 * 
 * @route DELETE /customerAccountGroup/delete
 * @operationId deleteCustomerAccountGroup
 * @group Customer Account Group API
 * @param {DeleteCustomerAccountGroup.model} DeleteCustomerAccountGroup.body.required - required CustomerAccountGroup
 * @returns {Array.<CustomerAccountGroupData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteCustomerAccountGroup], async function (req, res, next) {
    const customerAccountGroupIds = req.body.ids;
    const deleteOption = req.body.option;

    errorDef.parameterHandler(customerAccountGroupIds);
    errorDef.parameterHandler([deleteOption]);

    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.deleteCustomerAccountGroup(customerAccountGroupIds, deleteOption, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export Customer account group Masterdata service
 * 
 * @route POST /customerAccountGroup/export
 * @operationId exportCustomerAccountGroup
 * @group Customer Account Group API
 * @param {CustomerAccountGroupSearch.model} CustomerAccountGroupSearch.body - Search. Show all if not provided.
 * @returns {CustomerAccountGroupSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    
    return functions.getCustomerAccountGroup(search, pageObj).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows:resp.rows,
            filename:'contact_account_group'
        };

        return ExportAPI.exportData(null, data).then(response =>{
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });
        
    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;