const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateCustomerAccountGroup: (req, res, next) => {
        req.checkBody('customerAccountGroup', 'Customer Account Group object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('customerAccountGroup.*.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerAccountGroup.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerAccountGroup.*.topicCode', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerAccountGroup.*.countryId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerAccountGroup.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateCustomerAccountGroup: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerAccountGroup', 'Customer Account Group object parameter is missing').trim().notEmpty();
        req.checkBody('customerAccountGroup.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerAccountGroup.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerAccountGroup.topicCode', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerAccountGroup.countryId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('customerAccountGroup.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteCustomerAccountGroup: (req, res, next) => {
        req.checkBody('ids', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}