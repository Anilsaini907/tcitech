const CompanyModel = require('@driveit/driveit-databases/databases/customerMaster/models/7.company');
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
const customerCache = require('../cache-request/customer-api');
var _ = require('lodash');
const Sequelize = require("sequelize");
const Utils = require('../../utilities/utils');
const Op = Sequelize.Op;
const CalenderIndicatorFunctions = require('../32.calendarIndicator/functions');
const defaultData = require('../32.calendarIndicator/validation');
const CompanyMasterModel = require('@driveit/driveit-databases/databases/customerMaster');
let num = 0;
class Functions {

    static async getCompany(search, page, filter, basicSearch = false, showAll = false, distKeys = null, searchOrCond = false) {
        //temp fix for sorking Parent Company
        let array = [
            'parentCompanyId', 'asc'
        ]
        let array2 = [
            'parentCompanyId', 'desc'
        ]
        if (page.order[0] === 'parentCompany.name' && num ==  0) {
            num++;
            page.order = array;
        }
        if (page.order[0] === 'parentCompany.name' && num ==  1) {
            num--;
            page.order = array2;
        }
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        };

        if (search) {
            let excludedSearch = _.remove(search, (o) => {
                return o.colId === 'parentCompany.name';
            });
            let searched = await this.prepQry(excludedSearch);
            search = _.concat(search, searched);
        }
        

        let companyRes = basicSearch ? 
            await CompanyModel.searchAll(search, ['id', 'name', 'code', 'parentCompanyId', 'dealerGroupId', 'makeIds', 'countryId', 'branchIds', 'status', 'updatedAt'], pagination, page.order, filter, false, showAll, true, [], null, distKeys, searchOrCond) :
            await CompanyModel.searchAll(search, null, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond);

        if (basicSearch) {
            return {
                rows: companyRes,
                page: page.page,
                limit: page.limit
            };
        }

        let parentCompanyIds = this.extractParentCompanyIds(companyRes);
        let filterCompany = [{ colId: 'id', text: !_.isEmpty(parentCompanyIds) ? parentCompanyIds : [null] }];
        let resp = await CompanyModel.searchAll([], ['id', 'code', 'name'], {}, ['updatedAt', 'desc'], filterCompany, true, false, true);

        let companyIds = [], resCompanyLogo;
        companyIds = companyRes.rows.map((c) => c.id);
        if(companyIds.length) {
            companyIds = _.uniq(companyIds);
            let filterLogo = [{ colId: 'companyId', text: companyIds }];
            resCompanyLogo = await CompanyMasterModel.CompanyLogo.searchAll([], null, {}, ['updatedAt', 'desc'], filterLogo, true, false, true);
        }
            
        
        _.forEach(companyRes.rows, (row) => {
            let found = _.find(resp, (o) => { return _.isEqual(o.id, row.dataValues['parentCompanyId']); });
            row.dataValues['parentCompany'] = found ? found : {};

            if (resCompanyLogo) {
                let companyLogos = resCompanyLogo.filter((c) => c.companyId === row.id);
                row.dataValues['companyLogos'] = companyLogos.length ? _.orderBy(companyLogos, ['isDefault','updatedAt'], ['desc','desc']) : null;
            }
        });
        
        return {
            ...companyRes,
            page: page.page,
            limit: page.limit
        };
    }

    static extractParentCompanyIds(res) {
        let ids = [];
        _.forEach(res.rows, (row) => {
            if (row.dataValues) {
                if (row.dataValues['parentCompanyId']) {
                    ids.push(row.dataValues['parentCompanyId']);
                }
            }
        });
        return _.uniq(_.without(ids, null, ''));
    }

    static async prepQry(search) {
        return new Promise(function (resolve, reject) {
            let likeArr = [];
            let likeArrParentCompany = [];
            var promises = [];
            _.forEach(search, (searchObj) => {
                _.forEach(searchObj.text, (likeArrItem) => {
                    if (searchObj.colId == 'parentCompany.name') {
                        likeArrParentCompany.push({ colId: "name", text: `%${likeArrItem}%` });
                    }
                });
            });
            if (likeArrParentCompany.length > 0) {
                let p = CompanyModel.searchAllNoCount(likeArrParentCompany, ["id"]).then((res) => {
                    return { company: res }
                });
                promises.push(p);
            }
            Promise.all(promises).then((val) => {
                _.forEach(val, (val2) => {
                    if (val2) {
                        likeArr.push({ colId: 'parentCompanyId', text: !_.isEmpty(val2.company) ? _.map(val2.company, 'id') : ['00000000-0000-0000-0000-000000000000'] });
                    }
                });
                resolve(likeArr);
            });
        });
    }


    static async getAll(page) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        }
        let ids = [];
        let attr = null;

        //temp fix for PBI 663. Task 729. to get language, timezone, postcode, country, city, state, currency Name
        return CompanyModel.searchAll(ids, attr, pagination, page.order).then((companyRes) => {
            let masterdataTypes = ["language", "timezone", "postcode", "country", "city", "state", "currency"];
            let token = page.token ? page.token : null;
            return generalCache.processMasterdataResult(companyRes.rows, masterdataTypes, token).then((mdResults) => {
                generalCache.processRowRecords(companyRes, mdResults);

                let cacheKey = [{
                    rowKey: "parentCompany",
                    cacheKey: "company"
                }];
                return customerCache.processMasterCustomerDataResult(companyRes.rows, cacheKey, token).then((mdCustomerResults) => {
                    customerCache.processRowRecords(companyRes.rows, mdCustomerResults);

                    return {
                        ...companyRes,
                        page: page.page,
                        limit: page.limit
                    };
                });
            });
        });

        // return {
        //     ...await CompanyModel.getAllByIds(ids, attr, pagination, page.order),
        //     page: page.page,
        //     limit: page.limit
        // };
    }

    static async getCompanyTree(search, page, filter, hqId = null) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        };

        let attr = ['id', 'name', 'parentCompanyId', 'updatedAt'];

        let companyRes = await CompanyModel.searchAll(search, attr, pagination, page.order, filter, true, false, true);
        let companies = companyRes && !_.isEmpty(companyRes) ? _.map(companyRes, 'dataValues') : []

        const newRes = _.map(companies, (v) => {
            return {
                id: v.id,
                name: v.name,
                parentId: v.parentCompanyId
            }
        });
        
        const arrtemp = this.treeify(newRes, hqId);

        return {
            rows: this.flat(arrtemp)
        };
    }

    /** flatten nested array. ref: https://stackoverflow.com/a/35273005 */
    static flat(array) {
        var result = [];
        let self = this;
        array.forEach(function (a) {
            result.push(a);
            if (Array.isArray(a.children)) {
                result = result.concat(self.flat(a.children));
            }
        });
        return result;
    }

    static treeify(list, hqId = null) {
        var treeList = [];
        var lookup = {};
        list.forEach((obj) => {
            lookup[obj.id] = obj;
            lookup[obj.id].children = [];
        });
        list.forEach((obj) => {
            if (obj.parentId != null && lookup[obj.parentId]) {
                lookup[obj.parentId].children.push(obj);
            } else {
                treeList.push(obj);
            }
        });
        if (hqId) {
            return _.filter(treeList, (rr) => {
                return rr.id == hqId;
            })
        }
        return treeList;
    }

    static async addCompany(companies, who) {
        return CompanyModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(companies, (companyObj) => {
                companyObj['updatedBy'] = who;
                companyObj['createdBy'] = who;

                const p =
                    CompanyModel.getId({
                        code: companyObj.code
                    }).then((resp) => {
                        if (!resp) {
                            return this.add(companyObj, t);
                        } else {
                            throw errorDef.NOT_UNIQUE;
                        }
                    });
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }

    static async add(companyData, transaction = null) {
        return CompanyModel.addNew(companyData, transaction).then(async (c) => {
            if (c && c.id) {
                const companyId = c.id;
                const companyLogoDatas = companyData.companyLogos && companyData.companyLogos.data ? companyData.companyLogos.data : null
                if (companyLogoDatas && companyLogoDatas.length) {
                    _.forEach(companyLogoDatas, (companyLogoData) => {
                        companyLogoData['companyId'] = companyId;
                    });
                    await CompanyMasterModel.CompanyLogo.bulkCreate(companyLogoDatas, {returning: true, transaction})
                }
            }
            return c;
        })
    }

    static async addDefaultCalenderIndicators(companyId) {
        let data = defaultData.getDefaultData(companyId);
        let result = await CalenderIndicatorFunctions.addMany(data, "DEVELOPMENT");
        return result;
    }   

    static async updateCompany(companyData, where, who, token) {
        companyData['updatedBy'] = who;
        // MasterdataTenantAPI.updateTenantByCompany({
        //     id: where.id,
        //     data: {
        //         "isExternalDealer": companyData.isExternalDealer
        //     }
        // }, token).then((response) => {

        // });
        let resp = await CompanyModel.searchAll([], null, {}, ['updatedAt', 'desc'], [], true, false, true);

        let recordArr = resp ? _.map(resp, 'dataValues') : [];
        _.remove(recordArr, (o) => {
            return _.isEqual(o.id, where.id);
        });
        let found = _.find(recordArr, (o) => {
            return _.isEqual(o.code, companyData.code);
        });
        if (found) {
            throw errorDef.NOT_UNIQUE;
        } else {
            await CompanyModel.updateCompany(companyData, where);
            let resp = await CompanyModel.getId(where);
            if (!resp) {
                throw errorDef.MASTERDATA_COMPANY_NOT_FOUND;
            }
            const companyId = where.id;
            const companyLogoDatas = companyData.companyLogos && companyData.companyLogos.data ? companyData.companyLogos.data : null ;
            let addNewDatas = [], promises = [];
            if (companyLogoDatas && companyLogoDatas.length) {
                companyLogoDatas.forEach((companyLogoData) => {
                    if (companyLogoData.id) {
                        promises.push(CompanyMasterModel.CompanyLogo.updateCustomerFinance(companyLogoData, {id: companyLogoData.id}));
                    } else {
                        companyLogoData['companyId'] = companyId;
                        addNewDatas.push(companyLogoData);
                    }
                })
                if (addNewDatas.length) {
                    promises.push(CompanyMasterModel.CompanyLogo.bulkCreate(addNewDatas, {returning: true, transaction: null}))
                }
            }
            const companyLogoDeleteDatas = companyData.companyLogos && companyData.companyLogos.deleteItems ? companyData.companyLogos.deleteItems : null ;
            if (companyLogoDeleteDatas && companyLogoDeleteDatas.length) {
                companyLogoDeleteDatas.forEach((deleteId) => {
                    if (deleteId) {
                        let companyLogoDeleteData = {'deleted': true, 'status': 'deleted', 'isDefault': false}
                        promises.push(CompanyMasterModel.CompanyLogo.updateCustomerFinance(companyLogoDeleteData, {id: deleteId}));
                    }
                })
            }
            if (promises.length) {
                await Promise.all(promises);
            }

            return resp;
        }
    }

    static async deleteCompany(ids, deleteOption, who) {
        if (deleteOption == "soft") {
            let obj = {};
            obj['updatedBy'] = who;
            return await CompanyModel.deleteSoft(ids, obj).then(() => {
                return CompanyModel.getAllByIds(ids, null).then((resp) => {
                    // if(!resp) {
                    // throw errorDef.MASTERDATA_NOT_FOUND;
                    // }
                    return resp;
                });
            });
        } else if (deleteOption == "hard") {
            return await CompanyModel.deleteHard(ids).then((resp) => {
                if (!resp) {
                    return resp;
                } else {
                    return {
                        id: ids
                    };
                }
            });
        }
    }

    static async getCompanyByParent(companyId) {
        const sql = `SELECT id, code, name FROM customer_master.company where id = '${companyId}'
        union
        SELECT id, code, name FROM customer_master.company where parentCompanyId = '${companyId}'
        union
        SELECT id, code, name FROM customer_master.company where parentCompanyId in (
        SELECT id FROM customer_master.company where parentCompanyId = '${companyId}'
        )
        `;
        return CompanyModel.sequelize.query(sql, {
            type: Sequelize.QueryTypes.SELECT,
            // plain: true
        })
    }

}

module.exports = Functions;