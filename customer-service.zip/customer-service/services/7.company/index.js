const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');

/**
 * Search Company Masterdata service
 * 
 * @route POST /company/search
 * @operationId searchCompany
 * @group Company API
 * @param {CompanySearch.model} CompanySearch.body - Search. Show all if not provided.
 * @returns {CompanySearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;

    const basicSearch = req.body.basicSearch;

    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };

    return functions.getCompany(search, pageObj, filter, basicSearch, showAll, distKeys, searchOrCond).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send({...resp, order, search, filter, showAll});
    }).catch((reason) => {
        next(reason);
    });
});

/**
 * Add Company Masterdata service
 * 
 * @route POST /company/add
 * @operationId addCompany
 * @group Company API
 * @param {AddCompany.model} AddCompany.body.required - required Company
 * @returns {Array.<CompanyData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customValidator.validateCreateCompany], async function (req, res, next) {
    const company = req.body.company;

    errorDef.parameterHandler([company]);
    
    _.forEach(company, (companyObj) => {
        errorDef.parameterHandler([
            companyObj.code, companyObj.name, companyObj.status,companyObj.companyRegistrationNo,
            companyObj.languageId, companyObj.timezoneId, companyObj.postcodeId, companyObj.countryId, companyObj.cityId, companyObj.stateId, companyObj.currencyId,
        ]);
    });

    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addCompany(company, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            let companyId = resp.length > 0 ? resp[0].id : '';
            functions.addDefaultCalenderIndicators(companyId)
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Update Company Masterdata service
 * 
 * @route POST /company/update
 * @operationId updateCompany
 * @group Company API
 * @param {UpdateCompany.model} UpdateCompany.body.required - required Company
 * @returns {CompanyData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customValidator.validateUpdateCompany], async function (req, res, next) {
    const companyId = req.body.id;
    const company = req.body.company;
    const token = req.headers.authorization;

    errorDef.parameterHandler([companyId]);
    errorDef.parameterHandler([
        company.code,company.companyRegistrationNo,
        company.languageId, company.timezoneId, company.postcodeId, company.countryId, company.cityId, company.stateId, company.currencyId
    ]);

    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: companyId };
        return functions.updateCompany(company, where, userInfo.id,token).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Delete Company Masterdata service
 * 
 * @route DELETE /company/delete
 * @operationId deleteCompany
 * @group Company API
 * @param {DeleteCompany.model} DeleteCompany.body.required - required Company
 * @returns {Array.<CompanyData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteCompany], async function (req, res, next) {
    const companyIds = req.body.ids;
    const deleteOption = req.body.option;

    errorDef.parameterHandler(companyIds);
    errorDef.parameterHandler([deleteOption]);

    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.deleteCompany(companyIds, deleteOption, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});

/**
 * Export Company Masterdata service
 * 
 * @route POST /company/export
 * @operationId exportCompany
 * @group Company API
 * @param {CompanySearch.model} CompanySearch.body - Search. Show all if not provided.
 * @returns {CompanySearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    
    return functions.getCompany(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows:resp.rows,
            filename:'company'
        };

        return ExportAPI.exportData(null, data).then(response =>{
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });
        
    }).catch((reason) => {
        next(reason);
    });
});

router.post('/companyTree', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;
    const hqId = req.body.hqId || null;

    // if(search) {
    //     _.forEach(search, (searchObj) => {
    //         errorDef.parameterHandler([searchObj.colId, searchObj.text]);
    //     });
    // }
    // errorDef.parameterHandler([page, limit, order]);
    // errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    };

    return functions.getCompanyTree(search, pageObj, filter, hqId).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send(resp);
    }).catch((reason) => {
        next(reason);
    });
})

router.post('/companyByParent', function (req, res, next) {
    const parentCompanyId = req.body.companyId;
    
    return functions.getCompanyByParent(parentCompanyId).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }

        return res.status(200).send(resp);
    }).catch((reason) => {
        next(reason);
    });
})

module.exports = router;