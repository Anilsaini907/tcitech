const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateCompany: (req, res, next) => {
        req.checkBody('company', 'Company object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('company.*.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.address1', 'Address 1 parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.postcodeId', 'Post Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.cityId', 'City parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.stateId', 'State parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.countryId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.languageId', 'City parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.timezoneId', 'City parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.currencyId', 'City parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.companyRegistrationNo', 'Company Registration No parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateCompany: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company', 'Company object parameter is missing').trim().notEmpty();
        req.checkBody('company.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.address1', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.postcodeId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.cityId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.stateId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.countryId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.languageId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.timezoneId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.currencyId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.companyRegistrationNo', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('company.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteCompany: (req, res, next) => {
        req.checkBody('ids', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}