const TaxclassModel = require('@driveit/driveit-databases/databases/customerMaster/models/8.taxclass');
const CountryModel = require('@driveit/driveit-databases/databases/generalMaster/models/01.country');
const errorDef = require('../services.config/errorDef');
const generalCache = require('../cache-request/general-api');
var _ = require('lodash');

class Functions {

    static async getTaxClass(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };

        if (search) {
            let excludedSearch = _.remove(search, (o) => { return o.colId === 'countryName' || o.colId === 'countryCode'; });
            let searched = await this.prepQry(excludedSearch);
            search = _.concat(search, searched);
        }

        let attr = null;
        let taxClassRes = await TaxclassModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond);
        
        let resp = await CountryModel.searchAll([], ['id', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], [], true, true, true);
        let countries = resp && !_.isEmpty(resp) ? _.map(resp, 'dataValues') : [];
    
        _.forEach(taxClassRes.rows, (row) => {
            let found = _.find(countries, (o) => { return _.isEqual(o.id, row.countryId); });
            if (found) {
                row.dataValues['countryName'] = found.name ? found.name : '';
            }
        });
        
        return {
            ...taxClassRes,
            page: page.page,
            limit: page.limit
        };
    }

    static async prepQry(search) {
        let likeArr = [];
        let searchMasterDatas = [];
        for(let u = 0; u < _.size(search); u++) {
            if (search[u].colId === 'countryName') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "name", text: search[u].text }],
                        skipInclude: true
                    });
                } else {
                    let found = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found) {
                        found.search.push({ colId: "name", text: search[u].text });
                    }
                }
            } else if (search[u].colId === 'countryCode') {
                if (searchMasterDatas.length === 0) {
                    searchMasterDatas.push({
                        masterdata: 'country',
                        search: [{ colId: "code", text: search[u].text }],
                        skipInclude: true
                    });
                } else {
                    let found1 = _.find(searchMasterDatas, (o) => { return o.masterdata === 'country'; });
                    if (found1) {
                        found1.search.push({ colId: "code", text: search[u].text });
                    }
                }
            }
        }
        

        let queryResult = await generalCache.getMasterDataByQuery(searchMasterDatas);
        if (queryResult) {
            if (queryResult.country) {
                let countryIds = [];
                queryResult.country.forEach((country) => {
                    countryIds.push(country.id);
                });
                likeArr.push({ colId: 'countryId', text: !_.isEmpty(countryIds) ? countryIds : ['00000000-0000-0000-0000-000000000000'] });
            }
        }
        return likeArr;
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        
        //temp fix for PBI 663. Task 729. to display country Name
        return TaxclassModel.getAll(q, attr, pagination, page.order).then((taxClassRes) => {
            let masterdataTypes = ["country"];
            let token = page.token? page.token : null;
            return generalCache.processMasterdataResult(taxClassRes.rows, masterdataTypes, token).then((mdResults) => {
                _.forEach(taxClassRes.rows, (row) => {
                    let mObj = {};
                    _.forEach(mdResults, (masterdata, key) => {
                        mObj[key] = _.find(masterdata, (c) => {
                            let masterDataIdStr = `${key}Id`;
                            if(c && c.id) {
                                return _.isEqual(c.id, row[masterDataIdStr]);
                            } else {
                                return null;
                            }
                        });
                        
                        if(mObj[key] && mObj[key].name) {
                            let masterDataNameStr = `${key}Name`;
                            row.dataValues[masterDataNameStr] = mObj[key].name;
                        }
                    });
                });
                return {
                    ...taxClassRes,
                    page: page.page,
                    limit: page.limit
                };
            });
        });

        // return {
        //     ...await TaxclassModel.getAll(q, attr, pagination, page.order),
        //     page: page.page,
        //     limit: page.limit
        // };
    }
    static async updateDefault(taxdata){
        const data={default:'disabled'}
        const where={countryId:taxdata.countryId,deleted:0,default:'enabled',status:'enabled'}
        const getDefaultValue=await TaxclassModel.findAll({where:where});
        if(getDefaultValue.length>0){
            var result=await TaxclassModel.update(data, {where:{id:getDefaultValue[0].id}});
        }
        return result;
    }
    static async  addTaxClass(taxclassObj, who) {
        if(taxclassObj[0].default==='enabled'){
            const data={default:"disabled"}
            const where={countryId:taxclassObj[0].countryId,deleted:0,status:'enabled'}
            await TaxclassModel.update(data, {where:where});
        }
        return TaxclassModel.sequelize.transaction(async(t) => {
            var promises = [];
            _.forEach(taxclassObj, async(addTaxClassObj) => {
                addTaxClassObj['createdBy'] = who;
                addTaxClassObj['updatedBy'] = who;
                const p = TaxclassModel.addNew(addTaxClassObj, t);
                promises.push(p);
            });
           return Promise.all(promises);
        });
    }
    static async updateTaxClass(taxclass, where, who) {
        if(taxclass.default==='enabled'){
            const data={default:"disabled"}
            const where={countryId:taxclass.countryId,deleted:0,status:'enabled'}
            await TaxclassModel.update(data, {where:where});
        }
        taxclass['updatedBy'] = who;
        taxclass['id'] = where.id;
        return await TaxclassModel.updateTaxClass(taxclass, where).then(()=>{
            return TaxclassModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteTaxClass(where, who, type = "soft") {
        if(type == "soft") {
            return await TaxclassModel.deleteSoft(where, who).then(()=>{
                return TaxclassModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await TaxclassModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;