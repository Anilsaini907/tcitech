const express = require('express');
const router = express.Router();
const functions = require('./functions');
const ExportAPI = require('../api-request/export-api');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');
const customValidator = require('./validation');
/**
 * Search TaxClass Masterdata service
 * 
 * @route POST /taxclass/search
 * @operationId searchTaxClass
 * @group Tax Classification API
 * @param {TaxClassSearch.model} TaxClassSearch.body - Search. Show all if not provided.
 * @returns {TaxClassSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/search', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;
    const filter = req.body.filter;
    
    const showAll = req.body.showAll ? req.body.showAll : false;
    const distKeys = req.body.distKeys ? req.body.distKeys : null;
    const searchOrCond = req.body.searchOrCond ? req.body.searchOrCond : false;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
        return functions.getTaxClass(search, pageObj, filter, showAll, distKeys, searchOrCond).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }

            return res.status(200).send({...resp, order, search, filter});
        }).catch((reason) => {
            next(reason);
        });
});
/**
 * Add TaxClass Masterdata service
 * 
 * @route POST /taxclass/add
 * @operationId addTaxClass
 * @group Tax Classification API
 * @param {AddTaxClass.model} AddTaxClass.body.required - required TaxClass
 * @returns {Array.<TaxClassData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/add', [customValidator.validateCreateTaxClass], async function (req, res, next) {
    const taxclass = req.body.taxclass;
    errorDef.parameterHandler([taxclass]);
    _.forEach(taxclass, (taxclassObj) => {
        errorDef.parameterHandler([taxclassObj.code, taxclassObj.name, taxclassObj.countryId]);
    });
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        return functions.addTaxClass(taxclass, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Update TaxClass Masterdata service
 * 
 * @route POST /taxclass/update
 * @operationId updateTaxClass
 * @group Tax Classification API
 * @param {UpdateTaxClass.model} UpdateTaxClass.body.required - required TaxClass
 * @returns {TaxClassData.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.post('/update', [customValidator.validateUpdateTaxClass], async function (req, res, next) {
    const taxclassId = req.body.id;
    const taxclass = req.body.taxclass;
    errorDef.parameterHandler([taxclassId]);
    errorDef.parameterHandler([taxclass]);
    // errorDef.parameterHandler([taxclass.code, taxclass.name]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: taxclassId };
        return functions.updateTaxClass(taxclass, where, userInfo.id).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Delete TaxClass Masterdata service
 * 
 * @route DELETE /taxclass/delete
 * @operationId deleteTaxClass
 * @group Tax Classification API
 * @param {DeleteTaxClass.model} DeleteTaxClass.body.required - required TaxClass
 * @returns {Array.<TaxClassData>} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 * @security firebase
 */
router.delete('/delete', [customValidator.validateDeleteTaxClass], async function (req, res, next) {
    const taxclassId = req.body.id;
    const deleteOption = req.body.option;
    errorDef.parameterHandler([taxclassId, deleteOption]);
    const userInfo = await errorDef.userInfoHandler(req)
    .catch(err=>{
        console.error(err);
        next(err);
    });
    if(userInfo){
        let where = { id: taxclassId };
        return functions.deleteTaxClass(where, userInfo.id, deleteOption).then((resp) => {
            if (!resp) {
                throw errorDef.MASTERDATA_NOT_FOUND
            }
            return res.status(200).send(resp);
        }).catch((reason) => {
            next(reason);
        });
    }
});
/**
 * Export TaxClass Masterdata service
 * 
 * @route POST /taxclass/export
 * @operationId exportTaxClass
 * @group Tax Classification API
 * @param {TaxClassSearch.model} TaxClassSearch.body - Search. Show all if not provided.
 * @returns {TaxClassSearchResult.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/export', function (req, res, next) {
    const search = req.body.search;
    const page = req.body.page; 
    const limit = req.body.limit;
    const order = req.body.order;

    if(search) {
        _.forEach(search, (searchObj) => {
            errorDef.parameterHandler([searchObj.colId, searchObj.text]);
        });
    }
    errorDef.parameterHandler([page, limit, order]);
    errorDef.parameterHandler([order.columnName, order.direction]);
    let pageObj = {
        page,
        limit,
        order: [order.columnName, order.direction]
    }
    
    return functions.getTaxClass(search, pageObj, []).then((resp) => {
        if (!resp) {
            throw errorDef.MASTERDATA_NOT_FOUND
        }
        let data = {
            rows:resp.rows,
            filename:'taxclass'
        };

        return ExportAPI.exportData(null, data).then(response =>{
            if (!response) {
                throw errorDef.EXPORTDATA_NOT_FOUND;
            }
            return res.status(200).send(response);
        });
        
    }).catch((reason) => {
        next(reason);
    });
});
module.exports = router;