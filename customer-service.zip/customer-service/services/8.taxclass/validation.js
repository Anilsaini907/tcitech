const errorDef = require('../services.config/errorDef');

const self = module.exports = {
    validateCreateTaxClass: (req, res, next) => {
        req.checkBody('taxclass', 'Tax Class object parameter is missing').trim().notEmpty().isArray();
        req.checkBody('taxclass.*.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('taxclass.*.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('taxclass.*.countryId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('taxclass.*.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateUpdateTaxClass: (req, res, next) => {
        req.checkBody('id', 'ID parameter is invalid or missing').trim().notEmpty();
        req.checkBody('taxclass', 'Tax Class object parameter is missing').trim().notEmpty();
        req.checkBody('taxclass.code', 'Code parameter is invalid or missing').trim().notEmpty();
        req.checkBody('taxclass.name', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('taxclass.countryId', 'Name parameter is invalid or missing').trim().notEmpty();
        req.checkBody('taxclass.status', 'Status parameter is invalid or missing').trim().notEmpty();
        req.asyncValidationErrors().then(function () {
            next();
        }).catch(function (errors) {

            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            }
        });
    },

    validateDeleteTaxClass: (req, res, next) => {
        req.checkBody('id', "ID is missing").notEmpty();

        req.asyncValidationErrors({ onlyFirstError: true }).then(function () {
            next();
        }).catch(function (errors) {
            if (errors) {
                let retErr = errorDef.INVALID_PARAMETER;
                retErr.errors = errors;
                return res.status(422).json(retErr);
            } else {
                next();
            }
        });
    },
}