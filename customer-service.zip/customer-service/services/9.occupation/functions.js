const OccupationModel = require('@driveit/driveit-databases/databases/customerMaster/models/9.occupation');
const errorDef = require('../services.config/errorDef');
var _ = require('lodash');

class Functions {

    static async getOccupation(search, page, filter, showAll = false, distKeys = null, searchOrCond = false) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        };

        let attr = null;
        return {
            ...await OccupationModel.searchAll(search, attr, pagination, page.order, filter, false, showAll, false, [], null, distKeys, searchOrCond),
            page: page.page,
            limit: page.limit
        }
    }

    static async getAll(page) {
        const pagination = {
            limit : page.limit,
            offset: page.limit * (page.page - 1),
        }
        let q = {};
        let attr = null;
        return {
            ...await OccupationModel.getAll(q, attr, pagination, page.order),
            page: page.page,
            limit: page.limit
        };
    }

    static async addOccupation(occupationObj, who) {
        return OccupationModel.sequelize.transaction((t) => {
            var promises = [];
            _.forEach(occupationObj, (addOccupationObj) => {
                addOccupationObj['createdBy'] = who;
                addOccupationObj['updatedBy'] = who;
                const p = OccupationModel.addNew(addOccupationObj, t);
                promises.push(p);
            });
            return Promise.all(promises);
        });
    }
    static async updateOccupation(occupation, where, who) {
        occupation['updatedBy'] = who;
        occupation['id'] = where.id;
        return await OccupationModel.updateOccupation(occupation, where).then(()=>{
            return OccupationModel.getId(where).then((resp)=>{
                if(!resp) { 
                   throw errorDef.MASTERDATA_NOT_FOUND;
                }
                return resp;
            });
        });
    }
    static async deleteOccupation(where, who, type = "soft") {
        if(type == "soft") {
            return await OccupationModel.deleteSoft(where, who).then(()=>{
                return OccupationModel.getAll(where, null).then((resp)=>{
                    return resp;
                });
            });
        } else if (type == "hard") {
            return await OccupationModel.deleteHard(where).then((resp)=>{
                if(!resp) {
                    return resp;
                } else {
                    return where;
                }
            });
        }
    }
}


module.exports = Functions;