const https = require('https');
const http = require('http');
const utils = require('../../utilities/utils');
const config = require('config');
var _ = require('lodash');

class ExportAPI {
    // static async httpsPost({ body, ...options }) {
    //     return new Promise((resolve, reject) => {
    //         const req = https.request({
    //             method: 'POST',
    //             ...options,
    //         }, res => {
    //             const chunks = [];
    //             res.on('data', data => chunks.push(data))
    //             res.on('end', () => {
    //                 let body = Buffer.concat(chunks);
    //                 res.headers['content-type'] = 'application/json';
    //                 body = JSON.parse(body);
    //                 resolve(body)
    //             })
    //         })
    //         req.on('error', reject);
    //         if (body) {
    //             req.write(body);
    //         }
    //         req.end();
    //     })
    // }
    static async httpPost({ body, ...options }) {
        // process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
        return new Promise((resolve, reject) => {
            const req = http.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    body = JSON.parse(body);
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async exportData(token, body) {
        let obj = {
            hostname: config.exportService.hostname,
            path: config.exportService.getexportDataPath,
            method: 'POST',
            headers: {
                'Authorization' : `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        // if (process.env.NODE_ENV === 'development-local') {
            // obj['port'] = config.generalService.port;
            return await this.httpPost(obj);
        // } else {
            // return await this.httpsPost(obj);
        // }
    }
}

module.exports = ExportAPI;