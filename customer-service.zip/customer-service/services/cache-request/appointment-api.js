const https = require('https');
const http = require('http');
const config = require('config');
var _ = require('lodash');

// const serviceMasterDB = require("@driveit/driveit-databases/databases/serviceMaster");
const serviceMasterFunctions = require("@driveit/driveit-databases/functions/serviceMaster/functions");

class AppointmentAPI {
    static async httpsPost({ body, ...options }) {
        // process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
        return new Promise((resolve, reject) => {
            const req = https.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    body = JSON.parse(body);
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async httpPost({ body, ...options }) {
        // process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
        return new Promise((resolve, reject) => {
            const req = http.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    body = JSON.parse(body);
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async getCacheData(token, body) {
        let obj = {
            hostname: config.appointmentService.hostname,
            path: config.appointmentService.cachePath,
            method: 'POST',
            headers: {
                'Authorization' : `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.appointmentService.port;
            return await this.httpPost(obj);
        } else {
            return await this.httpsPost(obj);
        }
    }
    
    static async getCacheDataByIds(token, body) {
        let obj = {
            hostname: config.appointmentService.hostname,
            path: config.appointmentService.cacheByIdPath,
            method: 'POST',
            headers: {
                'Authorization' : `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        // return await this.httpsPost(obj);
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.appointmentService.port;
            return await this.httpPost(obj);
        } else {
            return await this.httpsPost(obj);
        }
    }

    static async getCacheDataByQuery(token, body) {
        // console.log('bodyyyy', JSON.stringify(body))
        let obj = {
            hostname: config.appointmentService.hostname,
            path: config.appointmentService.cacheByQueryPath,
            method: 'POST',
            headers: {
                'Authorization' : `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        // return await this.httpsPost(obj);
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.appointmentService.port;
            return await this.httpPost(obj);
        } else {
            return await this.httpsPost(obj);
        }
    }

    static async processCacheResult(rows, masterdataTypes, token=null) {
        let promises = [];
        let masterdataIds = {};
        _.forEach(masterdataTypes, (masterdatayType) => {
            masterdataIds[masterdatayType]=[]; // init array object
        });
        _.forEach(rows, (row)=>{
            _.forEach(masterdataTypes, (masterdatayType) => {
                let mdIdStr = `${masterdatayType}Id`;
                masterdataIds[masterdatayType].push(row[mdIdStr]);                
            });
        });
        _.forEach(masterdataTypes, (masterdatayType) => {
            let p=this.getCacheByIds(masterdatayType, masterdataIds[masterdatayType], token);
            promises.push(p);
        });
        return Promise.all(promises).then((res) => {
            let returnRes = {};
            let index = 0;
            _.forEach(masterdataTypes, (masterdatayType) => {
                returnRes[masterdatayType] = res[index++];
            });
            
            return returnRes;
        });
    }

    static async getCacheByIds(masterdataType, IdArr, token = null) {
        let body = {
            "data": [{
                "cacheKey" : masterdataType,
                "ids": IdArr
            }]
        };
        // return await this.getCacheDataByIds(token, body);
        return await serviceMasterFunctions.getDataByIds(body.data);
    }

    static async getCacheByQuery(searchMasterDatas, token = null) {
        _.forEach(searchMasterDatas, (o) => {
            o['skipCount'] = true;
        });
        // let body = {
        //     "data": searchMasterDatas
        // };
        // return await this.getCacheDataByQuery(token, body);
        return await serviceMasterFunctions.getDataByQuery(searchMasterDatas);
    }

    static processRow(rows, cacheResults) {
        _.forEach(rows, (row) => {
            let mObj = {};
            _.forEach(cacheResults, (masterdata, key) => {
                mObj[key] = _.find(masterdata, (c) => {
                    let masterDataIdStr = `${key}Id`;
                    if(c && c.id) {
                        return _.isEqual(c.id, row[masterDataIdStr]);
                    } else {
                        return null;
                    }
                });

                if(mObj[key]) {
                    row[`${key}`] = mObj[key];
                }
            });
        });
    }

    static processRowRecords(recordResults, cacheResults, getWhole = false){
        _.forEach(recordResults.rows, (row) => {
            let mObj = {};
            _.forEach(cacheResults, (masterdata, key) => {
                mObj[key] = _.find(masterdata, (c) => {
                    let masterDataIdStr = `${key}Id`;
                    if(c && c.id) {
                        return _.isEqual(c.id, row[masterDataIdStr]);
                    } else {
                        return null;
                    }
                });
                
                if(mObj[key]) {
                    if (getWhole) {
                        row.dataValues[`${key}`] = mObj[key];
                    } else {
                        if (mObj[key].name) {
                            row.dataValues[`${key}Name`] = mObj[key].name;
                        }
                        if (mObj[key].code) {
                            row.dataValues[`${key}Code`] = mObj[key].code;
                        }
                    }
                }
            });

        });
    }

}

module.exports = AppointmentAPI;