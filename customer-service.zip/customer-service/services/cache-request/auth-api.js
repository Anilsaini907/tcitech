const https = require('https');
const http = require('http');
const config = require('config');
var _ = require('lodash');

// const authMasterDB = require("@driveit/driveit-databases/databases/auth");
const authMasterFunctions = require("@driveit/driveit-databases/functions/authMaster/functions");

class AuthAPI {
    static async httpsPost({
        body,
        ...options
    }) {
        // process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
        return new Promise((resolve, reject) => {
            const req = https.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    body = JSON.parse(body);
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async httpPost({
        body,
        ...options
    }) {
        // process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
        return new Promise((resolve, reject) => {
            const req = http.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    body = JSON.parse(body);
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async processCache(token, body) {
        let obj = {
            hostname: config.authService.hostname,
            path: config.authService.cachePath,
            method: 'POST',
            headers: {
                'Authorization': `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.authService.port;
            return await this.httpPost(obj);
        } else {
            return await this.httpsPost(obj);
        }
    }

    static async processCacheById(token, body, headers = null) {
        let obj = {
            hostname: config.authService.hostname,
            path: config.authService.cacheByIdPath,
            method: 'POST',
            headers: {
                'Authorization': `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        // return await this.httpsPost(obj);
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.authService.port;
            return await this.httpPost(obj);
        } else {
            return await this.httpsPost(obj);
        }
    }

    static async processCacheByQuery(token, body) {
        let obj = {
            hostname: config.authService.hostname,
            path: config.authService.cacheByQueryPath,
            method: 'POST',
            headers: {
                'Authorization' : `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        // return await this.httpsPost(obj);
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.authService.port;
            return await this.httpPost(obj);
        } else {
            return await this.httpsPost(obj);
        }
    }

    static async processResultsById(rows, cacheKey, token = null, headers = null) {
        let promises = [];
        let dataIds = {};
        _.forEach(cacheKey, (key) => {
            dataIds[key.rowKey?key.rowKey:key] = []; // init array object
        });
        _.forEach(rows, (row) => {
            _.forEach(cacheKey, (key) => {
                let mdIdStr = `${key.rowKey?key.rowKey:key}Id`;
                dataIds[key.rowKey?key.rowKey:key].push(row[mdIdStr]);
            });
        });
        _.forEach(cacheKey, (key) => {
            let p = this.getCacheById(key.cacheKey?key.cacheKey:key, dataIds[key.rowKey?key.rowKey:key], token, headers);
            promises.push(p);
        });
        return Promise.all(promises).then((res) => {
            let returnRes = {};
            let index = 0;
            _.forEach(cacheKey, (key) => {
                returnRes[key.rowKey?key.rowKey:key] = res[index++];
            });

            return returnRes;
        });
    }

    static async postProcessingResults(rows, results){
        _.forEach(rows, (row) => {
            let mObj = {};
            _.forEach(results, (masterdata, key) => {
                mObj[key] = _.find(masterdata, (c) => {
                    let masterDataIdStr = `${key}Id`;
                    if(c && c.id) {
                        return _.isEqual(c.id, row[masterDataIdStr]);
                    } else {
                        return null;
                    }
                });
                
                if(mObj[key]) {
                    row.dataValues[key] = mObj[key];
                }else{
                    row.dataValues[key] = null;
                }
            });
        });
    }

    static async getCacheById(key, IdArr, token = null, headers = null) {
        let body = {
            "data": [{
                "cacheKey": key,
                "ids": IdArr
            }]
        };
        // return await this.processCacheById(token, body, headers);
        return await authMasterFunctions.getCacheByIds(body.data)
    }

    static async getCacheByQuery(searchMasterDatas, token = null) {
        _.forEach(searchMasterDatas, (o) => {
            o['skipCount'] = true;
        });
        // let body = {
        //     "data": searchMasterDatas
        // };
        // return await this.processCacheByQuery(token, body);
        return await authMasterFunctions.getDataByQuery(searchMasterDatas)
    }
}

module.exports = AuthAPI;