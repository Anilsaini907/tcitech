const https = require('https');
const http = require('http');
const Utils = require('../../utilities/utils')
const config = require('config');
var _ = require('lodash');

// const customerMasterDB = require("@driveit/driveit-databases/databases/customerMaster");
const customerMasterFunctions = require("@driveit/driveit-databases/functions/customerMaster/functions");

class CustomerAPI {
    static async httpsPost({ body, ...options }) {
        // process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
        return new Promise((resolve, reject) => {
            const req = https.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    body = JSON.parse(body);
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async httpPost({ body, ...options }) {
        // process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
        return new Promise((resolve, reject) => {
            const req = http.request({
                method: 'POST',
                ...options,
            }, res => {
                const chunks = [];
                res.on('data', data => chunks.push(data))
                res.on('end', () => {
                    let body = Buffer.concat(chunks);
                    res.headers['content-type'] = 'application/json';
                    body = JSON.parse(body);
                    resolve(body)
                })
            })
            req.on('error', reject);
            if (body) {
                req.write(body);
            }
            req.end();
        })
    }

    static async getCustomerData(token, body) {
        let obj = {
            hostname: config.customerService.hostname,
            path: config.customerService.getCustomerDataPath,
            method: 'POST',
            headers: {
                'Authorization' : `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.customerService.port;
            return await this.httpPost(obj);
        } else {
            return await this.httpsPost(obj);
        }
    }
    
    static async getCustomerDataByIds(token, body) {
        let obj = {
            hostname: config.customerService.hostname,
            path: config.customerService.getCustomerDataByIdsPath,
            method: 'POST',
            headers: {
                'Authorization' : `${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(body)
        };
        // return await this.httpsPost(obj);
        if (process.env.NODE_ENV === 'development-local') {
            obj['port'] = config.customerService.port;
            return await this.httpPost(obj);
        } else {
            return await this.httpsPost(obj);
        }
    }

    static async processMasterCustomerDataResult(rows, cacheKey, token=null) {
        let promises = [];
        let dataIds = {};
        _.forEach(cacheKey, (key) => {
            dataIds[key.rowKey?key.rowKey:key] = []; // init array object
        });
        _.forEach(rows, (row) => {
            _.forEach(cacheKey, (key) => {
                let mdIdStr = `${key.rowKey?key.rowKey:key}Id`;
                dataIds[key.rowKey?key.rowKey:key].push(row[mdIdStr]);
            });
        });
        _.forEach(cacheKey, (key) => {
            let p = this.getMasterDataByIds(key.cacheKey?key.cacheKey:key, dataIds[key.rowKey?key.rowKey:key], token);
            promises.push(p);
        });
        return Promise.all(promises).then((res) => {
            let returnRes = {};
            let index = 0;
            _.forEach(cacheKey, (key) => {
                returnRes[key.rowKey?key.rowKey:key] = res[index++];
            });

            return returnRes;
        });
    }

    static async getMasterDataByIds(masterdataType, IdArr, token = null) {        
        let body = {
            "data": [{
                "masterdata" : masterdataType,
                "ids": IdArr
            }]
        };
        // return await this.getCustomerDataByIds(token, body);
        return await customerMasterFunctions.getDataByIds(body.data);
    }

    static processRowRecords(rows, cacheResults){
        _.forEach(rows, (row) => {
            let mObj = {};
            _.forEach(cacheResults, (masterdata, key) => {
                mObj[key] = _.find(masterdata, (c) => {
                    let masterDataIdStr = `${key}Id`;
                    if(c && c.id) {
                        return _.isEqual(c.id, row[masterDataIdStr]);
                    } else {
                        return null;
                    }
                });
                
                if(mObj[key]) {
                    row.dataValues[key] = mObj[key];
                }else{
                    row.dataValues[key] = null;
                }
            });
        });
    }

}

module.exports = CustomerAPI;
