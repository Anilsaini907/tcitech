const _ = require('lodash');
const { Client } = require('@elastic/elasticsearch')
const client = new Client({
    node: process.env.ES_URL || 'https://35.197.131.114:9200',
    auth: {
        username: process.env.ES_USERNAME || 'elastic',
        password: process.env.ES_PASSWORD || 'nrhf2vddlwm59qwv4g2trw2j'
    },
    ssl: {
        rejectUnauthorized: false
    }
})

const indexName = 'repair-order';
const indexAlias = 'repairOrder';
const docType = 'repairOrder';

const self = module.exports = {
    /**
     * Update the RO Data
     */
    updateBranch: (id,branch) => {
        return new Promise(async resolve => {
            await client.updateByQuery({
                index: indexAlias,
                body: {
                    "query": {
                      "term": {
                        "branchId": id
                        }
                    },
                    "script": {
                      "source": `ctx._source.branchCodeName = '${branch.code, ' - ', branch.name}';ctx._source.branchCode = '${branch.code}';ctx._source.branchName = '${branch.name}'; ctx._source.countryId = '${branch.countryId}'; `,
                      "lang": "painless"
                    }
                  }
            })
                .catch(err => {
                    console.log(err);
                });
                resolve();
        })
    },
    updateCustomer: (id,customer) => {
        return new Promise(async resolve => {
            await client.updateByQuery({
                index: indexAlias,
                body: {
                    "query": {
                      "term": {
                        "customerId": id
                        }
                    },
                    "script": {
                      "source": `ctx._source.customerNameIdno = '${customer.name, ' - ', customer.identityNo}';ctx._source.customerName = '${customer.name}';ctx._source.identityNo = '${customer.identityNo}';`,
                      "lang": "painless"
                    }
                  }
            })
                .catch(err => {
                    console.log(err);
                });
                resolve();
        })
    },
    updateCustomerContact: (id,contact) => {
        return new Promise(async resolve => {
            await client.updateByQuery({
                index: indexAlias,
                body: {
                    "query": {
                      "term": {
                        "contactPersonId": id
                        }
                    },
                    "script": {
                      "source": `ctx._source.contactName = '${contact.name}';ctx._source.contactPersonTelephone = '${contact.telephone}';ctx._source.contactPersonMobile = '${contact.mobile}';ctx._source.contactPersonEmail = '${contact.email}';ctx._source.relationshipId = '${contact.relationshipId}';`,
                      "lang": "painless"
                    }
                  }
            })
                .catch(err => {
                    console.log(err);
                });
                resolve();
        })
    },
}
