const _ = require('lodash');
// const {
//     Client
// } = require('@elastic/elasticsearch');

// const client = new Client({
//     node: process.env.ES_URL || 'https://35.197.131.114:9200',
//     auth: {
//         username: process.env.ES_USERNAME || 'elastic',
//         password: process.env.ES_PASSWORD || 'nrhf2vddlwm59qwv4g2trw2j'
//     },
//     ssl: {
//         rejectUnauthorized: false
//     }
// })

const indexName = 'vehicle-master';
const indexAlias = 'vehicle-master';
const docType = 'vehicleMaster';

const self = module.exports = {
    /**
     * Update the RO Data
     */
    updateDataById: (functions, id, headers) => {
        return new Promise(async resolve => {
            const page = 1;
            const limit = 1;
            const order = {
                "columnName": "updatedAt",
                "direction": "DESC"
            };
            const filter = [{
                "colId": "id",
                "text": [
                    id
                ]
            }];
            const token = headers.authorization;

            let pageObj = {
                page,
                limit,
                order: [order.columnName, order.direction],
                token
            };
            // let vehicleData = await functions.getVehicleForEsUpdate(pageObj, filter);
            // if (vehicleData.length > 0) {
            //     await client.update({
            //             id: vehicleData[0].id,
            //             index: indexAlias,
            //             refresh: 'true',
            //             routing: vehicleData[0].id,
            //             body: {
            //                 doc: vehicleData[0]
            //             }
            //         })
            //         .catch(err => {
            //             console.log(err);
            //             console.log(vehicleData)
            //         });
            // }
            resolve();
        })
    },
    updateDataByIds: (functions, ids, headers) => {
        return new Promise(async resolve => {
            const page = 1;
            const limit = 30;
            const order = {
                "columnName": "updatedAt",
                "direction": "DESC"
            };
            const filter = [{
                colId: "id",
                text: ids
            }];
            const token = headers.authorization;

            let pageObj = {
                page,
                limit,
                order: _.isArray(order) ? order : [order.columnName, order.direction],
                token
            };
            // let vehicleData = await functions.getVehicleForEsUpdate(pageObj, filter);

            // if (vehicleData && vehicleData.length > 0) {
            //     for (let a = 0; a < vehicleData.length; a++) {
            //         let elementRes = vehicleData[a];
            //         await client.update({
            //                 id: elementRes.id,
            //                 index: indexAlias,
            //                 refresh: 'true',
            //                 routing: elementRes.id,
            //                 body: {
            //                     doc: elementRes
            //                 }
            //             })
            //             .catch(err => {
            //                 console.log(err);
            //                 console.log(vehicleData)
            //             });
            //     }
            // }
            resolve();
        })
    }
}
