const monitor = require('./monitor');

const errorResponseHandler = require('./services.config/errorDef').errorResponseHandler;
const errorClientHandler = require('./services.config/errorDef').errorClientHandler;

class ServicesIndex {
  constructor(app) {
    this.app = app;
  }

  registerServices() {
    this.app.use('/monitor', monitor);
    this.app.use('/sample', require('./0.sample'));
    this.app.use('/customerGroup', require('./1.customerGroup'));
    this.app.use('/paymentTerms', require('./2.paymentTerms'));
    this.app.use('/block', require('./3.block'));
    this.app.use('/leads', require('./4.leads'));
    this.app.use('/contactRelationship', require('./5.contactRelationship'));
    this.app.use('/customerAccountGroup', require('./6.customerAccountGroup'));
    this.app.use('/company', require('./7.company'));
    this.app.use('/taxclass', require('./8.taxclass'));
    this.app.use('/occupation', require('./9.occupation'));
    this.app.use('/customer', require('./10.customer'));
    this.app.use('/customerDetails', require('./11.customerDetails'));
    this.app.use('/customerFinance', require('./12.customerFinance'));
    this.app.use('/customerContact', require('./13.customerContact'));
    this.app.use('/employmentSector', require('./14.employmentSector'));
    this.app.use('/industry', require('./15.industry'));
    this.app.use('/annualIncome', require('./16.annualIncome'));
    this.app.use('/maritalStatus', require('./17.maritalStatus'));
    this.app.use('/branch', require('./18.branch'));
    this.app.use('/businessStream', require('./19.businessStream'));
    this.app.use('/storageLocation', require('./20.storageLocation'));
    this.app.use('/businessType', require('./21.businessType'));
    this.app.use('/branchBusinessStream', require('./22.branchBusinessStream'));
    this.app.use('/branchBusinessType', require('./23.branchBusinessType'));
    this.app.use('/companyBranch', require('./24.companyBranch'));
    this.app.use('/storage', require('./25.storage'));
    this.app.use('/employmentStatus', require('./27.employmentStatus'));
    this.app.use('/customerType', require('./28.customerType'));
    this.app.use('/dealerGroup', require('./29.dealerGroup'));
    this.app.use('/branchRoutes', require('./31.branchRoutes'));
    this.app.use('/calendarIndicator', require('./32.calendarIndicator'));
    this.app.use('/customerCorrespondenceAddress', require('./33.customerCorrespondenceAddress'));
    this.app.use('/customerRemarks', require('./34.customerRemarks'));
    this.app.use('/customerTags', require('./35.customerTags'));
    this.app.use('/branchBankAccounts', require('./36.branchBankAccounts'));
    this.app.use('/companyLogo', require('./38.companyLogo'));
    this.app.use('/customerRemarkType', require('./39.customerRemarkType'));

    this.app.use(errorResponseHandler);
    this.app.use(errorClientHandler);
  }
}

module.exports = (app)=>{
  return new ServicesIndex(app).registerServices();
}