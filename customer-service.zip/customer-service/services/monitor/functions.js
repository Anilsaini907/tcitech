const Sequelize = require('sequelize');

const fs = require('fs');
const packageJsonPath = `${process.cwd()}/package.json`;
const packageInfo = fs.existsSync(packageJsonPath) ? require(packageJsonPath) : {};

class MonitorFunctions {
    static async healthChecker() {
        return {
            Application: {
                name: getTitle(),
                version: getVersion(),
                dependencies: packageInfo.dependencies
            },
            Dependencies: process.versions
        };
    }

}

function getVersion() {
    if (packageInfo.version) {
        const nodeJsVersion = process.version;
        return {
            packageVersion: packageInfo.version,
            nodeJsVersion
        };
    }

    return undefined;
}

function getTitle() {
    if (packageInfo.name) {
        return packageInfo.name;
    }
    return undefined;
}


module.exports = MonitorFunctions;