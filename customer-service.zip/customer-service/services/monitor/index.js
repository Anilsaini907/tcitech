const express = require('express');
const router = express.Router();
const monitorFunctions = require('./functions');
const errorDef = require('../services.config/errorDef');

/**
 * Testing api to check condition of auth service
 * 
 * @route GET /api/health/liveness
 * @operationId liveness
 * @group kube-probe - API testing checker - liveness
 * @returns {string} 200 - OK
 * @returns {string} 400 - Bad Request
 */


 /**
 * Testing api to check condition of auth service
 * 
 * @route GET /api/health/readiness
 * @operationId readiness
 * @group kube-probe - API testing checker - readiness
 * @returns {string} 200 - OK
 * @returns {string} 400 - Bad Request
 */


/**
 * Testing api to check condition of auth service
 * 
 * @route GET /monitor/health
 * @operationId getHealth
 * @group Monitor - API testing checker
 * @returns {Auth.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.get('/health', function (req, res, next) {

    return monitorFunctions.healthChecker()
        .then((result) => {
            return res.send({
                code: 'OK',
                message: result
            });



        }).catch((reason) => {
            let errorResponse = errorDef.DATABASE_ISSUE;
            errorResponse.error = reason;
            return res.status(400).send(errorResponse);
        })
});

/**
 * Testing api to check condition of auth service
 * 
 * @route POST /monitor/health
 * @operationId postHealth
 * @group Monitor - API testing checker
 * @returns {Auth.model} 200 - OK
 * @returns {Error.model} 400 - Bad Request
 */
router.post('/health', function (req, res, next) {
    return monitorFunctions.healthChecker()
        .then((result) => {
            return res.send({
                code: 'OK',
                message: result
            });



        }).catch((reason) => {
            let errorResponse = errorDef.DATABASE_ISSUE;
            errorResponse.error = reason;
            return res.status(400).send(errorResponse);
        })
});




module.exports = router;