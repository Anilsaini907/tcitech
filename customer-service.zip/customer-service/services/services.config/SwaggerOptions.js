const fs = require('fs');
const packageJsonPath = `${process.cwd()}/package.json`;
const packageInfo = fs.existsSync(packageJsonPath) ? require(packageJsonPath) : {};

//get details in https://github.com/pgroot/express-swagger-generator
module.exports = {
    swaggerDefinition: {
        info: {
            title: getTitle(), // Title (required)
            version: getVersion(), // Version (required)
            description: getDescription(), // Description (optional)
            license: getLicense(),

        },
        produces: ['application/json'],
        consumes: ['application/json'],
        basePath: '/', // Base path (optional),
        schemes: ['http', 'https'],
        // host: "tc3s-dev.appspot.com",
        host:"localhost:8082",
/*         "x-google-endpoints": [{
            "name": "auth-service.endpoints.tc3s-dev.cloud.goog",
            "target": "35.187.254.178",
            "allowCors": true
        }], */
		securityDefinitions: {
            firebase: {
                authorizationUrl: "",
                flow: "implicit",
                type: "oauth2",
                "x-google-issuer": "https://securetoken.google.com/tc3s-dev",
                "x-google-jwks_uri": "https://www.googleapis.com/service_accounts/v1/metadata/x509/securetoken@system.gserviceaccount.com",
                "x-google-audiences": "tc3s-dev",
                scopes: {
                    "https://www.googleapis.com/auth/firebase": "Firebase scope"
                }
            }
        } 
    },
    // customCss: '.swagger-ui .topbar { display: none }',
    // apis: ['./services/*/index.js'], // <-- not in the definition, but in the options
    basedir: process.cwd(), //app absolute path
    files: ['./services/**/index.js',
        "./services/services.config/swaggerDef.*"
    ] //Path to the API handle folder
};


function getTitle() {
    if (packageInfo.name) {
        return packageInfo.name;
    }
    return undefined;
}

function getVersion() {
    if (packageInfo.version) {
        return packageInfo.version;
    }

    return undefined;
}

function getDescription() {
    if (packageInfo.description) {
        return packageInfo.description;
    }

    return undefined;
}

function getLicense() {
    if (packageInfo.license) {
        return {
            name: packageInfo.license
        };
    }
    return undefined;
}

