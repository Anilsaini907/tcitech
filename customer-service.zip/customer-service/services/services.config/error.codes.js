module.exports = {
    MASTERDATA_NOT_FOUND: {
        status: 400,
        code: "MASTERDATA_NOT_FOUND",
        message: "Masterdata does not exist"
    },
    MASTERDATA_CONTACT_RELATIONSHIP_NOT_FOUND: {
        status: 400,
        code: "MASTERDATA_CONTACT_RELATIONSHIP_NOT_FOUND",
        message: "Contact Relationship does not exist"
    },
    MASTERDATA_CUSTOMER_ACCOUNT_GROUP_NOT_FOUND: {
        status: 400,
        code: "MASTERDATA_CUSTOMER_ACCOUNT_GROUP_NOT_FOUND",
        message: "Customer Account Group does not exist"
    },
    MASTERDATA_COMPANY_NOT_FOUND: {
        status: 400,
        code: "MASTERDATA_COMPANY_NOT_FOUND",
        message: "Company does not exist"
    },
    MASTERDATA_COMPANY_VS_BRANCH_NOT_FOUND: {
        status: 400,
        code: "MASTERDATA_COMPANY_VS_BRANCH_NOT_FOUND",
        message: "Company vs Branch does not exist"
    },
    MASTERDATA_AREA_OF_USAGE_NOT_FOUND: {
        status: 400,
        code: "MASTERDATA_AREA_OF_USAGE_NOT_FOUND",
        message: "Area Of Usage does not exist"
    },
    MASTERDATA_BRANCH_VS_STORAGE_LOCATION_NOT_FOUND: {
        status: 400,
        code: "MASTERDATA_BRANCH_VS_STORAGE_LOCATION_NOT_FOUND",
        message: "Branch vs Storage Location does not exist"
    },
    MASTERDATA_EMPLOYMENT_STATUS_NOT_FOUND:{
        status: 400,
        code: "MASTERDATA_EMPLOYMENT_STATUS_NOT_FOUND",
        message: "Employment status does not exist"
    },
    EXPORTDATA_NOT_FOUND: {
        status: 400,
        code: "EXPORTDATA_NOT_FOUND",
        message: "Exportdata does not exist"
    },

    UPDATE_FAILED: {
        status: 400,
        code: "UPDATE_FAILED",
        message: "Failed to update record"
    },
    INVALID_PARAMETER: {
        status: 400,
        code: "INVALID_PARAMETER",
        message: "Parameters given are either missing or invalid"
    },
    TOKEN_EXPIRED: {
        status: 401,
        code: "TOKEN_EXPIRED",
        message: "Token session has expired"
    },
    INVALID_USERINFO: {
        status: 400,
        code: "INVALID_USERINFO",
        message: "Userinfo from token has expired or invalid"
    },
    NOT_UNIQUE: {
        status: 400,
        code: "NOT_UNIQUE",
        message: "Record is not unique."
    },
    NOT_FOUND: {
        status: 404,
        code: "NOT_FOUND",
        message: "URL does not exist"
    },
    DATABASE_ISSUE: {
        status: 400,
        code: "DATABASE_ISSUE",
        message: "Database issue or invalid query execution."
    }
}