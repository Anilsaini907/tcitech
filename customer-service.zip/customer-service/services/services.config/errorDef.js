const Sequelize = require("sequelize");
const base64url = require('base64url');
const errorCodes = require("./error.codes");
const sharedData = require('../../utilities/sharedData');
function parameterHandler(params) {
    if (params.length <= 0) {
        throw errorCodes.INVALID_PARAMETER;
    }
    
    for (let t = 0; t < params.length; t++) {
        if (typeof params[t] === 'undefined') {
            /** convert to string to handle scenario where input value is boolean */
            throw errorCodes.INVALID_PARAMETER;
        }
    }

}

function userInfoHandler(req) {
    return new Promise((resolve, reject) => {
        const userToken = req.headers.authorization;
        if (!userToken) {
            throw errorCodes.INVALID_USERINFO;
        }
        sharedData.firebaseAdmin.auth().verifyIdToken(userToken)
            .then(function (decodedToken) {
                resolve({ id: decodedToken.user_id });
            })
            .catch(function (error) {
                if (error.code != undefined && error.code == "auth/id-token-expired") {
                    reject(errorCodes.TOKEN_EXPIRED);
                }else{
                    reject(error);
                }
                
            });
    })
}

function errorResponseHandler(err, req, res, next) {

    if (err instanceof Array) {

        let errorRecords = err.filter(result => (result instanceof Error));

        let firstStatus;
        let messageArr = err.filter(result => !(result instanceof Error));

        for (let t=0; t< errorRecords.length; t++){
            let er = errorRecords[t];
            let errorInfo = compileError(er);

            if (!firstStatus) {
                firstStatus = errorInfo.status;
            }
            messageArr.push(errorInfo.message);
        }
        return res.status(firstStatus).send(messageArr);
    }

    let errorInfo = compileError(err);
    return res.status(errorInfo.status).send(errorInfo.message);

}

function compileError(err) {
    console.log("Error: " , err);
    if (err.status && err.code) {
        let _err = Object.assign({}, err);
        delete _err.status;

        return {
            status: err.status,
            message: _err
        };
    }

    if (err instanceof Sequelize.ValidationError) {
        return {
            status: 400,
            message: {
                code: err.errors[0].validatorKey || null,
                message: err.errors[0].message || null
            }
        };
    }

    if (err.errorInfo) {
        return {
            status: 400,
            message: err.errorInfo
        };
    }

    return {
        status: 500,
        message: {
            code: "INTERNAL_SERVER_ERROR",
            message: err.message,
            error: err.stack
        }
    };
}

function errorClientHandler(req, res, next) {
    let _err = Object.assign({}, errorCodes.NOT_FOUND);
    delete _err.status;
    res.status(errorCodes.NOT_FOUND.status).send(_err);
}

module.exports = {
    ...errorCodes,
    parameterHandler,
    userInfoHandler,
    errorResponseHandler,
    errorClientHandler,
    compileError
};