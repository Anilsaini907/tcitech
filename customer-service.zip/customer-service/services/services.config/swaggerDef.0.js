/**
 * @typedef Auth
 * @property {string} name.required
 * @property {string} picture.required
 * @property {string} user_id.required
 * @property {string} email.required
 * @property {boolean} email_verified.required
 */
/**
 * @typedef Error
 * @property {string} code.required
 * @property {string} message
 * @property {string} error
 */
/**
 * @typedef Order
 * @property {string} columnName.required
 * @property {enum} direction.required - Sorting option - eg: desc,asc
 */