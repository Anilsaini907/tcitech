/**
 * @typedef CustomerGroupSearch
 * @property {Array.<CustomerGroupSearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerGroupSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerGroupSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef CustomerGroupSearchResult
 * @property {string} count.required
 * @property {Array.<CustomerGroupData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerGroupData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} countryId.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddCustomerGroup
 * @property {Array.<AddCustomerGroupData>} customerGroup.required
 */
/**
 * @typedef UpdateCustomerGroup
 * @property {string} id.required
 * @property {UpdateCustomerGroupData.model} customerGroup.required
 */
/**
 * @typedef DeleteCustomerGroup
 * @property {string} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddCustomerGroupData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 * @property {string} status.required
 * @property {string} countryId.required
 */
/**
 * @typedef UpdateCustomerGroupData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 * @property {string} status.required
 * @property {string} countryId.required
 */