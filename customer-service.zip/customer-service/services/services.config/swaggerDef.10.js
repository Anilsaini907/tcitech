/**
 * @typedef CustomerSearch
 * @property {Array.<CustomerSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef CustomerSearchResult
 * @property {string} count.required
 * @property {Array.<CustomerData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddCustomer
 * @property {Array.<AddCustomerData>} customer.required
 */
/**
 * @typedef UpdateCustomer
 * @property {string} id.required
 * @property {UpdateCustomerData.model} customer.required
 */
/**
 * @typedef DeleteCustomer
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddCustomerData
 * @property {string} id.required
 * @property {string} name.required
 * @property {string} countryId.required
 * @property {string} customerAccountGroupId.required
 * @property {string} regionId.required
 * @property {string} salutationId.required
 * @property {string} identityId.required
 * @property {string} identityNo.required
 */
/**
 * @typedef UpdateCustomerData
 * @property {string} id.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
