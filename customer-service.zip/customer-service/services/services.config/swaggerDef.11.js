/**
 * @typedef CustomerDetailsSearch
 * @property {Array.<CustomerDetailsSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerDetailsSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerDetailsSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef CustomerDetailsSearchResult
 * @property {string} count.required
 * @property {Array.<CustomerDetailsData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerDetailsData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddCustomerDetails
 * @property {Array.<AddCustomerDetailsData>} customerDetails.required
 */
/**
 * @typedef UpdateCustomerDetails
 * @property {string} id.required
 * @property {UpdateCustomerDetailsData.model} customerDetails.required
 */
/**
 * @typedef DeleteCustomerDetails
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddCustomerDetailsData
 * @property {string} customerId.required
 * @property {string} tenantId.required
 * @property {string} mAddress1.required
 * @property {string} mPostcodeId.required
 * @property {string} mCityId.required
 * @property {string} mStateId.required
 * @property {string} mCountryId.required
 * @property {string} cAddress1.required
 * @property {string} cPostcodeId.required
 * @property {string} cCityId.required
 * @property {string} cStateId.required
 * @property {string} cCountryId.required
 * @property {string} telephone.required
 * @property {string} mobile.required
 * @property {string} email.required
 * @property {string} preferedModeOfContactId.required
 * @property {boolean} receiveSMS.required
 * @property {string} gender.required
 * @property {string} highestEducationId.required
 * @property {string} ethnicityId.required
 * @property {string} dateOfBirth.required
 * @property {string} nationality.required
 * @property {string} religionId.required
 * @property {boolean} pdpaConsent.required
 * @property {string} pdpaSignedDate
 */
/**
 * @typedef UpdateCustomerDetailsData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
