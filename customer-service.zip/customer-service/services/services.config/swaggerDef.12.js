/**
 * @typedef CustomerFinanceSearch
 * @property {Array.<CustomerFinanceSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerFinanceSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerFinanceSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef CustomerFinanceSearchResult
 * @property {string} count.required
 * @property {Array.<CustomerFinanceData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerFinanceData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddCustomerFinance
 * @property {Array.<AddCustomerFinanceData>} customerFinance.required
 */
/**
 * @typedef UpdateCustomerFinance
 * @property {string} id.required
 * @property {UpdateCustomerFinanceData.model} customerFinance.required
 */
/**
 * @typedef DeleteCustomerFinance
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddCustomerFinanceData
 * @property {string} customerDetailsId.required
 * @property {string} customerId.required
 * @property {string} tenantId.required
 * @property {string} companyId.required
 * @property {string} customerGroupId.required
 * @property {string} paymentTermsId.required
 * @property {string} currencyId.required
 * @property {string} creditLimit.required
 * @property {string} blockOptionsIds.required
 * @property {string} taxClassId.required
 */
/**
 * @typedef UpdateCustomerFinanceData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
