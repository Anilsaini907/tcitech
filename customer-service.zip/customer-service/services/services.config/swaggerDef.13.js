/**
 * @typedef CustomerContactSearch
 * @property {Array.<CustomerContactSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerContactSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerContactSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef CustomerContactSearchResult
 * @property {string} count.required
 * @property {Array.<CustomerContactData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerContactData
 * @property {string} id.required
 * @property {string} customerId.required
 * @property {string} tenantId.required
 * @property {string} salutationId.required
 * @property {string} name.required
 * @property {string} relationshipId.required
 * @property {string} relationshipName
 * @property {string} relationshipCode
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} mobile.required
 * @property {string} email.required
 * @property {enum} status.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 * @property {string} customerDetailsId.required
 */
/**
 * @typedef AddCustomerContact
 * @property {Array.<AddCustomerContactData>} customerContact.required
 */
/**
 * @typedef UpdateCustomerContact
 * @property {string} id.required
 * @property {UpdateCustomerContactData.model} customerContact.required
 */
/**
 * @typedef GroupUpdateCustomerContact
 * @property {Array<UpdateCustomerContact>} customerContacts.required
 */
/**
 * @typedef DeleteCustomerContact
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddCustomerContactData
 * @property {string} customerDetailsId.required
 * @property {string} customerId.required
 * @property {string} tenantId.required
 * @property {string} salutationId.required
 * @property {string} name.required
 * @property {string} relationshipId.required
 * @property {string} telephone.required
 * @property {string} mobile.required
 * @property {string} email.required
 */
/**
 * @typedef UpdateCustomerContactData
 * @property {string} salutationId.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 * @property {string} relationshipId.required
 * @property {string} telephone.required
 * @property {string} mobile.required
 * @property {string} email.required
 */
