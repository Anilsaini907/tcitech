/**
 * @typedef EmploymentSectorSearch
 * @property {Array.<EmploymentSectorSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef EmploymentSectorSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef EmploymentSectorSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef EmploymentSectorSearchResult
 * @property {string} count.required
 * @property {Array.<EmploymentSectorData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef EmploymentSectorData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddEmploymentSector
 * @property {Array.<AddEmploymentSectorData>} employmentSector.required
 */
/**
 * @typedef UpdateEmploymentSector
 * @property {string} id.required
 * @property {UpdateEmploymentSectorData.model} employmentSector.required
 */
/**
 * @typedef DeleteEmploymentSector
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddEmploymentSectorData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
/**
 * @typedef UpdateEmploymentSectorData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
