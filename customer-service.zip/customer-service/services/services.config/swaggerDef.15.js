/**
 * @typedef IndustrySearch
 * @property {Array.<IndustrySearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef IndustrySearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef IndustrySearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef IndustrySearchResult
 * @property {string} count.required
 * @property {Array.<IndustryData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef IndustryData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddIndustry
 * @property {Array.<AddIndustryData>} industry.required
 */
/**
 * @typedef UpdateIndustry
 * @property {string} id.required
 * @property {UpdateIndustryData.model} industry.required
 */
/**
 * @typedef DeleteIndustry
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddIndustryData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
/**
 * @typedef UpdateIndustryData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
