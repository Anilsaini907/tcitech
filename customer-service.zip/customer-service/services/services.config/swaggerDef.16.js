/**
 * @typedef AnnualIncomeSearch
 * @property {Array.<AnnualIncomeSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef AnnualIncomeSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef AnnualIncomeSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef AnnualIncomeSearchResult
 * @property {string} count.required
 * @property {Array.<AnnualIncomeData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef AnnualIncomeData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} countryId.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddAnnualIncome
 * @property {Array.<AddAnnualIncomeData>} annualIncome.required
 */
/**
 * @typedef UpdateAnnualIncome
 * @property {string} id.required
 * @property {UpdateAnnualIncomeData.model} annualIncome.required
 */
/**
 * @typedef DeleteAnnualIncome
 * @property {string} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddAnnualIncomeData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 * @property {string} status.required
 * @property {string} countryId.required
 */
/**
 * @typedef UpdateAnnualIncomeData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 * @property {string} status.required
 * @property {string} countryId.required
 */
