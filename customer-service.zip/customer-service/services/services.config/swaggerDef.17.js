/**
 * @typedef MaritalStatusSearch
 * @property {Array.<MaritalStatusSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef MaritalStatusSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef MaritalStatusSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef MaritalStatusSearchResult
 * @property {string} count.required
 * @property {Array.<MaritalStatusData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef MaritalStatusData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddMaritalStatus
 * @property {Array.<AddMaritalStatusData>} maritalStatus.required
 */
/**
 * @typedef UpdateMaritalStatus
 * @property {string} id.required
 * @property {UpdateMaritalStatusData.model} maritalStatus.required
 */
/**
 * @typedef DeleteMaritalStatus
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddMaritalStatusData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
/**
 * @typedef UpdateMaritalStatusData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
