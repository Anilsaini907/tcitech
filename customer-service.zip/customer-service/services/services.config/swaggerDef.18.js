/**
 * @typedef BranchSearch
 * @property {Array.<BranchSearchParam>} search
 * @property {Array.<BranchFilterParam>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */

/**
 * @typedef BranchSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef BranchFilterParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef BranchSearchResult
 * @property {string} count.required
 * @property {Array.<BranchData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BranchData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} countryId.required
 * @property {string} countryName.required
 * @property {string} countryCode.required
 * @property {string} companyRegistrationNo.required
 * @property {string} status.required
 * @property {string} address1.required
 * @property {string} address2.required
 * @property {string} address3.required
 * @property {string} postcodeId.required
 * @property {string} postcodeCode.required
 * @property {string} cityId.required
 * @property {string} cityName.required
 * @property {string} cityCode.required
 * @property {string} stateId.required
 * @property {string} stateName.required
 * @property {string} stateCode.required
 * @property {string} currencyId.required
 * @property {string} currencyName.required
 * @property {string} currencyCode.required
 * @property {string} email.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} zone.required
 * @property {string} area.required
 * @property {string} regionId.required
 * @property {string} regionName.required
 * @property {string} regionCode.required
 * @property {string} taxId.required
 * @property {string} taxRegistrationDate.required
 * @property {string} taxZone.required
 * @property {string} taxclassId.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddBranch
 * @property {Array.<AddBranchData>} branch.required
 */
/**
 * @typedef UpdateBranch
 * @property {string} id.required
 * @property {UpdateBranchData.model} branch.required
 */
/**
 * @typedef DeleteBranch
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

/**
 * @typedef AddBranchData
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} countryId.required
 * @property {string} companyRegistrationNo.required
 * @property {string} status.required
 * @property {string} address1.required
 * @property {string} address2.required
 * @property {string} address3.required
 * @property {string} postcodeId.required
 * @property {string} cityId.required
 * @property {string} stateId.required
 * @property {string} currencyId.required
 * @property {string} email.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} zone.required
 * @property {string} area.required
 * @property {string} regionId.required
 * @property {string} taxId.required
 * @property {string} taxRegistrationDate.required
 * @property {string} taxZone.required
 * @property {string} taxclassId.required
 */

/**
 * @typedef UpdateBranchData
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} countryId.required
 * @property {string} companyRegistrationNo.required
 * @property {string} status.required
 * @property {string} address1.required
 * @property {string} address2.required
 * @property {string} address3.required
 * @property {string} postcodeId.required
 * @property {string} cityId.required
 * @property {string} stateId.required
 * @property {string} currencyId.required
 * @property {string} email.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} zone.required
 * @property {string} area.required
 * @property {string} regionId.required
 * @property {string} taxId.required
 * @property {string} taxRegistrationDate.required
 * @property {string} taxZone.required
 * @property {string} taxclassId.required
 */