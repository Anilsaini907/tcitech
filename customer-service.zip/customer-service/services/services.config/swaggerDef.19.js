/**
 * @typedef BusinessStreamSearch
 * @property {Array.<BusinessStreamSearchParam>} search
 * @property {Array.<BusinessStreamFilterParam>} filter
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BusinessStreamSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BusinessStreamSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef BusinessStreamFilterParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef BusinessStreamSearchResult
 * @property {string} count.required
 * @property {Array.<BusinessStreamData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BusinessStreamData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddBusinessStream
 * @property {Array.<BusinessStreamData>} businessStream.required
 */
/**
 * @typedef UpdateBusinessStream
 * @property {string} id.required
 * @property {BusinessStreamData.model} businessStream.required
 */
/**
 * @typedef DeleteBusinessStream
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

