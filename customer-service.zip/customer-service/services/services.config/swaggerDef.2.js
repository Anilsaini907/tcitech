/**
 * @typedef PaymentTermsSearch
 * @property {Array.<PaymentTermsSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef PaymentTermsSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef PaymentTermsSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef PaymentTermsSearchResult
 * @property {string} count.required
 * @property {Array.<PaymentTermsData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef PaymentTermsData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} countryId.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddPaymentTerms
 * @property {Array.<AddPaymentTermsData>} paymentTerms.required
 */
/**
 * @typedef UpdatePaymentTerms
 * @property {string} id.required
 * @property {UpdatePaymentTermsData.model} paymentTerms.required
 */
/**
 * @typedef DeletePaymentTerms
 * @property {string} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddPaymentTermsData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 * @property {string} status.required
 * @property {string} countryId.required
 */
/**
 * @typedef UpdatePaymentTermsData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 * @property {string} status.required
 * @property {string} countryId.required
 */
