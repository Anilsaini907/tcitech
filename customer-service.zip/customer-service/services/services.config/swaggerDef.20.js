/**
 * @typedef StorageLocationSearch
 * @property {Array.<StorageLocationSearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef StorageLocationSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef StorageLocationSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef StorageLocationSearchResult
 * @property {string} count.required
 * @property {Array.<StorageLocationData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef StorageLocationData
 * @property {string} id.required
 * @property {string} branchId.required
 * @property {string} storageId.required
 * @property {string} zone.required
 * @property {string} regionId.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} area.required
 * @property {string} primaryContact.required
 * @property {string} shipToAddress1.required
 * @property {string} shipToAddress2.required
 * @property {string} shipToAddress3.required
 * @property {string} postcodeId.required
 * @property {string} cityId.required
 * @property {string} stateId.required
 * @property {string} countryId.required
 * @property {string} countryCode.required
 * @property {string} rfIdPoleNo.required
 * @property {string} status.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddStorageLocation
 * @property {Array.<AddStorageLocationData>} storageLocation.required
 */
/**
 * @typedef UpdateStorageLocation
 * @property {string} id.required
 * @property {UpdateStorageLocationData.model} storageLocation.required
 */
/**
 * @typedef DeleteStorageLocation
 * @property {string} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddStorageLocationData
 * @property {string} branchId.required
 * @property {string} storageId.required
 * @property {string} countryId.required
 * @property {string} zone.required
 * @property {string} regionId.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} area.required
 * @property {string} primaryContact.required
 * @property {string} shipToAddress1.required
 * @property {string} shipToAddress2.required
 * @property {string} shipToAddress3.required
 * @property {string} postcodeId.required
 * @property {string} cityId.required
 * @property {string} stateId.required
 * @property {string} rfIdPoleNo.required
 * @property {string} status.required
 */
/**
 * @typedef UpdateStorageLocationData
 * @property {string} branchId.required
 * @property {string} storageId.required
 * @property {string} countryId.required
 * @property {string} zone.required
 * @property {string} regionId.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} area.required
 * @property {string} primaryContact.required
 * @property {string} shipToAddress1.required
 * @property {string} shipToAddress2.required
 * @property {string} shipToAddress3.required
 * @property {string} postcodeId.required
 * @property {string} cityId.required
 * @property {string} stateId.required
 * @property {string} rfIdPoleNo.required
 * @property {string} status.required
 */
