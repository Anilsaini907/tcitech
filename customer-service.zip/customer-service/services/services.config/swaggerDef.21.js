/**
 * @typedef BusinessTypeSearch
 * @property {Array.<BusinessTypeSearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BusinessTypeSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BusinessTypeSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef BusinessTypeSearchResult
 * @property {string} count.required
 * @property {Array.<BusinessTypeData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BusinessTypeData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} deleted.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddBusinessType
 * @property {Array.<AddBusinessTypeData>} businessType.required
 */
/**
 * @typedef UpdateBusinessType
 * @property {string} id.required
 * @property {UpdateBusinessTypeData.model} businessType.required
 */
/**
 * @typedef DeleteBusinessType
 * @property {string} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddBusinessTypeData
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} deleted.required
 */
/**
 * @typedef UpdateBusinessTypeData
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} deleted.required
 */
