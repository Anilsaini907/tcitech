/**
 * @typedef BranchBusinessStreamSearch
 * @property {Array.<BranchBusinessStreamSearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BranchBusinessStreamSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BranchBusinessStreamSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef BranchBusinessStreamSearchResult
 * @property {string} count.required
 * @property {Array.<BranchBusinessStreamData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BranchBusinessStreamData
 * @property {string} id.required
 * @property {string} countryId.required
 * @property {string} countryName.required
 * @property {string} branchId.required
 * @property {string} businessStream.required
 * @property {string} status.required
 * @property {string} updatedBy.required
 * @property {string} createdBy.required
 * @property {string} updatedAt.required
 * @property {string} createdAt.required
 */
/**
 * @typedef AddBranchBusinessStream
 * @property {Array.<AddBranchBusinessStreamData>} BranchBusinessStream.required
 */
/**
 * @typedef UpdateBranchBusinessStream
 * @property {string} id.required
 * @property {UpdateBranchBusinessStreamData.model} BranchBusinessStream.required
 */
/**
 * @typedef DeleteBranchBusinessStream
 * @property {string} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddBranchBusinessStreamData
 * @property {string} countryId.required - eg: "EN","MS"
 * @property {string} branchId.required - "English", "Malay"
 * @property {string} businessStream.required - "English", "Malay"
 * @property {string} status.required
 */
/**
 * @typedef UpdateBranchBusinessStreamData
 * @property {string} countryId.required - eg: "EN","MS"
 * @property {string} branchId.required - "English", "Malay"
 * @property {string} status.required
 */