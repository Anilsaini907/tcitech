/**
 * @typedef BranchBusinessTypeSearch
 * @property {Array.<BranchBusinessTypeSearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BranchBusinessTypeSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BranchBusinessTypeSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef BranchBusinessTypeSearchResult
 * @property {string} count.required
 * @property {Array.<BranchBusinessTypeData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef BranchBusinessTypeData
 * @property {string} id.required
 * @property {string} countryId.required
 * @property {string} countryName.required
 * @property {string} branchId.required
 * @property {string} branchName.required
 * @property {string} branchCode.required
 * @property {string} businessTypeId.required
 * @property {string} businessTypeCode.required
 * @property {string} businessTypeName.required
 * @property {string} status.required
 * @property {string} updatedBy.required
 * @property {string} createdBy.required
 * @property {string} updatedAt.required
 * @property {string} createdAt.required
 */
/**
 * @typedef AddBranchBusinessType
 * @property {Array.<AddBranchBusinessTypeData>} branchBusinessType.required
 */
/**
 * @typedef UpdateBranchBusinessType
 * @property {string} id.required
 * @property {UpdateBranchBusinessTypeData.model} branchBusinessType.required
 */
/**
 * @typedef DeleteBranchBusinessType
 * @property {string} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddBranchBusinessTypeData
  * @property {string} countryId.required
  * @property {string} branchId.required
  * @property {string} businessTypeId.required
 * @property {string} status.required
 */
/**
 * @typedef UpdateBranchBusinessTypeData
* @property {string} countryId.required
  * @property {string} branchId.required
  * @property {string} businessTypeId.required
 * @property {string} status.required
 */
