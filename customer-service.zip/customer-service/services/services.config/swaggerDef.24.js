/**
 * @typedef CompanyBranchSearch
 * @property {Array.<CompanyBranchSearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CompanyBranchSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CompanyBranchSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef CompanyBranchSearchResult
 * @property {string} count.required
 * @property {Array.<CompanyBranchData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CompanyBranchData
 * @property {string} id.required
 * @property {string} countryId.required
 * @property {string} countryCode.required
 * @property {string} companyId.required
 * @property {string} companyCode.required
 * @property {string} companyName.required
 * @property {string} branchId.required
 * @property {string} branchCode.required
 * @property {string} branchName.required
 * @property {string} status.required
 * @property {string} updatedBy.required
 * @property {string} createdBy.required
 * @property {string} updatedAt.required
 * @property {string} createdAt.required
 */
/**
 * @typedef AddCompanyBranch
 * @property {Array.<AddCompanyBranchData>} companyBranch.required
 */
/**
 * @typedef UpdateCompanyBranch
 * @property {string} id.required
 * @property {UpdateCompanyBranchData.model} companyBranch.required
 */
/**
 * @typedef DeleteCompanyBranch
 * @property {string} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
* @typedef AddCompanyBranchData
* @property {string} countryId.required
* @property {string} companyId.required
* @property {string} branchId.required
* @property {string} status.required
*/
/**
* @typedef UpdateCompanyBranchData
* @property {string} countryId.required
* @property {string} companyId.required
* @property {string} branchId.required
* @property {string} status.required
 */
