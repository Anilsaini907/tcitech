/**
 * @typedef EmploymentStatusSearch
 * @property {Array.<EmploymentStatusSearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef EmploymentStatusSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef EmploymentStatusSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef EmploymentStatusSearchResult
 * @property {string} count.required
 * @property {Array.<EmploymentStatusData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */


/**
 * @typedef EmploymentStatusData 
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */

/**
 * @typedef DeleteEmploymentStatus
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */

 /** 
 * @typedef AddEmploymentStatus
 * @property {Array.<AddEmploymentStatusData>} employmentStatuses.required
 */

 /**
 * @typedef AddEmploymentStatusData
 * @property {string} name.required
 * @property {string} code.required
 * @property {string} status.required - Status option - eg: enabled,disabled,pending
 */

/**
 * @typedef UpdateEmploymentStatus
 * @property {string} id.required
 * @property {UpdateEmploymentStatusData.model} employmentStatus.required
 */

/**
 * @typedef UpdateEmploymentStatusData
 * @property {string} name.required
 * @property {string} code.required
 * @property {string} status.required - Status option - eg: enabled,disabled,pending
 */

