/**
 * @typedef CustomerTypeSearch
 * @property {Array.<CustomerTypeSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerTypeSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerTypeSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef CustomerTypeSearchResult
 * @property {string} count.required
 * @property {Array.<CustomerTypeData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerTypeData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddCustomerType
 * @property {Array.<AddCustomerTypeData>} customerType.required
 */
/**
 * @typedef UpdateCustomerType
 * @property {string} id.required
 * @property {UpdateCustomerTypeData.model} customerType.required
 */
/**
 * @typedef DeleteCustomerType
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddCustomerTypeData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
/**
 * @typedef UpdateCustomerTypeData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
