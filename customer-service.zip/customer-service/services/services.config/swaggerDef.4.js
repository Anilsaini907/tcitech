/**
 * @typedef LeadsSearch
 * @property {Array.<LeadsSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef LeadsSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef LeadsSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef LeadsSearchResult
 * @property {string} count.required
 * @property {Array.<LeadsData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef LeadsData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddLeads
 * @property {Array.<AddLeadsData>} leads.required
 */
/**
 * @typedef UpdateLeads
 * @property {string} id.required
 * @property {UpdateLeadsData.model} leads.required
 */
/**
 * @typedef DeleteLeads
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddLeadsData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
/**
 * @typedef UpdateLeadsData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
