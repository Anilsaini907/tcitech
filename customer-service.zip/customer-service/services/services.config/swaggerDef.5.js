/**
 * @typedef ContactRelationshipSearch
 * @property {Array.<ContactRelationshipSearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef ContactRelationshipSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef ContactRelationshipSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef ContactRelationshipSearchResult
 * @property {string} count.required
 * @property {Array.<ContactRelationshipData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef ContactRelationshipData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddContactRelationship
 * @property {Array.<AddContactRelationshipData>} contactRelationship.required
 */
/**
 * @typedef UpdateContactRelationship
 * @property {string} id.required
 * @property {UpdateContactRelationshipData.model} contactRelationship.required
 */
/**
 * @typedef DeleteContactRelationship
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddContactRelationshipData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
/**
 * @typedef UpdateContactRelationshipData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
