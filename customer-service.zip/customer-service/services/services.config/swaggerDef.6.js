/**
 * @typedef CustomerAccountGroupSearch
 * @property {Array.<CustomerAccountGroupSearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerAccountGroupSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerAccountGroupSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef CustomerAccountGroupSearchResult
 * @property {string} count.required
 * @property {Array.<CustomerAccountGroupData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CustomerAccountGroupData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} topicCode.required
 * @property {string} countryId.required
 * @property {string} countryName.required
 * @property {string} updatedBy.required
 * @property {string} createdBy.required
 * @property {string} updatedAt.required
 * @property {string} createdAt.required
 */
/**
 * @typedef AddCustomerAccountGroup
 * @property {Array.<AddCustomerAccountGroupData>} customerAccountGroup.required
 */

/**
 * @typedef AddCustomerAccountGroupData
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} topicCode.required
 * @property {string} countryId.required
 */

/**
 * @typedef UpdateCustomerAccountGroup
 * @property {string} id.required
 * @property {UpdateCustomerAccountGroupData.model} customerAccountGroup.required
 */
/**
 * @typedef UpdateCustomerAccountGroupData
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} topicCode.required
 * @property {string} countryId.required
 */

/** 
 * @typedef DeleteCustomerAccountGroup
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
*/