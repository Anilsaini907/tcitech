/**
 * @typedef CompanySearch
 * @property {Array.<CompanySearchParam>} search
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CompanySearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CompanySearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef CompanySearchResult
 * @property {string} count.required
 * @property {Array.<CompanyData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef CompanyData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} languageId.required
 * @property {string} languageName.required
 * @property {string} timezoneId.required
 * @property {string} timezoneName.required
 * @property {string} postcodeId.required
 * @property {string} postcodeName.required
 * @property {string} countryId.required
 * @property {string} countryName.required
 * @property {string} cityId.required
 * @property {string} cityName.required
 * @property {string} stateId.required
 * @property {string} stateName.required
 * @property {string} currencyId.required
 * @property {string} currencyName.required
 * @property {string} address1.required
 * @property {string} address2.required
 * @property {string} address3.required
 * @property {string} email.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} zone.required
 * @property {string} area.required
 * @property {string} regionId.required
 * @property {string} regionName.required
 * @property {string} taxId.required
 * @property {string} taxZone.required
 * @property {string} companyRegistrationNo.required
 * @property {string} taxClassification.required
 * @property {string} taxRegistrationDate.required
 * @property {string} status.required
 * @property {string} updatedBy.required
 * @property {string} createdBy.required
 * @property {string} updatedAt.required
 * @property {string} createdAt.required
 * @property {string} dealerGroupId.required
 * @property {string} makeIds.required
 * @property {string} branchIds.required
 * @property {string} parentCompanyId.required
 */
/**
 * @typedef AddCompany
 * @property {Array.<AddCompanyData>} company.required
 */

/**
 * @typedef AddCompanyData
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} languageId.required
 * @property {string} timezoneId.required
 * @property {string} postcodeId.required
 * @property {string} countryId.required
 * @property {string} cityId.required
 * @property {string} stateId.required
 * @property {string} currencyId.required
 * @property {string} regionId.required
 * @property {string} address1.required
 * @property {string} address2.required
 * @property {string} address3.required
 * @property {string} companyRegistrationNo.required
 * @property {string} email.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} status.required
 * @property {string} dealerGroupId.required
 * @property {string} makeIds.required
 * @property {string} branchIds.required
 * @property {string} parentCompanyId
 */

/**
 * @typedef UpdateCompany
 * @property {string} id.required
 * @property {UpdateCompanyData.model} company.required
 */
/**
 * @typedef UpdateCompanyData
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} status.required
 * @property {string} languageId.required
 * @property {string} timezoneId.required
 * @property {string} postcodeId.required
 * @property {string} countryId.required
 * @property {string} cityId.required
 * @property {string} stateId.required
 * @property {string} currencyId.required
 * @property {string} regionId.required
 * @property {string} companyRegistrationNo.required
 * @property {string} address1.required
 * @property {string} address2.required
 * @property {string} address3.required
 * @property {string} email.required
 * @property {string} telephone.required
 * @property {string} fax.required
 * @property {string} dealerGroupId.required
 * @property {string} makeIds.required
 * @property {string} branchIds.required
 * @property {string} parentCompanyId
 */

/** 
 * @typedef DeleteCompany
 * @property {Array.<string>} ids.required
 * @property {enum} option.required - Delete option - eg: soft,hard
*/