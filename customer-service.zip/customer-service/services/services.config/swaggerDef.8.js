/**
 * @typedef TaxClassSearch
 * @property {Array.<TaxClassSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef TaxClassSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef TaxClassSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef TaxClassSearchResult
 * @property {string} count.required
 * @property {Array.<TaxClassData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef TaxClassData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} countryId.required
 * @property {string} countryName.required
 * @property {string} status.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddTaxClass
 * @property {Array.<AddTaxClassData>} taxclass.required
 */
/**
 * @typedef UpdateTaxClass
 * @property {string} id.required
 * @property {UpdateTaxClassData.model} taxclass.required
 */
/**
 * @typedef DeleteTaxClass
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddTaxClassData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 * @property {string} countryId.required
 */
/**
 * @typedef UpdateTaxClassData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 * @property {string} countryId.required
 */
