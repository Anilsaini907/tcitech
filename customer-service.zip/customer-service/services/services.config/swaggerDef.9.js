/**
 * @typedef OccupationSearch
 * @property {Array.<OccupationSearchParam>} search
 * @property {boolean} showAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef OccupationSearchAll
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef OccupationSearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */
/**
 * @typedef OccupationSearchResult
 * @property {string} count.required
 * @property {Array.<OccupationData>} rows.required
 * @property {number} page.required
 * @property {number} limit.required
 * @property {Order.model} order.required
 */
/**
 * @typedef OccupationData
 * @property {string} id.required
 * @property {string} code.required
 * @property {string} name.required
 * @property {string} updatedBy
 * @property {string} createdBy
 * @property {string} updatedAt
 * @property {string} createdAt
 */
/**
 * @typedef AddOccupation
 * @property {Array.<AddOccupationData>} occupation.required
 */
/**
 * @typedef UpdateOccupation
 * @property {string} id.required
 * @property {UpdateOccupationData.model} occupation.required
 */
/**
 * @typedef DeleteOccupation
 * @property {Array.<string>} id.required
 * @property {enum} option.required - Delete option - eg: soft,hard
 */
/**
 * @typedef AddOccupationData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
/**
 * @typedef UpdateOccupationData
 * @property {string} code.required - eg: "EN","MS"
 * @property {string} name.required - "English", "Malay"
 */
