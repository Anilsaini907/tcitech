/**
 * @typedef CacheSearch
 * @property {Array.<string>} data.required
 */
/**
 * @typedef CacheSearchResult
 * @property {string} masterdata.required
 */
/**
 * @typedef CacheSearchByIds
 * @property {Array.<CacheSearchByIdsParams>} data.required
 */
/**
 * @typedef CacheSearchByIdsParams
 * @property {string} masterdata.required
 * @property {Array.<string>} ids.required
 */

/**
 * @typedef CacheSearchByQuery
 * @property {Array.<CacheSearchByQueryParams>} data.required
 */

 /**
 * @typedef CacheSearchByQueryParams
 * @property {string} masterdata.required
 * @property {Array.<SearchParam>} search.required
 */
/**
 * @typedef SearchParam
 * @property {string} colId.required
 * @property {Array.<string>} text
 */

/**
 * @typedef deleteCache
 * @property {string} key.required
 */