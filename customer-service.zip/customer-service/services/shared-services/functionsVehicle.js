const VehicleModel = require('@driveit/driveit-databases/databases/specMaster/models/09.vehicle');
const VehicleModelModel = require('@driveit/driveit-databases/databases/specMaster/models/32.vehicleModel');
const ProductModel = require('@driveit/driveit-databases/databases/specMaster/models/13.product');
const CompanyBranch = require('@driveit/driveit-databases/databases/customerMaster/models/24.companyBranch');

// const customerCache = require('../cache-request/customer-api');
const CompanyModel = require('@driveit/driveit-databases/databases/customerMaster/models/7.company');
const BranchModel = require('@driveit/driveit-databases/databases/customerMaster/models/18.branch');
const StorageLocationModel = require('@driveit/driveit-databases/databases/customerMaster/models/20.storageLocation');

var _ = require('lodash');
const Sequelize = require("sequelize");


class Functions {

    static async getVehicleForEsUpdate(page, filter) {
        const pagination = {
            limit: page.limit,
            offset: page.limit * (page.page - 1),
        };
        let orderBy = page.order;
        let token = page.token ? page.token : null;

        let vehicleRes = await VehicleModel.searchAll([], null, pagination, orderBy, filter, false, false, true);

        let productIds = _.without(_.uniq(_.map(vehicleRes, 'productId')), null, '');
        let vehicleStockIds = _.without(_.uniq(_.map(vehicleRes, 'vehicleStockId')), null, '');
        let vehicleLocationIds = _.without(_.uniq(_.map(vehicleRes, 'vehicleLocationId')), null, '');
        let storageLocationIds = _.without(_.uniq(_.map(vehicleRes, 'storageLocationId')), null, '');

        let filterProduct = [{ colId: 'id', text: !_.isEmpty(productIds) ? productIds : [null] }];
        let productRes = await ProductModel.searchAll([], ['id', 'code', 'name', 'updatedAt'], {}, ['updatedAt', 'desc'], filterProduct, true, false, true);

        let products = productRes && _.size(productRes) > 0 ? _.map(productRes, 'dataValues') : [];

        // query to filter out from cache
        // let searchMasterdatas = [];
        // searchMasterdatas.push({
        //     masterdata: 'company',
        //     search: [{ colId: 'id', text: vehicleStockIds }],
        //     attributes: null,
        //     skipInclude: true
        // });
        // searchMasterdatas.push({
        //     masterdata: 'branch',
        //     search: [{ colId: 'id', text: vehicleLocationIds }],
        //     attributes: null,
        //     skipInclude: true
        // });

        // searchMasterdatas.push({
        //     masterdata: 'storageLocation',
        //     search: [{ colId: 'id', text: storageLocationIds }],
        //     attributes: null
        // });

        // let queryResults = await customerCache.getCacheByQuery(searchMasterdatas, token);
        // let companies = queryResults && queryResults.company ? _.map(queryResults.company, 'dataValues') : [];
        // let branches = queryResults && queryResults.branch ? _.map(queryResults.branch, 'dataValues') : [];
        // let storageLocations = queryResults && queryResults.storageLocation ? _.map(queryResults.storageLocation, 'dataValues') : [];
        
        let companies = await CompanyModel.searchAll([], null, {}, ["updatedAt", "desc"], [{ colId: 'id', text: vehicleStockIds }], true, false, true);
        let branches = await BranchModel.searchAll([], null, {}, ["updatedAt", "desc"], [{ colId: 'id', text: vehicleLocationIds }], true, false, true);
        let storageLocations = await StorageLocationModel.searchAll([], null, {}, ["updatedAt", "desc"], [{ colId: 'id', text: storageLocationIds }], true, false, true);
        
        _.forEach(vehicleRes, (row) => {
            if (row.make) {
                row.dataValues['makeName'] = row.make.dataValues && row.make.dataValues.name ? row.make.dataValues.name : '';
            }
            if (row.model) {
                row.dataValues['modelName'] = row.model.dataValues && row.model.dataValues.name ? row.model.dataValues.name : '';
            }
            if (row.variant) {
                row.dataValues['variantName'] = row.variant && row.variant.dataValues && row.variant.dataValues.name ? row.variant.dataValues.name : '';
            }
            if (row.color) {
                row.dataValues['colorName'] = row.color.dataValues && row.color.dataValues.name ? row.color.dataValues.name : '';
            }

            if (row.dataValues.oicRectifications) {
                let rectifiedData = row.dataValues.oicRectifications.filter(ocr => ocr.status === "passed")
                let totalOic = row.dataValues.oicRectifications.length;
                let totalComp = rectifiedData.length + '/' + totalOic;
                row.dataValues['totalOic'] = totalComp;
            } else if (!row.dataValues.oicRectifications) {
                row.dataValues['totalOic'] = "";
            }

            let foundVehicleStock = _.find(companies, (o) => { return o.id === row.dataValues['vehicleStockId']; });
            row.dataValues['vehicleStock'] = foundVehicleStock ? foundVehicleStock : {};
            let foundVehicleLocation = _.find(branches, (o) => { return o.id === row.dataValues['vehicleLocationId']; });
            row.dataValues['vehicleLocation'] = foundVehicleLocation ? foundVehicleLocation : {};
            let foundStorageLocation = _.find(storageLocations, (o) => { return o.id === row.dataValues['storageLocationId']; });
            row.dataValues['storageLocation'] = foundStorageLocation ? foundStorageLocation : {};

            let findProduct = _.find(products, (o) => { return o.id === row.dataValues['productId']; });
            row.dataValues['productName'] = findProduct ? findProduct.name : '';
        });

            
        return vehicleRes;
    }

    static async updateVehicle(vehicle, where, who) {
        vehicle['updatedBy'] = who;

        // check chassis no
        if (vehicle.chassisNo) {
            let filterVec = [{ colId: 'chassisNo', text: [vehicle.chassisNo] }];
            let getVeh = await VehicleModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterVec, true, false, true);

            let vhcs = getVeh ? _.map(getVeh, 'dataValues') : [];
            _.remove(vhcs, (o) => { return o.id === where.id; });

            if (vhcs && vhcs.length > 0) {
                throw errorDef.NOT_UNIQUE;
            }
        }

        // check reg no
        if (vehicle.regNo) {
            let filterVhc = [{ colId: 'regNo', text: [vehicle.regNo] }];
            let getVhc = await VehicleModel.searchAll([], null, {}, ['updatedAt', 'desc'], filterVhc, true, false, true);

            let vecs = getVhc ? _.map(getVhc, 'dataValues') : [];
            _.remove(vecs, (o) => { return o.id === where.id; });

            if (vecs && vecs.length > 0) {
                throw {
                    status: 400,
                    code: "REG_NUMBER_EXISTED",
                    message: "There is an existing vehicle chassis with the same registration number. Please check the registration number provided."
                };
            }
        }

        // find company by branch id
        if (vehicle.branchId) {
            let filterCompanyBranch = [{
                colId: 'branchId',
                text: [vehicle.branchId]
            }];
            let companyBranchRes = await CompanyBranch.searchAll([], null, {}, ['updatedAt', 'desc'], filterCompanyBranch, true, false, true);
            if (companyBranchRes && !_.isEmpty(companyBranchRes)) {
                vehicle['companyId'] = companyBranchRes[0].companyId;
            }
        }

        await VehicleModel.updateVehicle(vehicle, where);

        let picked = _.pick(vehicle, ['makeId', 'modelId', 'variantId', 'productId']);
        if (!_.isEmpty(picked)) {
            picked['updatedBy'] = who;
            await VehicleModelModel.updateVehicleModel(picked, { vehicleId: where.id });
        }

        let resp = await VehicleModel.getId(where);
        if (!resp) {
            throw errorDef.MASTERDATA_VEHICLE_NOT_FOUND;
        }
        return resp;

        //     }
        // });
    }

    static async getCacheByQuery(searchMasterDatas, token = null) {
        _.forEach(searchMasterDatas, (o) => {
            o['skipCount'] = true;
        });
        // let body = {
        //     "data": searchMasterDatas
        // };
        // return await this.processCacheByQuery(token, body);
        return await customerMasterFunctions.getDataByQuery(searchMasterDatas);
    }

    

}


module.exports = Functions;
