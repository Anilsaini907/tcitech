//get environment variables from storage and set it in env
const googleStorage = require('./storage.googlecloud');

async function processEnvironmentVariables() {

    let databaseAccount;
    let firebaseConfig;
    let sendGrid;
    let serviceAccountFirebaseAdmin;
    let smtp;

    console.log('env value for the process:' + process.env.NODE_ENV);

    if (process.env.NODE_ENV == 'development-local') {
        let bucketNm = googleStorage.storageOptions.keyFilename.includes('dev') ? 'keys-store' : 'keys-store-stage';

        // folder 'driveit'      for P2-ETCM-TCEAS-Dev env.
        // folder 'driveit-tcec' for P1-TCEC-Dev env
        let folderName = 'driveit-sit';

        process.env.databaseAccount = await googleStorage.readFile(bucketNm, `/${folderName}/databaseAccount.json`);
        process.env.firebaseConfig = await googleStorage.readFile(bucketNm, `/${folderName}/firebaseConfig.json`);
        process.env.sendGrid = await googleStorage.readFile(bucketNm, `/${folderName}/sendGrid.json`);
        process.env.serviceAccountFirebaseAdmin = await googleStorage.readFile(bucketNm, `/${folderName}/serviceAccountFirebaseAdmin.json`);
        process.env.smtp = await googleStorage.readFile(bucketNm, `/${folderName}/smtp.json`);

        /** For testing with revamp database */
        const test = {
            username: "proxyuser",
            password: "P@ssw0rd@#1",
            options: {
                host: "localhost",
                port: 3390,
                dialect: "mysql",
                logging: false,
                dialectOptions: {
                    socketPath: "/cloudsql/driveit-stage1:asia-southeast1:tc3s-master"
                }
            }
        };
        process.env.databaseAccount = JSON.stringify(test);
        const test2 = {
            "apiKey": "AIzaSyAHmzKuDeZGH8_t5gm17u2Q1bQqM8Va7dk",
            "authDomain": "driveit-stage1.firebaseapp.com",
            "databaseURL": "https://driveit-stage1.firebaseio.com",
            "projectId": "driveit-stage1",
            "storageBucket": "driveit-stage1.appspot.com",
            "messagingSenderId": "179703230394"
        }

        process.env.firebaseConfig = JSON.stringify(test2);
        const privateKey = "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDbOs/EsMek2zNZ\nA9Uogthd9PguCv9hRyVtJxhccAACAmmOt44/L08oX00xUv4y6SjiBoKAldNto+Td\na2Mlq4SBwuPI8QBacRgnTIyRVP2RPoaJZfuSAq0SdgkGCyYwrgQ54B4X1qIlAHAN\nThkFzLD/oulxB7CHtKzr9ioLJODuxtT+n/d8zFFHzUo2LWQqseWGn/2b8SczblfP\nAyORDsxCu+CzAlwVYueRVa7wpRBZWSio60DxMdKFOv1ZvG4wRPI+v5+W0hAEMkI2\ndV3rqLaYhwVppoWbQATjb+cgN/g68aIHUuof760fl720FZYqVTPJaGkx2H9lTlqF\nmT00MSF5AgMBAAECggEAI6YnnQNmI4+lhOcTpXfJeVXZeZs+NfJcyqgd1QI9bhY4\nVgXRMsMdqyH8KnYlcd/qTv7h/8jdTanmEH9i6wA+Ft+7LLTL6ukTFWjkPsnERfcV\n54fW5cJbpHHfO8VaW3Ygp8yi+Btl2IB+uBsoBIJpkdhK/59RfG/L4r7vzUoc7ZbI\najElT46ROq24eYHwFuSSeAD+IY+83NuiaSBsBQaL0Qv2wQijLWg+s5PnYrWwH+Xs\ndeNe0e55f0hbQd5wnYNzZ8SYLpVf0firoTCLzy6LLjj01u1I7DzRxH0q+/0TWYuQ\nMLNbacsLgunWv0z1ryMNMKP6e+JkYm7gK7D2Xe8B9QKBgQD5z+KuWicu7j0NgoUH\n8sQHjKZqBPW6puB7nbM7izN1UpqIKOYoMC+R3lph+EEI2ybcO4J8osocP1JN7lVH\nPvukrCPXYvQ7LY26rsSYQ4MBAduQJpRD6PqN1ZCzrnyp1wICq4Epjwot7XjM3k/Y\nSRKbIuBoSuPRnVoTt1wuilL0zwKBgQDgqP8qUpJIQBPZRSvv6Iub/7R8lm7KVvlB\nSC9UTWFJ7ZCxCSbjKDYL7ru3RqC8e5//Um/WEzuAbA8ban9UlcMF9WLT33b14lRa\ntXKgt8bpJRdvNhi42xcsy6U5nTWqPBYEAOhm6cQZaqK7eraDJPW4AZ4mCwoZjAN9\n7AW1sH0nNwKBgQCLBtf4AnJWGv5dW2sf3kqcjPk8faAoDaFXCo/qLnEn9R3Ncz2L\n1i1TN/UDGv9Op3B8Fp5rMMncaJ0sg9xv9yxjG+4ie47CtHpxD7yXpNLup5MDKYVQ\nOgPfFaEfbpcwilkzFTGf6FxY7RVSptK24wv4zLMpN6yMRs8Ps/cYa6D5XwKBgArQ\nt+/+p6Ioy4vTI6laBZaN+c9hopXFGBzHb9fcHcnkUOnk6eVXozpx1MGe+c/5F5vA\nCThCFsQ474U/XD/jMc9Qn+BZSq3NpofzYkBQeJfyvC0Tap9DlNsINr0OT24RlHG+\n5XFG4bTjiFAEOVMY7WddVJK6R1MxhV2DhkbX5z6DAoGAdQcLYQO6fKPW8xbLIB4i\ntT0OxiXY8Vd4S+S+AIzNBybWU2+1ECqehr05+HjvY+dalBtsWNEGutnisQCM23JL\ninC9+YsPAYlqCNdx3+fdSBm5o3DcjQByWluwj6B8O/wJTl/GrE5sUzJTq3hL7xwV\nHsjJMFyoZgMeA2rj4scExHA=\n-----END PRIVATE KEY-----\n";
        const serviceAccountFirebaseAdminConfig = {
            "type": "service_account",
            "project_id": "driveit-stage1",
            "private_key_id": "24c03a8d04e2615f4204202029554056681bd262",
            "private_key": privateKey.replace(/\\n/g, '\n'),
            "client_email": "firebase-adminsdk-1jw7c@driveit-stage1.iam.gserviceaccount.com",
            "client_id": "106221171981417449102",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
            "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-1jw7c%40driveit-stage1.iam.gserviceaccount.com"
        }
        process.env.serviceAccountFirebaseAdmin = JSON.stringify(serviceAccountFirebaseAdminConfig);

    } else {

        databaseAccount = {
            "username": process.env.DB_USER_NAME,
            "password": process.env.DB_PASS,
            "options": {
                "host": process.env.DB_HOST,
                "port": parseInt(process.env.DB_PORT),
                "dialect": process.env.DB_DIALECT,
                "logging": false,
                "dialectOptions": {
                    "socketPath": process.env.DB_SOCKET_PATH
                }
            }
        };
        firebaseConfig = {
            "apiKey": process.env.FIREBASE_API_KEY,
            "authDomain": process.env.FIREBASE_AUTH_DOMAIN,
            "databaseURL": process.env.FIREBASE_DB_URL,
            "projectId": process.env.FIREBASE_PROJECT_ID,
            "storageBucket": process.env.FIREBASE_STOREAGE_BUCKET,
            "messagingSenderId": process.env.FIREBASE_MESSAGING_SENDER_ID
        };
        sendGrid = {
            "SENDGRID_API_KEY": process.env.SENDGRID_API_KEY
        };
        serviceAccountFirebaseAdmin = {
            "type": process.env.FIREBASE_SERVICE_ACC_TYPE,
            "project_id": process.env.FIREBASE_SERVICE_ACC_PROJECT_ID,
            "private_key_id": process.env.FIREBASE_SERVICE_ACC_PRIVATE_KEY_ID,
            "private_key": process.env.FIREBASE_SERVICE_ACC_PRIVATE_KEY.replace(/\\n/g, '\n'),
            "client_email": process.env.FIREBASE_SERVICE_ACC_CLIENT_EMAIL,
            "client_id": process.env.FIREBASE_SERVICE_ACC_CLIENT_ID,
            "auth_uri": process.env.FIREBASE_SERVICE_ACC_AUTH_URI,
            "token_uri": process.env.FIREBASE_SERVICE_ACC_TOKEN_URI,
            "auth_provider_x509_cert_url": process.env.FIREBASE_SERVICE_ACC_AUTH_CERT_URL,
            "client_x509_cert_url": process.env.FIREBASE_SERVICE_ACC_CLIENT_CERT_URL
        };
        smtp = {
            "host": "smtp.gmail.com",
            "port": parseInt(process.env.SMTP_USER_PORT),
            "secure": false,
            "auth": {
                "user": process.env.SMTP_USER_EMAIL,
                "pass": process.env.SMTP_USER_PASS
            },
            "tls": {
                "rejectUnauthorized": false
            }
        };

        // if (process.env.NODE_ENV == 'staging') {
        //     databaseAccount = require('../config/keys/stage/databaseAccount.json');
        //     firebaseConfig = require('../config/keys/stage/firebaseConfig.json');
        //     sendGrid = require('../config/keys/stage/sendGrid.json');
        //     serviceAccountFirebaseAdmin = require('../config/keys/stage/serviceAccountFirebaseAdmin.json');
        //     smtp = require('../config/keys/stage/smtp.json');
        // }

        process.env.databaseAccount = JSON.stringify(databaseAccount);
        process.env.firebaseConfig = JSON.stringify(firebaseConfig);
        process.env.sendGrid = JSON.stringify(sendGrid);
        process.env.serviceAccountFirebaseAdmin = JSON.stringify(serviceAccountFirebaseAdmin);
        process.env.smtp = JSON.stringify(smtp);
    }

    console.log('env value for the process:' + JSON.stringify(process.env.databaseAccount, null, 2));
}

module.exports = {
    processEnvironmentVariables
}
