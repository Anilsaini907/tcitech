const firebaseAdmin = require('firebase-admin');

const firebaseConfig = JSON.parse(process.env.firebaseConfig);
const serviceAccountFirebaseAdmin = JSON.parse(process.env.serviceAccountFirebaseAdmin);

const firebaseDevCredentials = {
  credential: firebaseAdmin.credential.cert(serviceAccountFirebaseAdmin),
  databaseURL: firebaseConfig.databaseURL
}

firebaseAdmin.initializeApp(firebaseDevCredentials);
// firebaseAdmin.initializeApp(firebaseAdmin.credential.applicationDefault());

const firestore = firebaseAdmin.firestore();
const settings = {
  /* your settings... */
  timestampsInSnapshots: true
};
firestore.settings(settings);

var SharedData = {
  env: undefined,
  firebaseAdmin,
  firestore
}

module.exports = {
  ...SharedData,
  serviceAccount: serviceAccountFirebaseAdmin
};