var request = require('request-promise');
const config = require('config');
const GeneralAPI = require('../services/cache-request/general-api');

function generateSeries(code, headers) {

    const theHeader = {
        'Authorization' : headers.authorization,
        'Content-Type': 'application/json',
    };
    return request(config.topicSeries.hostname + "/" + code, {
        headers: theHeader
    });
}

function generateMultipleSeries(code, headers, howMany, prefix = null) {
    const theHeader = {
        'Authorization' : headers.authorization,
        'Content-Type': 'application/json',
    };

    let theBody = {};
    theBody['code'] = code;
    theBody['qty'] = howMany;
    if (prefix !== null) {
        theBody['prefix'] = prefix;
    }

    return request(config.topicSeries.hostname + "/multiple", {
       headers: theHeader,
       method: 'POST',
       json: true,
       body: theBody
    });
}

function addCode(token, code) {
    let prefix, startNumber, endNumber;
    switch (code) {
        default:
            prefix = "";
            startNumber = "0000000";
            endNumber = "9999999";
            break;
    }
    let topicSeries = [{
        code,
        prefix,
        startNumber,
        currentNumber: startNumber,
        endNumber,
        status: "enabled",
        yearSuffix: false,
        resetPerYr: false
    }];

    let options = {
        endpoint: '/topic-series/add',
        method: 'PUT'
    }
    return GeneralAPI.generalService(token, {
        topicSeries
    }, options);
}

module.exports = {
    generateSeries,
    generateMultipleSeries,
    addCode
}