const Sequelize = require("sequelize");
const Op = Sequelize.Op;
var _ = require('lodash');

function generateWhereClause(searches) {
  if (!searches) return "";

  let searchQuery = " WHERE ";
  searches.forEach(search => {
    searchQuery +=
      search.colId + " REGEXP " + generateWhereValues(search.text) + " OR ";
  });

  searchQuery = searchQuery.slice(0, -4);

  return searchQuery;
}

function generateWhereValues(text) {
  //Array<text>
  if (!text) return "";

  let searchValue = "";
  text.forEach(value => {
    searchValue += "|" + value;
  });

  if (searchValue && searchValue.length > 0) {
    searchValue = searchValue.substring(1);
    searchValue = "'" + searchValue + "'";
  }

  return searchValue;
}

function getConfig(moduleArr) {
  let requiredModule;
  let error;
  for (let t = 0; t < moduleArr.length; t++) {
    try {
      requiredModule = require(moduleArr[t]);
      if (requiredModule) return requiredModule;
    } catch (e) {
      error = e;
    }
  }

  throw error;
}

function filterGenerator(valueArr = []) {
  let arr = [];

  _.forEach(valueArr, (value) => {
    if (value.filterCondition) {
      let rangeAndCondition = [];
      for (let t = 0; t < value.filterCondition.length; t++) {

        let operation = null;
        switch (value.filterCondition[t].direction) {
          case "ne":
            operation = Op.ne;
            break;
          case "notIn":
            operation = Op.notIn;
            break;
          case "in":
            operation = Op.in;
            break;
          case "notBetween":
            operation = Op.notBetween;
            break;
          case "between":
            operation = Op.between;
            break;
          case "not":
            operation = Op.not;
            break;
          case "is":
            operation = Op.is;
            break;
          case "eq":
            operation = Op.eq;
            break;
          case "lte":
            operation = Op.lte;
            break;
          case "lt":
            operation = Op.lt;
            break;
          case "gte":
            operation = Op.gte;
            break;
          case "gt":
            operation = Op.gt;
            break;
          case "or":
            operation = Op.or;
            break;
          case "like":
            operation = Op.like;
            break;
          default:
            break;
        }

        if (operation !== null) {
          if (
            value.text[t] !== null ||
            (value.text[t] === null && (operation === Op.eq || operation === Op.ne || operation === Op.not))
          ) {
            rangeAndCondition.push({
              [value.colId]: {
                [operation]: operation === Op.like ? `%${value.text[t]}%` : value.text[t]
              }
            });
          }
        }
      }

      if (rangeAndCondition.length > 0) {
        arr = _.concat(arr, rangeAndCondition);
      }

    } else if (value.dateTimeRange) {

      let startDateTime = null;
      let endDateTime = null;
      _.forEach(value.dateTimeRange, (val) => {
        if (val.isStart) {
          startDateTime = val.dateTimeValue;
        } else {
          endDateTime = val.dateTimeValue;
        }
      });
      
      if (startDateTime !== null && endDateTime !== null) {
        arr.push({
          [value.colId]: { [Op.gte]: startDateTime, [Op.lte]: endDateTime }
        });
      } else {
        if (startDateTime === null && endDateTime !== null) {
          arr.push({
            [value.colId]: { [Op.lte]: endDateTime }
          });
        } else if (startDateTime !== null && endDateTime === null) {
          arr.push({
            [value.colId]: { [Op.gte]: startDateTime }
          });
        }
      }

    } else if (value.text) {
      // value.text.forEach(singleText => {

      //   arr.push({
      //     [value.colId]: singleText
      //   });
      // });

      let texts = [];
      let hasNull = false;
      _.forEach(value.text, (singleText) => {
        if (singleText && singleText !== null) {
          texts.push(singleText);
        } else {
          hasNull = true;
        }
      });

      arr.push({
        [value.colId]: { [Op.in]: texts }
      });
      if (hasNull) {
        arr.push({
          [value.colId]: { [Op.is]: null }
        });
      }

    }
  });

  return arr;
}

function searchGenerator(valueArr = []) {
  let arr = [];
  if (valueArr.length) {
    valueArr.forEach(value => {

      value.text.forEach(singleText => {
        arr.push({ [value.colId]: singleText });
      });
    });

  }
  return arr;
}

function pickObjectKeysFromArray(array, thingsToPick) {
  if (array) {
    return _.map(array, _.partial(_.ary(_.pick, thingsToPick.length), _, thingsToPick));  
  }
  return [];
}

function multiIncludes(values, input) {
  var re = new RegExp(values.join('|'));
  return re.test(input);
}

function isJsonString(str) {
  if (typeof str === 'string') {
    if (_.includes(str, '[') || _.includes(str, '{')) {
      try {
        JSON.parse(str);
        return true;
      } catch (e) {
        return false;
      }
    }
  }
  return false;
}

function leadingZeros(num, size) {
  var s = num + "";
  while (s.length < size) s = "0" + s;
  return s;
}

module.exports = {
  generateWhereClause,
  getConfig,
  filterGenerator,
  searchGenerator,
  pickObjectKeysFromArray,
  multiIncludes,
  isJsonString,
  leadingZeros
};

//WHERE interests REGEXP 'sports|pub'
